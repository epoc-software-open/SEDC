#/bin/bash
echo -n "DBサーバのIPアドレスを入力して下さい > "
read server_nm

echo "接続するータベース名を入力して下さい。"
echo -n "（省略時:smartedc > "
read db_name

if [ -z "$db_name" -o "$db_name" = " " ]; 
then
    db_name="smartedc"
fi

DIR=$(cd $(dirname $0) && pwd)/environment
sed -e "s/localhost/$server_nm/" $DIR/reorg.cfg > $DIR/client.cfg
sed -i -e "s/smartedc/$db_name/" $DIR/client.cfg

echo -n "データベース：${db_name}のユーザーIDを入力して下さい > "
read user_id

stty -echo
echo -n "データベース：${db_name}のパスワードを入力して下さい > "
read passwd
stty echo


echo ""
java -cp $DIR/gxclassR.zip com.genexus.PasswordChanger -file:$DIR/client.cfg -user:$user_id -password:$passwd

echo "DB接続先情報を設定しました。"

