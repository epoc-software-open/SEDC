#!/bin/bash
echo -n "MySQL ユーザIDを入力して下さい > "
read user_id

stty -echo
echo -n "MySQL パスワードを入力して下さい > "
read passwd
stty echo


echo ""
echo "作成するデータベース名を入力して下さい。"
echo -n "（省略時:smartedc > "
read db_name

if [ -z "$db_name" -o "$db_name" = " " ]; 
then
    db_name="smartedc"
fi

echo "データベースを作成中です。しばらくお待ちください。"

dbchk=`mysql -u $user_id -p$passwd -e "show databases like '${db_name}';"`
if [ "$?" -ne 0 ];
then
    echo "データベース作成中にエラーが発生しました。処理を中断します。"
    exit
fi

DIR=$(cd $(dirname $0) && pwd)/database

if [ -z "$dbchk" -o "$dbchk" = " "  ];
then
    `mysql -u $user_id -p$passwd -e "create database ${db_name};"`
    mysql -u $user_id -p$passwd $db_name < $DIR/smartedc_tbl_create.sql
    mysql -u $user_id -p$passwd $db_name < $DIR/smartedc_data_ins.sql
else
    echo -n "データベース:${db_name} は既に作成されています。再作成しますか？（y/n）> "
    read crtchk
    if [ "$crtchk" = "y" ];
    then
        `mysql -u $user_id -p$passwd -e "drop database ${db_name};"`
        `mysql -u $user_id -p$passwd -e "create database ${db_name};"`
        mysql -u $user_id -p$passwd $db_name < $DIR/smartedc_tbl_create.sql
        mysql -u $user_id -p$passwd $db_name < $DIR/smartedc_data_ins.sql
    else
        echo "ストアドプロシージャの作成のみ行います。"
    fi
fi

mysql -u $user_id -p$passwd $db_name < $DIR/b506_sf01_get_input_level.sql
mysql -u $user_id -p$passwd $db_name < $DIR/b506_sp01_up_crf_val.sql
mysql -u $user_id -p$passwd $db_name < $DIR/b506_sp02_crf_update.sql
mysql -u $user_id -p$passwd $db_name < $DIR/b506_sp03_crf_result.sql
mysql -u $user_id -p$passwd $db_name < $DIR/b506_sp04_crf_verup.sql
mysql -u $user_id -p$passwd $db_name < $DIR/proc_chk_crf_ver0.9.sql
mysql -u $user_id -p$passwd $db_name < $DIR/proc_err_chk_csv_ver2.sql
mysql -u $user_id -p$passwd $db_name < $DIR/proc_master_csv_ver14.sql
mysql -u $user_id -p$passwd $db_name < $DIR/proc_optimize_crf_ver1.0.sql

echo "MySQLにデータベース：${db_name}を作成しました。"

