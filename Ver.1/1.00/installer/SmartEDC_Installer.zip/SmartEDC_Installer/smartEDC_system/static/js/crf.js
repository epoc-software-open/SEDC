function Crf(studyIdsStr,subjectIdsStr,crfidsStr,crfInputLevelsStr,crfUpdCntsStr){
	this.studyIds = studyIdsStr.split(Crf.Delimiter);
	this.subjectIds = subjectIdsStr.split(Crf.Delimiter);
	this.crfids = crfidsStr.split(Crf.Delimiter);
	this.crfInputLevels = crfInputLevelsStr.split(Crf.Delimiter);
	this.crfUpdCnts = crfUpdCntsStr.split(Crf.Delimiter);

	this.numPages = this.studyIds.length;
	this.setPage(0);

	this.moveValues = new Array(this.numPages);
	this.setMoveValues();
	this.dmArrivalFlgs = new Array(this.numPages);
	this.resetDmArrivalFlgs();
	this.errorItems = new Array(this.numPages);
	this.resetErrorItems();

	this.loadingFlag = false;

	this.lastFocusEl = null;
}
Crf.prototype.setPage = function(page){
	this.page = page;

	this.studyId = this.studyIds[page];
	this.subjectId = this.subjectIds[page];
	this.crfid = this.crfids[page];
	this.crfInputLevel = this.crfInputLevels[page];
	this.crfUpdCnt = this.crfUpdCnts[page];
}
Crf.prototype.setMoveValues = function(){
	for(var i = 0;i < this.numPages;i++){
		new Ajax.Request("../servlet/ab702_pc01_get_crf_design?" + this.studyIds[i] + "," + this.subjectIds[i] + "," + this.crfids[i] + "," + this.crfInputLevels[i] + ",1",
				{
			asynchronous:false,
			method:'post',
			onSuccess:function(req){
				var obj = eval('(' + req.responseText + ')');
				if(obj.RESULT_CD == null){
					alert("CRFデザイン情報の取得ができませんでした。");
					backToSearchView();
				}else{
					if(obj.RESULT_CD != Crf.ResultCd.OK){
						if(obj.RESULT_CD == Crf.ResultCd.NG){
							if(obj.ERR_MSG != null){
								alert(br2nl(obj.ERR_MSG));
							}
							backToSearchView();
						}else{
							MoveToErrorView();
						}
					}else{
						this.moveValues[i] = obj.MOVE_VALUE;
					}
				}
			}.bind(this),
			onFailure:function(){
				alert("CRFデザイン情報の取得ができませんでした。");
				backToSearchView();
			}
				});
	}
}
Crf.prototype.resetDmArrivalFlgs = function(){
	for(var i = 0;i < this.numPages;i++){
		this.dmArrivalFlgs[i] = 0;
	}
}
Crf.prototype.resetErrorItems = function(){
	resetViewErr();
	for(var i = 0;i < this.numPages;i++){
		this.errorItems[i] = new Array();
	}
}
Crf.Delimiter = ",";
Crf.ResultCd = {"OK":"0","NG":"1","Warning":"2","DBError":"9"}

Crf.prototype.getCrfDesign = function(initFlg){
	if(initFlg == 1){
		this.resetDmArrivalFlgs();
		this.resetErrorItems();
	}
	new Ajax.Request("../servlet/ab702_pc01_get_crf_design?" + this.studyId + "," + this.subjectId + "," + this.crfid + "," + this.crfInputLevel + "," + initFlg,
			{
		asynchronous:false,
		method:'post',
		onSuccess:function(req){
			var obj = eval('(' + req.responseText + ')');
			if(obj.RESULT_CD == null){
				alert("CRFデザイン情報の取得ができませんでした。");
			}else{
				if(obj.RESULT_CD != Crf.ResultCd.OK){
					if(obj.RESULT_CD == Crf.ResultCd.NG){
						if(obj.ERR_MSG != null){
							alert(br2nl(obj.ERR_MSG));
						}
					}else{
						MoveToErrorView();
					}
				}else{
					this.getCrfJsp(req.responseText,obj.CRF_ITEMS,initFlg);
				}
			}
		}.bind(this),
		onFailure:function(){
			alert("CRFデザイン情報の取得ができませんでした。");
		}
			});
}
Crf.prototype.getCrfJsp = function(text,crfItems){
	new Ajax.Request("wrap.jsp",
			{
		asynchronous:false,
		method:'post',
		parameters:"jobj=" + encodeURIComponent(text) + "&subjectId=" + this.subjectId + "&page=" + this.page + "&numPages=" + this.numPages,
		onSuccess:function(req){
			$("wrap").innerHTML = req.responseText;
			setHeaderNamesWidth();
			setCrfHeight(crfItems);
			viewFigure(crfItems);
			setColor(crfItems);
			viewErr(this.errorItems[this.page]);
			this.setDmArrivalFlgForm();
		}.bind(this),
		onFailure:function(){
			alert("CRFデザイン情報の取得ができませんでした。");
		}
			});
}

Crf.prototype.setCrfVal = function(crfItemCd,crfValue){
//	new Ajax.Request("../servlet/ab704_pc01_set_crf_val?" + this.studyId + "," + this.subjectId + "," + this.crfid + "," + crfItemCd + "," + encodeURIComponent(crfValue),
	new Ajax.Request("../servlet/ab704_pc01_set_crf_val?" + this.studyId + "," + this.subjectId + "," + this.crfid + "," + this.crfInputLevel + "," + crfItemCd + "," + encodeURIComponent(crfValue),
			{
		method:'post',
		onSuccess:function(req){
			var obj = eval('(' + req.responseText + ')');
			if(obj.RESULT_CD == null){
				alert("CRF入力データ保存ができませんでした。");
			}else{
				if(obj.RESULT_CD != Crf.ResultCd.OK){
					if(obj.RESULT_CD == Crf.ResultCd.NG){
						if(obj.ERR_MSG != null){
							alert(br2nl(obj.ERR_MSG));
						}
					}else{
						MoveToErrorView();
					}
				}
			}
		},
		onFailure:function(){
			alert("CRF入力データ保存ができませんでした。");
		}
			});
}

Crf.prototype.setCrfGroupVal = function(crfItemCd){
	var crfItems = document.getElementsByName(crfItemCd);
	var val = "";
	for(var i = 0;i < crfItems.length;i++){
		var crfItem = crfItems[i];
		if(crfItem.value != null){
			val += crfItem.value;
		}
	}
	this.setCrfVal(crfItemCd,val);
}

Crf.prototype.errchkCrfVal = function(){
	this.resetErrorItems();
	var ngFlag = false;
	var warningFlag = false;
	var res = false;
	for(var i = 0;i < this.numPages;i++){
		if(isReferMode(this.moveValues[i])) continue;
		new Ajax.Request("../servlet/ab705_pc01_errchk_crf_val?" + this.studyIds[i] + "," + this.subjectIds[i] + "," + this.crfids[i] + "," + this.crfInputLevels[i] + "," + this.dmArrivalFlgs[i],
				{
			asynchronous:false,
			method:'post',
			onSuccess:function(req){
				var obj = eval('(' + req.responseText + ')');
				if(obj.RESULT_CD == null){
					alert("CRF入力エラーチェックができませんでした。");
					res = false;
				}else{
					switch(obj.RESULT_CD){
					case Crf.ResultCd.OK:
						res = true;
						break;
					case Crf.ResultCd.NG:
						ngFlag = true;
						this.errorItems[i] = obj.ERR_ITEMS;
						res = true;
						break;
					case Crf.ResultCd.Warning:
						warningFlag = true;
						this.errorItems[i] = obj.ERR_ITEMS;
						res = true;
						break;
					case Crf.ResultCd.DBError:
//						alert("CRF入力エラーチェックができませんでした。");
						MoveToErrorView();
						res = false;
						break;
					default:
						alert("CRF入力エラーチェックができませんでした。");
					res = false;
					}
				}
			}.bind(this),
			onFailure:function(){
				alert("CRF入力エラーチェックができませんでした。");
				res = false;
			}
				});
		if(!res)return;
	}
	if(ngFlag){
		viewErr(this.errorItems[this.page]);
		alert("エラーがあります。");
	}else if(warningFlag){
		viewErr(this.errorItems[this.page]);
		if(confirm("エラーがありますが、保存しますか？")){
			this.viewRegCrfPanel();
		}
	}else{
		if($("dmArrivalFlg") == null){
			this.viewRegCrfPanel();
		}else{
			if($("dmArrivalFlg").checked == 0){
				this.viewRegCrfPanel();
			}else{
				this.viewRegCrfPanel2();
			}
		}
	}
}

Crf.prototype.regCrf = function(updateReason){
	var errFlag = false;
	var errmsgs = new Array();
	for(var i = 0;i < this.numPages;i++){
		if(isReferMode(this.moveValues[i])) continue;
		var res = false;
		new Ajax.Request("../servlet/ab706_pc01_reg_crf?" + this.studyIds[i] + "," + this.subjectIds[i] + "," + this.crfids[i] + "," + this.crfInputLevels[i] + "," + this.dmArrivalFlgs[i] + "," + "," + "," + "," + encodeURIComponent(updateReason),
				{
			asynchronous:false,
			method:'post',
			onSuccess:function(req){
				var obj = eval('(' + req.responseText + ')');
				if(obj.RESULT_CD == null){
					alert("CRF入力データ登録処理ができませんでした。");
					res = false;
				}else{
					if(obj.RESULT_CD != Crf.ResultCd.OK){
						if(obj.RESULT_CD == Crf.ResultCd.NG){
							errFlag = true;
							if(obj.ERR_MSG != null){
								if(errmsgs.length == 0){
									errmsgs.push(obj.ERR_MSG);
								}else{
									for(var j = 0;j < errmsgs.length;j++){
										if(obj.ERR_MSG == errmsgs[j]){
											break;
										}else if(j == errmsgs.length - 1){
											errmsgs.push(obj.ERR_MSG);
										}
									}
								}
							}
						}else{
							MoveToErrorView();
						}
					}
					res = true;
				}
			},
			onFailure:function(){
				alert("CRF入力データ登録処理ができませんでした。");
				res = false;
			}
				});
		if(!res) return;
	}
	if(errFlag){
		if(errmsgs.length > 0){
			alert(br2nl(errmsgs.join("\n")));
		}
	}else{
		this.delCrfDesign();
	}
}

Crf.prototype.delCrfDesign = function(){
	new Ajax.Request("../servlet/ab702_pc04_del_crf_design",
			{
		method:'post',
		onSuccess:function(req){
			var obj = eval('(' + req.responseText + ')');
			if(obj.RESULT_CD == null){
				alert("CRFデザイン削除処理ができませんでした。");
			}else{
				if(obj.RESULT_CD != Crf.ResultCd.OK){
					if(obj.RESULT_CD == Crf.ResultCd.NG){
						if(obj.ERR_MSG != null){
							alert(br2nl(obj.ERR_MSG));
						}
					}else{
						MoveToErrorView();
					}
				}else{
					backToSearchView();
				}
			}
		},
		onFailure:function(){
			alert("CRFデザイン削除処理ができませんでした。");
		}
			});
}

Crf.prototype.setDmArrivalFlg = function(checked){
	this.dmArrivalFlgs[this.page] = (checked) ? 1 : 0;
}
Crf.prototype.setDmArrivalFlgForm = function(){
	if($("dmArrivalFlg") == null)return;
	$("dmArrivalFlg").checked = this.dmArrivalFlgs[this.page];
}

Crf.prototype.changePage = function(_page){
	if(this.loadingFlag) return;
	this.loadingFlag = true;
	resetViewErr();
	this.setPage(_page);
	this.getCrfDesign(0);
	this.lastFocusEl = null;
	this.loadingFlag = false;
}
Crf.prototype.firstPage = function(){this.changePage(0);}
Crf.prototype.prevPage = function(){this.changePage(this.page - 1);}
Crf.prototype.nextPage = function(){this.changePage(this.page + 1);}
Crf.prototype.lastPage = function(){this.changePage(this.numPages - 1);}

Crf.prototype.cancelEditData = function(){
	if(window.confirm("編集中の内容を破棄し開いた直後の状態に戻します。よろしいですか？")){
		if(this.loadingFlag) return;
		this.loadingFlag = true;
		this.setPage(this.page);
		this.getCrfDesign(1);
		this.loadingFlag = false;
	}
}

Crf.prototype.viewRegCrfPanel = function(){
	var tgtCnt = 0;
	for(var i = 0;i < this.moveValues.length;i++){
		if(!isReferMode(this.moveValues[i])){
			tgtCnt++;
		}
	}
	$("tgtCnt").innerHTML = tgtCnt;
	$("overlayScreen").style.display = "";
	$("regCrfPanel").style.display = "";
	center("regCrfPanel","absolute");
}
function hideRegCrfPanel() {
	$("overlayScreen").style.display = "none";
	$("regCrfPanel").style.display = "none";
}

Crf.prototype.viewRegCrfPanel2 = function(){
	var tgtCnt2 = 0;
	for(var i = 0;i < this.moveValues.length;i++){
		if(!isReferMode(this.moveValues[i])){
			tgtCnt2++;
		}
	}
	$("tgtCnt2").innerHTML = tgtCnt2;
	$("overlayScreen").style.display = "";
	$("regCrfPanel2").style.display = "";
	center("regCrfPanel2","absolute");
}
function hideRegCrfPanel2() {
	$("overlayScreen").style.display = "none";
	$("regCrfPanel2").style.display = "none";
}

function setHeaderNamesWidth(){
	var studyNmW = $("studyNm").offsetWidth;
	if(992 - studyNmW <= 0) return;
	if(studyNmW >= 496){
		$("studyNm").innerHTML += "　";
		studyNmW = $("studyNm").offsetWidth;
	}
	var w = (992 - studyNmW) / 2;
	$("crfNm").style.width = w + "px";
	$("subjectId").style.width = w + "px";
}

function setCrfHeight(crfItems){
	var height = 0;
	for(var i = 0;i < crfItems.length;i++){
		var obj = crfItems[i];
		var bottom = obj.LOCATION_Y2;
		if(height < bottom) height = bottom;
	}
	$("crf").style.height = height + "px";
}

function viewFigure(crfItems){
	for(var i = 0;i < crfItems.length;i++){
		var crfItem = crfItems[i];
		if(crfItem.CRF_ITEM_DIV == 'Line'){
			viewLine(crfItem);
		}else if(crfItem.CRF_ITEM_DIV == 'Rect'){
			viewRect(crfItem);
		}else if(crfItem.CRF_ITEM_DIV == 'Paren'){
			viewParen(crfItem);
		}
	}
}

var cvBuff = 10;

function viewLine(crfItem){
	if(crfItem.LINE_SIZE_DIV == 0) return;

	var el = $(crfItem.CRF_ITEM_CD);
	if(el != null){
		if (typeof G_vmlCanvasManager !== 'undefined') {
			el = G_vmlCanvasManager.initElement(el);
		}

		/* 矢印フラグ */
		var stArrowFlag = false;
		var edArrowFlag = false;
		if(crfItem.LINE_START_POINT_DIV == 1){
			stArrowFlag = true;
		}
		if(crfItem.LINE_END_POINT_DIV == 1){
			edArrowFlag = true;
		}

		/* 座標 */
		var w = crfItem.LINE_SIZE_DIV / 2 + 4;
		var h = w * 1.5;
		var _xy = new Array(crfItem.LOCATION_X,crfItem.LOCATION_Y);
		var _xy2 = new Array(crfItem.LOCATION_X2,crfItem.LOCATION_Y2);
		var stArrPos = null;
		var edArrPos = null;
		if(stArrowFlag){
			stArrPos = posArrow(ct,_xy,_xy2,w,h);
			if(stArrPos == null) stArrowFlag = false;
		}
		if(edArrowFlag){
			edArrPos = posArrow(ct,_xy2,_xy,w,h);
			if(edArrPos == null) edArrowFlag = false;
		}
		//中心
		var cxy = new Array((_xy[0] + _xy2[0]) / 2,(_xy[1] + _xy2[1]) / 2);
		//回転
		var angle = crfItem.LINE_ANGLE;
		var xy = rotatePos(_xy,cxy,angle);
		var xy2 = rotatePos(_xy2,cxy,angle);
		var l = null;
		var r = null;
		var m = null;
		if(stArrowFlag){
			l = rotatePos(stArrPos[0],cxy,angle);
			r = rotatePos(stArrPos[1],cxy,angle);
			m = rotatePos(stArrPos[2],cxy,angle);
		}
		var l2 = null;
		var r2 = null;
		var m2 = null;
		if(edArrowFlag){
			l2 = rotatePos(edArrPos[0],cxy,angle);
			r2 = rotatePos(edArrPos[1],cxy,angle);
			m2 = rotatePos(edArrPos[2],cxy,angle);
		}

		/* canvas位置・サイズ */
		var left = Math.min(xy[0],xy2[0]);
		var right = Math.max(xy[0],xy2[0]);
		var top = Math.min(xy[1],xy2[1]);
		var bottom = Math.max(xy[1],xy2[1]);
		if(stArrowFlag){
			left = Math.min(left,l[0],r[0],m[0]);
			right = Math.max(right,l[0],r[0],m[0]);
			top = Math.min(top,l[1],r[1],m[1]);
			bottom = Math.max(bottom,l[1],r[1],m[1]);
		}
		if(edArrowFlag){
			left = Math.min(left,l2[0],r2[0],m2[0]);
			right = Math.max(right,l2[0],r2[0],m2[0]);
			top = Math.min(top,l2[1],r2[1],m2[1]);
			bottom = Math.max(bottom,l2[1],r2[1],m2[1]);
		}
		setCanvasPosSize(el,left,right,top,bottom);

		/* 描画 */
		var ct = el.getContext('2d');
		if (!ct) return;

		ct.strokeStyle = toColorCode(crfItem.LINE_COLOR_DIV);
		ct.fillStyle = toColorCode(crfItem.LINE_COLOR_DIV);
		ct.lineWidth = crfItem.LINE_SIZE_DIV;
		ct.lineCap = "square";

		ct.beginPath();
		ct.moveTo(((stArrowFlag) ? m[0] : xy[0]) - left + cvBuff,((stArrowFlag) ? m[1] : xy[1]) - top + cvBuff);
		ct.lineTo(((edArrowFlag) ? m2[0] : xy2[0]) - left + cvBuff,((edArrowFlag) ? m2[1] : xy2[1]) - top + cvBuff);
		ct.stroke();

		if(stArrowFlag){
			ct.beginPath();
			ct.moveTo(l[0] - left + cvBuff, l[1] - top + cvBuff);
			ct.lineTo(xy[0] - left + cvBuff,xy[1] - top + cvBuff);
			ct.lineTo(r[0] - left + cvBuff, r[1] - top + cvBuff);
			ct.closePath();
			ct.fill();
		}
		if(edArrowFlag){
			ct.beginPath();
			ct.moveTo(l2[0] - left + cvBuff, l2[1] - top + cvBuff);
			ct.lineTo(xy2[0] - left + cvBuff,xy2[1] - top + cvBuff);
			ct.lineTo(r2[0] - left + cvBuff, r2[1] - top + cvBuff);
			ct.closePath();
			ct.fill();
		}
	}
}
function posArrow(ct,head,tail,w,h){
	var vx = head[0] - tail[0];
	var vy = head[1] - tail[1];
	var v = Math.sqrt(vx * vx + vy * vy);
	if(v == 0) return null;
	var ux = vx / v;
	var uy = vy / v;
	var l = new Array(2);
	var r = new Array(2);
	var m = new Array(2);
	l[0] = head[0] - uy * w - ux * h;
	l[1] = head[1] + ux * w - uy * h;
	r[0] = head[0] + uy * w - ux * h;
	r[1] = head[1] - ux * w - uy * h;
	m[0] = head[0] - ux * h;
	m[1] = head[1] - uy * h;
	return new Array(l,r,m);
}

function viewRect(crfItem){
	var el = $(crfItem.CRF_ITEM_CD);
	if(el != null){
		el.style.border = "solid " + crfItem.LINE_SIZE_DIV + "px " + toColorCode(crfItem.LINE_COLOR_DIV);
	}
}

function viewParen(crfItem){
	if(crfItem.LINE_SIZE_DIV == 0) return;
	var el = $(crfItem.CRF_ITEM_CD);
	if(el != null){
		if (typeof G_vmlCanvasManager !== 'undefined') {
			el = G_vmlCanvasManager.initElement(el);
		}

		/* 座標 */
		var _xy = new Array(crfItem.LOCATION_X,crfItem.LOCATION_Y);
		var _x2y =  new Array(crfItem.LOCATION_X2,crfItem.LOCATION_Y);
		var _x2y2 = new Array(crfItem.LOCATION_X2,crfItem.LOCATION_Y2);
		var _xy2 =  new Array(crfItem.LOCATION_X,crfItem.LOCATION_Y2);
		//中心
		var cxy = new Array((_xy[0] + _x2y2[0]) / 2,(_xy[1] + _x2y2[1]) / 2);
		//回転
		var angle = crfItem.LINE_ANGLE;
		var xy = rotatePos(_xy,cxy,angle);
		var x2y = rotatePos(_x2y,cxy,angle);
		var x2y2 = rotatePos(_x2y2,cxy,angle);
		var xy2 = rotatePos(_xy2,cxy,angle);

		/* canvas位置・サイズ */
		var left = Math.min(xy[0],x2y[0],x2y2[0],xy2[0]);
		var right = Math.max(xy[0],x2y[0],x2y2[0],xy2[0]);
		var top = Math.min(xy[1],x2y[1],x2y2[1],xy2[1]);
		var bottom = Math.max(xy[1],x2y[1],x2y2[1],xy2[1]);
		setCanvasPosSize(el,left,right,top,bottom);

		/* 描画 */
		var ct = el.getContext('2d');
		if (!ct) return;

		ct.strokeStyle = toColorCode(crfItem.LINE_COLOR_DIV);
		ct.lineWidth = crfItem.LINE_SIZE_DIV;
		ct.lineCap = "square";

		ct.beginPath();
		ct.moveTo(x2y[0] - left + cvBuff,x2y[1] - top + cvBuff);
		ct.lineTo(xy[0] - left + cvBuff,xy[1] - top + cvBuff);
		ct.lineTo(xy2[0] - left + cvBuff,xy2[1] - top + cvBuff);
		ct.lineTo(x2y2[0] - left + cvBuff,x2y2[1] - top + cvBuff);
		ct.stroke();
	}
}

function setColor(crfItems){
	for(var i = 0;i < crfItems.length;i++){
		var obj = crfItems[i];
		var el;
		if(obj.CRF_ITEM_DIV == 'CheckBox'){
			el = $("dm" + obj.CRF_ITEM_CD);
		}else{
			el = $(obj.CRF_ITEM_CD);
		}
		if(el != null){
			el.style.color = toColorCode(obj.FONT_COLOR_DIV);
		}
	}
}

function toColorCode(val) {
	var _color = parseInt(val);
	var color = _color.toString(16);
	return "#" + zeroFillNum(color,6);
}

function zeroFillNum(num, figures) {
	var str = String(num);
	while (str.length < figures) {
		str = "0" + str;
	}
	return str;
}

function rotatePos(p,base,deg){
	var rad = deg * Math.PI / 180;
	return new Array(((p[0] - base[0]) * Math.cos(rad) - (p[1] - base[1]) * Math.sin(rad)) + base[0],
			((p[0] - base[0]) * Math.sin(rad) + (p[1] - base[1]) * Math.cos(rad)) + base[1]);
}

function setCanvasPosSize(elCanvas,left,right,top,bottom){
	elCanvas.style.left = left - cvBuff + "px";
	elCanvas.style.top = top - cvBuff + "px";
	elCanvas.style.width = right - left + (cvBuff * 2) + "px";
	elCanvas.width = right - left + (cvBuff * 2);
	elCanvas.style.height = bottom - top + (cvBuff * 2) + "px";
	elCanvas.height = bottom - top + (cvBuff * 2);
}

var errBgColor = "#ff99ff";
function viewErr(errItems){
	if(errItems.length > 0){
		$("errmsg").style.display = "";
		var elLabel;
		var elDiv;
		for(var i = 0;i < errItems.length;i++){
			elDiv = newElement("div",null);
			elDiv.className = "errmsg";
			elLabel = document.createTextNode(errItems[i].ERR_MSG);
			elDiv.appendChild(elLabel);
			$("errmsg").appendChild(elDiv);
			document.body.style.paddingTop = $("header").clientHeight + "px";

			var elCrfItem = $(errItems[i].CRF_ITEM_GRP_CD)
			if(elCrfItem == null) continue;
			if(elCrfItem.style.visibility == "hidden"){
				elGroupItems = elCrfItem.children;
				for(var j = 0;j < elGroupItems.length;j++){
					if(elGroupItems[j].tagName == "TEXTAREA" || elGroupItems[j].tagName == "INPUT" || elGroupItems[j].tagName == "LABEL" || elGroupItems[j].tagName == "SELECT"){
						elGroupItems[j].style.backgroundColor = errBgColor;
					}
				}
			}else{
				elCrfItem.style.backgroundColor = errBgColor;
			}
		}
	}
}
function resetViewErr(){
	if($("errmsg") != null){
		removeChildElement("errmsg");
		$("errmsg").style.display = "none";
		document.body.style.paddingTop = $("header").clientHeight + "px";
	}

	if($("crf") != null){
		var elCrfItems = $("crf").children;
		for(var i = 0;i < elCrfItems.length;i++){
			if(isGroupEl(elCrfItems[i])){
				var elGroupItems = elCrfItems[i].children;
				for(var j = 0;j < elGroupItems.length;j++){
					elGroupItems[j].style.backgroundColor = "";
				}
			}else{
				elCrfItems[i].style.backgroundColor = "";
			}
		}
	}
}

function backToSearchView(){

	location.href = "../servlet/b712_wp02_result_crf";
}

function MoveToErrorView(){

	location.href = "../servlet/b790_wp02_error_html";
}


function isGroupEl(el){
	return (el.style.visibility == "hidden");
}

function isReferMode(val){
	return (val == "参照モード");
}

function br2nl(str){
	if ( isNull(str) ) return str;
	str = str.replace(/<br>/g, "\n");
	return str;
}

//メモ機能
Crf.MemoKbn = {"Kojin":1,"Rnrk":2,"ForRnrkUser":3};

Crf.prototype.getMemo = function(memoKbn,memoNo,crfItemCd,kakuninChk,centerFlag){
	if(memoNo == 0){
		if(this.lastFocusEl == null) return;
		crfItemCd = this.lastFocusEl.id.replace("dm","");
	}
	this.lastFocusEl = null;
	new Ajax.Request("../servlet/ab707_pc01_get_memo?" + this.studyId + "," + this.subjectId + "," + memoKbn + "," + memoNo,
			{
		asynchronous:false,
		method:'post',
		onSuccess:function(req){
			var obj = eval('(' + req.responseText + ')');
			if(obj.RESULT_CD == null){
				alert("メモ情報の取得ができませんでした。");
			}else{
				if(obj.RESULT_CD != Crf.ResultCd.OK){
					if(obj.RESULT_CD == Crf.ResultCd.NG){
						if(obj.ERR_MSG != null){
							alert(br2nl(obj.ERR_MSG));
						}else{
							alert("メモ情報の取得ができませんでした。");
						}
					}else{
						alert("メモ情報の取得ができませんでした。");
					}
				}else{
					viewMemoPanel(memoNo,crfItemCd,obj.MEMO_KBN,obj.MEMO,obj.CRT_USER_NM,obj.RNRK_SITE_NM,obj.RNRK_USER_ID,obj.RNRK_USERS,obj.KAKUNIN_COMMENT,kakuninChk,centerFlag);
				}
			}
		}.bind(this),
		onFailure:function(){
			alert("メモ情報の取得ができませんでした。");
		}
			});
}
function viewMemoPanel(memoNo,crfItemCd,memoKbn,memo,crtUserNm,rnrkSiteNm,rnrkUserId,rnrkUsers,kakuninComment,kakuninChk,centerFlag){
	if(memoKbn == Crf.MemoKbn.ForRnrkUser){
		$("regMemoBtn").style.display = "";
		$("delMemoBtn").style.display = "none";
		$("memo").disabled = true;
	}else{
		$("regMemoBtn").style.display = "";
		$("delMemoBtn").style.display = "";
		$("memo").disabled = false;
		$("crfItemCd").value = crfItemCd;
		$("memoKbn").value = memoKbn;
	}
	$("memo").value = memo;
	$("memoNo").value = memoNo;
	switch(Number(memoKbn)){
		case Crf.MemoKbn.Kojin:
			$("memo").className = "textarea";
			$("crtUserWrap").style.display = "none";
			$("commentWrap").style.display = "none";
			$("rnrkUserWrap").style.display = "none";
			$("kakuninWrap").style.display = "none";
			break;
		case Crf.MemoKbn.Rnrk:
			$("memo").className = "textarea";
			$("crtUserWrap").style.display = "none";
			$("commentWrap").style.display = "none";
			$("rnrkUserWrap").style.display = "";
			$("rnrkSiteNm").innerHTML = getLabelElementHtml(rnrkSiteNm);
			$("rnrkUserId").options.length = 0;
			for(var i = 0;i < rnrkUsers.length;i++){
				$("rnrkUserId").options[i] = new Option(rnrkUsers[i].RNRK_USER_NM,rnrkUsers[i].RNRK_USER_ID);
			}
			$("rnrkUserId").value = rnrkUserId;
			$("kakuninWrap").style.display = "none";
			if (kakuninComment != "" || kakuninChk == true) {
				$("commentWrap").style.display = "";
				$("memo").className = "text_comment";
				$("kakuninComment").value = kakuninComment;
				$("kakuninComment").disabled = true;
			}
			break;
		case Crf.MemoKbn.ForRnrkUser:
			$("memo").className = "text_comment";
			$("crtUserWrap").style.display = "";
			$("commentWrap").style.display = "";
			$("crtUserNm").innerHTML = getLabelElementHtml(crtUserNm);
			$("rnrkUserWrap").style.display = "none";
			$("kakuninWrap").style.display = "";
			$("kakuninComment").value = kakuninComment;
			$("kakuninChk").checked = kakuninChk;
			break;
	}
	$("memoPanel").style.display = "";
	if(centerFlag) center("memoPanel",'fixed');

	jQuery(function(){
		jQuery("#memoPanel").draggable();
	});
	jQuery("#memoPanel textarea").click(function(){
		jQuery("#memoPanel").draggable('disable');
	}).blur(function(){
		jQuery("#memoPanel").draggable('enable');
	});
}
function hideMemoPanel() {
	$("memoPanel").style.display = "none";
}

Crf.SyoriKbn = {"Save":1,"Delete":2};
Crf.prototype.regMemo = function(memoNo,crfItemCd,syoriKbn,memoKbn,memo,rnrkUserId){
//	if(!confirm("メモを" + ((syoriKbn == Crf.SyoriKbn.Save) ? "保存" : "削除") + "します。よろしいですか？")) return;
	new Ajax.Request("../servlet/ab707_pc02_reg_memo?" + this.studyId + "," + this.subjectId + "," + memoNo + "," + this.crfid + "," + encodeURIComponent(crfItemCd) + "," + syoriKbn + "," + memoKbn + "," + encodeURIComponent(memo) + "," + encodeURIComponent(rnrkUserId),
			{
		asynchronous:false,
		method:'post',
		onSuccess:function(req){
			var obj = eval('(' + req.responseText + ')');
			if(obj.RESULT_CD == null){
				alert("メモ登録処理ができませんでした。");
			}else{
				if(obj.RESULT_CD != Crf.ResultCd.OK){
					if(obj.RESULT_CD == Crf.ResultCd.NG){
						if(obj.ERR_MSG != null){
							alert(br2nl(obj.ERR_MSG));
						}else{
							alert("メモ登録処理ができませんでした。");
						}
					}else{
						alert("メモ登録処理ができませんでした。");
					}
				}else{
					if(memoNo == 0){
						addMemo(crfItemCd,memoKbn,obj.MEMO_NO);
					}
					if(syoriKbn == Crf.SyoriKbn.Save){
						alert("メモを保存しました。");
						hideMemoPanel();
//						crf.getMemo(memoKbn,obj.MEMO_NO,crfItemCd,false,false);
					}else{
						delMemo(memoNo,crfItemCd);
						alert("メモを削除しました。");
						hideMemoPanel();
					}
				}
			}
		},
		onFailure:function(){
			alert("メモ登録処理ができませんでした。");
		}
			});
}
function addMemo(crfItemCd,memoKbn,memoNo){
	var elDiv = newElement("div",{"className":"abs memo"});
	var crfItem = $(crfItemCd);
	var crfItemStyle = (crfItem.type == "radio" || crfItem.type == "hidden") ? crfItem.parentNode.style : crfItem.style;
	elDiv.style.left = (Number(crfItemStyle.left.replace("px","")) + ((crfItem.type == "radio" || crfItem.type == "hidden") ? 10 : 5)) + "px";
	elDiv.style.top = (Number(crfItemStyle.top.replace("px","")) - ((crfItem.type == "radio" || crfItem.type == "hidden") ? 7 : 10)) + "px";
	elDiv.style.width = (Number(crfItemStyle.width.replace("px","")) + 10) + "px";
	elDiv.style.textAlign = (crfItem.type == "radio" || crfItem.type == "hidden") ? "left" : "right";
	elDiv.style.visibility = crfItemStyle.visibility;
	var elImg = newElement("img",{"id":"memo" + memoNo,"src":"img/icon_memo_" + ((memoKbn == Crf.MemoKbn.Kojin) ? "kojin" : "rnrk") + ".gif","width":"20","height":"20"});
	elImg.onclick = function(){
		crf.getMemo(memoKbn,memoNo,crfItemCd,false,true);
	};
	elDiv.appendChild(elImg);
	var appendTgt = (crfItem.type == "radio" || crfItem.type == "hidden") ? crfItem.parentNode.parentNode : crfItem.parentNode;
	appendTgt.appendChild(elDiv);
	if(crfItem.type == "radio"){
		crfItem.onclick = function(){
			onRadioClick(crfItem,true,true);
		};
	}else if(crfItem.type == "hidden"){
		$("dm" + crfItemCd).onclick = function(){
			crf.lastFocusEl = null;
		};
	}else{
		crfItem.onclick = function(){
			crf.lastFocusEl = null;
		};
	}
}
function delMemo(memoNo,crfItemCd){
	if(memoNo == 0) return;
	Element.remove($("memo" + memoNo).parentNode);
	var crfItem = $(crfItemCd);
	if(crfItem.type == "radio"){
		crfItem.onclick = function(){
			onRadioClick(crfItem,true,false);
		};
	}else if(crfItem.type == "hidden"){
		$("dm" + crfItemCd).onclick = function(){
			crf.lastFocusEl = crfItem;
		};
	}else{
		crfItem.onclick = function(){
			crf.lastFocusEl = crfItem;
		};
	}
}
function onRadioClick(crfItem,memoDispFlg,memoFlg){
	if(crfItem.className == 'checked'){
		crfItem.className = '';
		crfItem.checked = false;
		if(window.navigator.taintEnabled == undefined){
			crfItem.onchange();
		}
	}else{
		crfItem.className = 'checked';
	}
	if(memoDispFlg){
		crf.lastFocusEl = (!memoFlg) ? crfItem : null;
	}
}

Crf.prototype.kanryoMemo = function(memoNo,kakuninComment,kakuninChk,crfItemCd){
	new Ajax.Request("../servlet/ab707_pc03_kanryo_memo?" + this.studyId + "," + this.subjectId + "," + memoNo + "," + encodeURIComponent(kakuninComment) + "," + kakuninChk,
			{
		asynchronous:false,
		method:'post',
		onSuccess:function(req){
			var obj = eval('(' + req.responseText + ')');
			if(obj.RESULT_CD == null){
				alert("メモ確認完了処理ができませんでした。");
			}else{
				if(obj.RESULT_CD != Crf.ResultCd.OK){
					if(obj.RESULT_CD == Crf.ResultCd.NG){
						if(obj.ERR_MSG != null){
							alert(br2nl(obj.ERR_MSG));
						}else{
							alert("メモ確認完了処理ができませんでした。");
						}
					}else{
						alert("メモ確認完了処理ができませんでした。");
					}
				}else{
					var el = $("memo" + memoNo);
					el.src = "img/icon_memo_rnrk" + ((kakuninChk == 1) ? "_k" : "") + ".gif";
					el.onclick = function(){
						crf.getMemo(Crf.MemoKbn.Rnrk,memoNo,crfItemCd,kakuninChk,true);
					};
				}
			}
		},
		onFailure:function(){
			alert("メモ確認完了処理ができませんでした。");
		}
			});

}