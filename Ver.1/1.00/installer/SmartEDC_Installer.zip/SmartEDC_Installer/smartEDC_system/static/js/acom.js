/*
	Name: ST_CLOCK
    Description: datetime_disp
*/
function ST_CLOCK() {
	var today    = new Date();
	var w_Year   = today.getFullYear();
	var w_Month  = today.getMonth()+1;
	var w_Day    = today.getDate();
	var w_Week   = today.getDay();
	var w_Hour   = today.getHours();
	var w_Minute = today.getMinutes();
	var w_Second = today.getSeconds();
	var w_We     = new Array( "日","月","火","水","木","金","土" );
	if (w_Month  < 10) w_Month  = "0" + w_Month;
	if (w_Day    < 10) w_Day    = "0" + w_Day;
	if (w_Hour   < 10) w_Hour   = "0" + w_Hour;
	if (w_Minute < 10) w_Minute = "0" + w_Minute;
	if (w_Second < 10) w_Second = "0" + w_Second;
	var Time = w_Year + "/" + w_Month + "/" + w_Day + "(" + w_We[w_Week] + ") " + w_Hour + ":" + w_Minute + ":" + w_Second;
	document.getElementById("Timer").innerHTML = Time;
	setTimeout("ST_CLOCK()", 1000);
}
/*
	Name: ST_CLICK_SPACE
    Description: space -> click
*/
function ST_CLICK_SPACE(){
	
	var elements = document.getElementsByTagName('a');
	//FF
	if(window.addEventListener)
		for(var i=0;i < elements.length; i++){
			try{
				elements[i].removeEventListener('keydown',ST_KEY_DOWN,false);
			}catch(e){}
			elements[i].addEventListener('keydown',ST_KEY_DOWN,false);
		}
	//IE
	else if(window.attachEvent)
		for(var i=0;i < elements.length; i++){
			try{
				elements[i].detachEvent("onkeydown",ST_ON_KEY_DOWN);
			}catch(e){}
			elements[i].attachEvent('onkeydown',ST_ON_KEY_DOWN);
		}
}
function ST_KEY_DOWN(e){
	if(e.keyCode == 32){
		e.preventDefault();
		if(this.onclick){
			this.onclick();
		}else{
			location.href = this.getAttribute('href');
		}
	}
	return;
}
function ST_ON_KEY_DOWN(e){
	if(event.keyCode == 32){
		event.srcElement.click();
		return false;
	}
	return true
}

document.onkeydown = function(e){
	var retVal	= true;
	if(getKEYCODE(e)==123){
		gx.evt.execEvt('W0009E\'BTN_END\'.',this);
		retVal = false;
	}
	return retVal;
}
function getKEYCODE(e){
	var ua = navigator.userAgent
	if(document.layers){
		return e.which;
	} else if(document.all){
		return event.keyCode;
	} else if(document.getElementById){
		return e.keyCode;
	} else{
		return null;
	}
}

/*
	Name: textAreaBreak
    Description: Insert_new_line
*/
if (window.addEventListener) {
	window.addEventListener('load', function(){initTextAreaBreak();}, false);
} else if (window.attachEvent) {	//for IE
	window.attachEvent('onload',function(){initTextAreaBreak();});
}

function initTextAreaBreak() {
	var elements = document.getElementsByTagName('textarea');
	//FF未対応
	if(window.addEventListener){
//		for(var i=0;i < elements.length; i++){
//			try{
//				elements[i].removeEventListener('keydown',textAreaBreak,false);
//				elements[i].removeEventListener('keypress',textAreaBreak,false);
//			}catch(e){}
//			elements[i].addEventListener('keydown',textAreaBreak,false);
//			elements[i].addEventListener('keypress',textAreaBreak,false);
//		}
	}
	//IE
	else if(window.attachEvent){
		for(var i=0;i < elements.length; i++){
			try{
				elements[i].detachEvent('onkeydown',textAreaBreak);
				elements[i].detachEvent('onkeypress',textAreaBreak);
			}catch(e){}
			elements[i].attachEvent('onkeydown',textAreaBreak);
			elements[i].attachEvent('onkeypress',textAreaBreak);
		}
	}
}

function textAreaBreak(e){
	var retVal	= true;
	var event	= (window.event == null ? e : window.event);
	//Ctrlキー + Enterキー判定
	if(event.ctrlKey && event.keyCode == 13){
		var range = getSelRange();

		if(range == null){
			return true;
		}

		insertBreak(range);

		event.cancelBubble = true;
		retVal = false;
	}
	return retVal;
}

function getSelRange(){
	var range = null;
	
	//FF未対応
	if(window.getSelection){
//		range = window.getSelection().getRangeAt(0);
	}
	//IE
	else if(document.selection && document.selection.createRange){
		range = document.selection.createRange();
	}
	
	return range;
}

function insertBreak(range){
	range.text = "\n";
	range.select();
}
