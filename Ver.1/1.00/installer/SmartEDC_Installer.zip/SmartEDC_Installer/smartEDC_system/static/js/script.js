﻿
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document;
  if(d.images){
    if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments;
    if ( a.length == 1 && isArray(a[0]) ) a = MM_preloadImages.arguments[0];
    for(i=0; i<a.length; i++) if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}
 }
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function isNull(v) {
	if ( v == null || v == undefined ) return true;
	if ( v.length == 0 ) return true;
	return false;
}

function isNotNull(v) {
	return !(isNull(v));
}

function isArray(v) {
	return ((typeof v == "object") && (v.constructor == Array));
}

function isDigit(v) {
	if ( isNull(v) ) return false;
	return (v.match(/^[0-9]+$/));
}

function isDigitWithScale(v, s) {
	if ( isNull(v) ) return false;
	var p = v.split(".");
	if ( p.length == 0 || p.length > 2 ) return false;
	if ( !isDigit(p[0]) ) return false;
	if ( p.length && isNotNull(p[1]) ) {
		if ( !isDigit(p[1]) ) return false;
		if ( p[1].length > s ) return false;
	}
	return true;
}

function isValidDate(y, m, d) {
	if ( isNaN(y) || isNaN(m) || isNaN(d) ) return false;
	var checkd = new Date(y, m - 1, d);
	return ( checkd != null && checkd.getFullYear() == y && checkd.getMonth() + 1 == m && checkd.getDate() == d );
}

function defaultStr(val, def) {
	return ( isNotNull(val) ) ? val : def;
}

function nl(val) {
	return val + "\n";
}

function findInArray(arr, val) {
	for ( var i = 0, e = arr.length; i < e; i++ ) {
		if ( arr[i] == val ) return i;
	}
	return -1;
}

function removeArray(arr, idx) {
	if ( !arr ) return;
	if ( arr.length == 0 || idx < 0 || arr.length <= idx ) return;
	var _arr = arr.slice(0, idx);
	if ( idx < arr.length - 1 ) _arr = _arr.concat(arr.slice(idx + 1));
	return _arr;
}

function openSubWin(url, name, width, height) {
	var sw = window.open(url, name, "width=" + width + ",height=" + height + ",scrollbars=yes,resizable=yes,status=yes");
	if ( sw ) sw.focus();
	return sw;
}
function openWin(url, name) {
	var sw = window.open(url, name);
	if ( sw ) sw.focus();
	return sw;
}

function newElement(elType, attr) {
	var el = document.createElement(elType);
	if ( attr != null ) {
		for ( var k in attr ) { el.setAttribute(k, attr[k]); }
		if ( (elType == 'input' || elType == 'select') && isNotNull(attr["name"]) ) el.setAttribute("id", attr["name"]);
		if ( isNotNull(attr["className"]) ) el.setAttribute("class", attr["className"]);
	}
	return el;
}

function getLabelElementHtml(labelVal) {
	var el = document.createElement("div");
	var elLabel = document.createTextNode(labelVal);
	el.appendChild(elLabel);
	return el.innerHTML;
}

function removeChildElement(elId) {
	var el = document.getElementById(elId);
	if ( !el ) return;
	var ch = el.childNodes;
	for ( var i = ch.length - 1; i >= 0; i-- ) el.removeChild(ch[i]);
}

var resizeImageClassReg = new RegExp(/^resizeImg_(\d+)_(\d+)$/);
function resizeImages() {
	for ( var i = 0, l = document.images.length; i < l; i++ ) {
		if ( isNull(document.images[i].className) ) continue;
		if ( !document.images[i].className.match(resizeImageClassReg) ) continue;
		var w = RegExp.$1;
		var h = RegExp.$2;
		if ( document.images[i].width > w || document.images[i].height > h ) {
			if ( document.images[i].width > document.images[i].height ) {
				document.images[i].width = w;
			} else {
				document.images[i].height = h;
			}
		}
		document.images[i].style.visibility = "visible";
	}
}
function loadResizeImage(url, name, maxWidth, maxHeight) {
	var img = new Image();
	img.src = url;
	img.onload = function() {
		if ( !document.images[name] ) return;
		document.images[name].src = img.src
		if ( img.width > maxWidth || img.height > maxHeight ) {
			if ( img.width > img.height ) {
				document.images[name].width = maxWidth;
			} else {
				document.images[name].height = maxHeight;
			}
		}
	};
}


function onListHeaderMouseOver(obj) {
	obj.style.backgroundColor = "#EBEFF5";
}
function onListHeaderMouseOut(obj) {
	obj.style.backgroundColor = "#ffffff";
}
function onListDataMouseOver(obj) {
	obj.style.backgroundColor = "#FCF8F9";
}
function onListDataMouseOut(obj) {
	obj.style.backgroundColor = "#ffffff";
}


function center(element,position) {
	try {
		element = document.getElementById(element);
	} catch(e){
		return;
	}
	var width = 0;
	var height = 0;
	if ( typeof( window.innerWidth ) == 'number' ) {
		width = window.innerWidth;
		height = window.innerHeight;
	} else if ( document.documentElement &&
			( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
		width = document.documentElement.clientWidth;
		height = document.documentElement.clientHeight;
	} else if ( document.body &&
			( document.body.clientWidth || document.body.clientHeight ) ) {
		width = document.body.clientWidth;
		height = document.body.clientHeight;
	}
	element.style.position = position;
	element.style.zIndex = 100001;
	var scrollY = 0;
	if ( document.documentElement && document.documentElement.scrollTop ) {
		scrollY = document.documentElement.scrollTop;
	} else if ( document.body && document.body.scrollTop ) {
		scrollY = document.body.scrollTop;
	} else if ( window.pageYOffset ) {
		scrollY = window.pageYOffset;
	} else if ( window.scrollY ) {
		scrollY = window.scrollY;
	}
	var elementDimensions = Element.getDimensions(element);
	var setX = ( width - elementDimensions.width ) / 2;
	var setY = ( height - elementDimensions.height ) / 2;
	if(position != "fixed") setY += scrollY;
	setX = ( setX < 0 ) ? 0 : setX;
	setY = ( setY < 0 ) ? 0 : setY;
	element.style.left = setX + "px";
	element.style.top = setY + "px";
	element.style.display = 'block';
}

function nl2br(val) {
	if ( isNull(val) ) return val;
	val = val.replace(/\r\n/g, "\n");
	val = val.replace(/(\r|\n)/g, "<br>");
	return val;
}

function formatYMD(ymd) {
	if ( !isNull(ymd) && ymd.length == 8 ) {
		return ymd.substr(0,4) + "/" + ymd.substr(4,2) + "/" + ymd.substr(6);
	}
	return "";
}


function onAuthError() {
	alert("一定時間操作されなかったため、ログインセッションが解除されました。\nお手数ですがログイン画面から再度ログインし直してください。");
	location.href = 'Login.do';
}
