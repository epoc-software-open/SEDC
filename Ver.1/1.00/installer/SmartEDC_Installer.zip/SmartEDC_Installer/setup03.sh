#!/bin/bash
echo "Webアプリケーションを格納するtomcatのディレクトリを入力して下さい。"
echo -n "（省略時:/usr/share/tomcat6/webapps） > "
read tomcat_dir

echo "Webアプリケーション名を入力して下さい。"
echo -n "（省略時:smartEDC_system > "
read wbeapp_name

if [ -z "$wbeapp_name" -o "$wbeapp_name" = " " ]; 
then
    wbeapp_name="smartEDC_system"
fi

echo -n "SSL対応版を設定しますか。y/n > "
read ssl_ver

if [ -z "$tomcat_dir" -o "$tomcat_dir" = " " ]; 
then
    tomcat_dir="/usr/share/tomcat6/webapps"
fi

echo "Webアプリケーションを設定中です。しばらくお待ちください。"

sed -e "s@/usr/share/tomcat6/webapps@$tomcat_dir@" ./smartEDC_system/static/ini/GXX_SYS_CONFIG.org > ./smartEDC_system/static/ini/GXX_SYS_CONFIG.INI
sed -i -e "s@smartEDC_system@$wbeapp_name@" ./smartEDC_system/static/ini/GXX_SYS_CONFIG.INI

cp -r ./smartEDC_system -T ${tomcat_dir}/${wbeapp_name}

if [ "$ssl_ver" = "y" ];
then
    rm -rf ${tomcat_dir}/${wbeapp_name}/WEB-INF/classes
    mv -f  ${tomcat_dir}/${wbeapp_name}/WEB-INF/classes_SSL $tomcat_dir/${wbeapp_name}/WEB-INF/classes
else
    rm -rf ${tomcat_dir}/${wbeapp_name}/WEB-INF/classes_SSL
fi

cp -f ./environment/client.cfg ${tomcat_dir}/${wbeapp_name}/WEB-INF/classes/client.cfg 

if [ "$?" -eq 0 ];
then
    echo -n "homeディレクトリにCSV格納ディレクトリ：EDCCSVを作成しますか。y/n > "
    read mkdir_yn
    if [ "$mkdir_yn" = "y" ];
    then 
       mkdir -p /home/EDCCSV
       chmod a+w /home/EDCCSV
    fi
    chmod a+w ${tomcat_dir}/${wbeapp_name}/PublicTempStorage
    chmod a+w ${tomcat_dir}/${wbeapp_name}/PrivateTempStorage
    chmod a+w ${tomcat_dir}/${wbeapp_name}/csv_download
    chmod a+w ${tomcat_dir}/${wbeapp_name}/csv_upload
    chmod a+w ${tomcat_dir}/${wbeapp_name}/log

    rm -f ${tomcat_dir}/${wbeapp_name}/static/ini/GXX_SYS_CONFIG.org

    echo "TomatにWebアプリケーション：${wbeapp_name}を設定しました。"
else
    echo "TomcatへのWebアプリケーション：${wbeapp_name}の設定に失敗しました。"
fi
