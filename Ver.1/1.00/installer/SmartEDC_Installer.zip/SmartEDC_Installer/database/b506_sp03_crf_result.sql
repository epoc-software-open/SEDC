drop procedure if exists b506_sp03_crf_result;
delimiter //
create procedure b506_sp03_crf_result(
		in	p_session_id	varchar(50)
	,	in	p_app_id		varchar(7)
	,	in	p_disp_datetime	varchar(14)
	,	in	p_exec_user_id	varchar(200)
	,	in	p_exec_time		datetime
	,	out	p_err_cd		tinyint
	)
begin

	declare program_name varchar(20) DEFAULT 'b506_sp03_crf_result';

	set p_err_cd = 0;

	delete from tbt12_crf_result
	where	exists(
				select	tbw04.tbw04_study_id
				from	tbw04_crf	tbw04
				where	tbw04.tbw04_session_id			= p_session_id
				and		tbw04.tbw04_app_id				= p_app_id
				and		tbw04.tbw04_disp_datetime		= p_disp_datetime
				and		tbw04.tbw04_study_id			= tbt12_study_id
				and		tbw04.tbw04_subject_id			= tbt12_subject_id
				and		tbw04.tbw04_crf_id				= tbt12_crf_id
				and		tbw04.tbw04_edit_flg			= '1'
			)
	and		not exists(
				select	tbw05.tbw05_study_id
				from	tbw05_crf_result	tbw05
				where	tbw05.tbw05_session_id			= p_session_id
				and		tbw05.tbw05_app_id				= p_app_id
				and		tbw05.tbw05_disp_datetime		= p_disp_datetime
				and		tbw05.tbw05_study_id			= tbt12_study_id
				and		tbw05.tbw05_crf_id				= tbt12_crf_id
				and		tbw05.tbw05_crf_item_grp_div	= tbt12_crf_item_grp_div
				and		tbw05.tbw05_crf_item_grp_cd		= tbt12_crf_item_grp_cd
			)
	;

	insert into tbt12_crf_result(
		tbt12_study_id
	,	tbt12_subject_id
	,	tbt12_crf_id
	,	tbt12_crf_item_grp_div
	,	tbt12_crf_item_grp_cd
	,	tbt12_crf_value
	,	tbt12_edit_flg
	,	tbt12_del_flg
	,	tbt12_crt_datetime
	,	tbt12_crt_user_id
	,	tbt12_crt_prog_nm
	,	tbt12_upd_datetime
	,	tbt12_upd_user_id
	,	tbt12_upd_prog_nm
	,	tbt12_upd_cnt
	)
	select
		tbw05.tbw05_study_id
	,	tbw05.tbw05_subject_id
	,	tbw05.tbw05_crf_id
	,	tbw05.tbw05_crf_item_grp_div
	,	tbw05.tbw05_crf_item_grp_cd
	,	tbw05.tbw05_crf_value
	,	if(tbw05.tbw05_crf_value <> ifnull(tbt13.tbt13_crf_value, ' ') and tbt02.tbt02_crf_latest_version > 0
			, '1'
			, '0'
		)
	,	'0'
	,	p_exec_time
	,	p_exec_user_id
	,	program_name
	,	p_exec_time
	,	p_exec_user_id
	,	program_name
	,	1
	from		tbw05_crf_result	tbw05
	inner join	tbw04_crf			tbw04
		on	tbw05.tbw05_session_id			= tbw04.tbw04_session_id
		and	tbw05.tbw05_app_id				= tbw04.tbw04_app_id
		and	tbw05.tbw05_disp_datetime		= tbw04.tbw04_disp_datetime
		and	tbw05.tbw05_study_id			= tbw04.tbw04_study_id
		and	tbw05.tbw05_subject_id			= tbw04.tbw04_subject_id
		and	tbw05.tbw05_crf_id				= tbw04.tbw04_crf_id
	left join	tbt02_crf			tbt02
		on	tbw05.tbw05_study_id			= tbt02.tbt02_study_id
		and	tbw05.tbw05_subject_id			= tbt02.tbt02_subject_id
		and	tbw05.tbw05_crf_id				= tbt02.tbt02_crf_id
	left join	tbt13_crf_res_his	tbt13
		on	tbw05.tbw05_study_id			= tbt13.tbt13_study_id
		and	tbw05.tbw05_subject_id			= tbt13.tbt13_subject_id
		and	tbw05.tbw05_crf_id				= tbt13.tbt13_crf_id
		and	tbt02.tbt02_crf_latest_version	= tbt13.tbt13_crf_version
		and	tbw05.tbw05_crf_item_grp_div	= tbt13.tbt13_crf_item_grp_div
		and	tbw05.tbw05_crf_item_grp_cd		= tbt13.tbt13_crf_item_grp_cd
	where	tbw05.tbw05_session_id		= p_session_id
	and		tbw05.tbw05_app_id			= p_app_id
	and		tbw05.tbw05_disp_datetime	= p_disp_datetime
	and		tbw04.tbw04_edit_flg		= '1'
	on duplicate key update
		tbt12_crf_value		= values(tbt12_crf_value)
	,	tbt12_edit_flg		= values(tbt12_edit_flg)
	,	tbt12_upd_datetime	= p_exec_time
	,	tbt12_upd_user_id	= p_exec_user_id
	,	tbt12_upd_prog_nm	= program_name
	,	tbt12_upd_cnt		= tbt12_upd_cnt + 1
	;

end
//
delimiter ;
