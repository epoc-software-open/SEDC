drop procedure if exists b506_sp04_crf_verup;
delimiter //
create procedure b506_sp04_crf_verup(
		in	p_session_id	varchar(50)
	,	in	p_app_id		varchar(7)
	,	in	p_disp_datetime	varchar(14)
	,	in	p_exec_user_id	varchar(200)
	,	in	p_exec_time		datetime
	,	out	p_err_cd		tinyint
	)
begin

	declare program_name varchar(20) DEFAULT 'b506_sp04_crf_verup';

	set p_err_cd = 0;

	update		tbt02_crf	tbt02
	inner join	tbw04_crf	tbw04
		on	tbw04.tbw04_study_id		= tbt02.tbt02_study_id
		and	tbw04.tbw04_subject_id		= tbt02.tbt02_subject_id
		and	tbw04.tbw04_crf_id			= tbt02.tbt02_crf_id
		and	tbw04.tbw04_session_id		= p_session_id
		and	tbw04.tbw04_app_id			= p_app_id
		and	tbw04.tbw04_disp_datetime	= p_disp_datetime
	set		tbt02_crf_latest_version	= tbt02_crf_latest_version + 1
	,		tbt02_upd_prog_nm			= program_name
	where	tbw04.tbw04_completion_flg	= '1'
	and		tbw04.tbw04_edit_flg		= '1'
	and		(	tbt02_crf_latest_version	= 0
			or	exists(
					select	tbt12.tbt12_study_id
					from	tbt12_crf_result tbt12
					where	tbt12.tbt12_study_id	= tbt02.tbt02_study_id
					and		tbt12.tbt12_subject_id	= tbt02.tbt02_subject_id
					and		tbt12.tbt12_crf_id		= tbt02.tbt02_crf_id
					and		tbt12_edit_flg			= '1'
				)
			or	exists(
					select	tbw06.tbw06_study_id
					from	tbw06_crf_memo tbw06
					where	tbw06.tbw06_session_id		= p_session_id
					and		tbw06.tbw06_app_id			= p_app_id
					and		tbw06.tbw06_disp_datetime	= p_disp_datetime
					and		tbw06.tbw06_study_id		= tbt02.tbt02_study_id
					and		tbw06.tbw06_subject_id		= tbt02.tbt02_subject_id
					and		tbw06.tbw06_crf_id			= tbt02.tbt02_crf_id
					and		tbw06.tbw06_proc_div		= '1'
				)
			or	exists(
					select	tbw07.tbw07_study_id
					from		tbw07_crf_memo_loc	tbw07
					inner join	tbw06_crf_memo		tbw06
						on		tbw07.tbw07_session_id		= tbw06.tbw06_session_id
						and		tbw07.tbw07_app_id			= tbw06.tbw06_app_id
						and		tbw07.tbw07_disp_datetime	= tbw06.tbw06_disp_datetime
						and		tbw07.tbw07_study_id		= tbw06.tbw06_study_id
						and		tbw07.tbw07_subject_id		= tbw06.tbw06_subject_id
						and		tbw07.tbw07_ins_no			= tbw06.tbw06_ins_no
					where	tbw07.tbw07_session_id		= p_session_id
					and		tbw07.tbw07_app_id			= p_app_id
					and		tbw07.tbw07_disp_datetime	= p_disp_datetime
					and		tbw07.tbw07_study_id		= tbt02.tbt02_study_id
					and		tbw07.tbw07_subject_id		= tbt02.tbt02_subject_id
					and		tbw07.tbw07_crf_id			= tbt02.tbt02_crf_id
					and		tbw06.tbw06_crf_id			= tbt02.tbt02_crf_id
					and		tbw06.tbw06_proc_div		= '1'
				)
			)
	;

	insert into tbt11_crf_history(
		tbt11_study_id
	,	tbt11_subject_id
	,	tbt11_crf_id
	,	tbt11_crf_version
	,	tbt11_crf_input_level
	,	tbt11_upload_datetime
	,	tbt11_upload_user_id
	,	tbt11_upload_auth_cd
	,	tbt11_dm_arrival_flg
	,	tbt11_dm_arrival_datetime
	,	tbt11_approval_flg
	,	tbt11_approval_datetime
	,	tbt11_approval_user_id
	,	tbt11_approval_auth_cd
	,	tbt11_input_end_flg
	,	tbt11_input_end_datetime
	,	tbt11_input_end_user_id
	,	tbt11_input_end_auth_cd
	,	tbt11_del_flg
	,	tbt11_crt_datetime
	,	tbt11_crt_user_id
	,	tbt11_crt_prog_nm
	,	tbt11_upd_datetime
	,	tbt11_upd_user_id
	,	tbt11_upd_prog_nm
	,	tbt11_upd_cnt
	)
	select
		tbt02.tbt02_study_id
	,	tbt02.tbt02_subject_id
	,	tbt02.tbt02_crf_id
	,	tbt02.tbt02_crf_latest_version
	,	tbt02.tbt02_crf_input_level
	,	tbt02.tbt02_upload_datetime
	,	tbt02.tbt02_upload_user_id
	,	tbt02.tbt02_upload_auth_cd
	,	tbt02.tbt02_dm_arrival_flg
	,	tbt02.tbt02_dm_arrival_datetime
	,	tbt02.tbt02_approval_flg
	,	tbt02.tbt02_approval_datetime
	,	tbt02.tbt02_approval_user_id
	,	tbt02.tbt02_approval_auth_cd
	,	tbt02.tbt02_input_end_flg
	,	tbt02.tbt02_input_end_datetime
	,	tbt02.tbt02_input_end_user_id
	,	tbt02.tbt02_input_end_auth_cd
	,	tbt02.tbt02_del_flg
	,	p_exec_time
	,	p_exec_user_id
	,	program_name
	,	p_exec_time
	,	p_exec_user_id
	,	program_name
	,	1
	from		tbt02_crf	tbt02
	inner join	tbw04_crf	tbw04
		on	tbw04.tbw04_study_id		= tbt02.tbt02_study_id
		and	tbw04.tbw04_subject_id		= tbt02.tbt02_subject_id
		and	tbw04.tbw04_crf_id			= tbt02.tbt02_crf_id
		and	tbw04.tbw04_session_id		= p_session_id
		and	tbw04.tbw04_app_id			= p_app_id
		and	tbw04.tbw04_disp_datetime	= p_disp_datetime
	where	tbw04.tbw04_completion_flg	= '1'
	and		tbw04.tbw04_edit_flg		= '1'
	and		not exists(
				select	tbt11.tbt11_study_id
				from	tbt11_crf_history	tbt11
				where	tbt11.tbt11_study_id	= tbt02.tbt02_study_id
				and		tbt11.tbt11_subject_id	= tbt02.tbt02_subject_id
				and		tbt11.tbt11_crf_id		= tbt02.tbt02_crf_id
				and		tbt11.tbt11_crf_version	= tbt02.tbt02_crf_latest_version
			)
	;

	insert into tbt13_crf_res_his(
		tbt13_study_id
	,	tbt13_subject_id
	,	tbt13_crf_id
	,	tbt13_crf_version
	,	tbt13_crf_item_grp_div
	,	tbt13_crf_item_grp_cd
	,	tbt13_crf_value
	,	tbt13_edit_flg
	,	tbt13_del_flg
	,	tbt13_crt_datetime
	,	tbt13_crt_user_id
	,	tbt13_crt_prog_nm
	,	tbt13_upd_datetime
	,	tbt13_upd_user_id
	,	tbt13_upd_prog_nm
	,	tbt13_upd_cnt
	)
	select
		tbt12.tbt12_study_id
	,	tbt12.tbt12_subject_id
	,	tbt12.tbt12_crf_id
	,	tbt02.tbt02_crf_latest_version
	,	tbt12.tbt12_crf_item_grp_div
	,	tbt12.tbt12_crf_item_grp_cd
	,	tbt12.tbt12_crf_value
	,	tbt12.tbt12_edit_flg
	,	tbt12.tbt12_del_flg
	,	p_exec_time
	,	p_exec_user_id
	,	program_name
	,	p_exec_time
	,	p_exec_user_id
	,	program_name
	,	1
	from		tbt12_crf_result	tbt12
	left join	tbt02_crf			tbt02
		on	tbt12.tbt12_study_id	= tbt02.tbt02_study_id
		and	tbt12.tbt12_subject_id	= tbt02.tbt02_subject_id
		and	tbt12.tbt12_crf_id		= tbt02.tbt02_crf_id
	inner join	tbw04_crf	tbw04
		on	tbw04.tbw04_study_id		= tbt12.tbt12_study_id
		and	tbw04.tbw04_subject_id		= tbt12.tbt12_subject_id
		and	tbw04.tbw04_crf_id			= tbt12.tbt12_crf_id
		and	tbw04.tbw04_session_id		= p_session_id
		and	tbw04.tbw04_app_id			= p_app_id
		and	tbw04.tbw04_disp_datetime	= p_disp_datetime
	where	tbw04.tbw04_completion_flg	= '1'
	and		tbw04.tbw04_edit_flg		= '1'
	and		not exists(
				select	tbt13.tbt13_study_id
				from	tbt13_crf_res_his	tbt13
				where	tbt13.tbt13_study_id			= tbt12.tbt12_study_id
				and		tbt13.tbt13_subject_id			= tbt12.tbt12_subject_id
				and		tbt13.tbt13_crf_id				= tbt12.tbt12_crf_id
				and		tbt13.tbt13_crf_version			= tbt02.tbt02_crf_latest_version
				and		tbt13.tbt13_crf_item_grp_div	= tbt12.tbt12_crf_item_grp_div
				and		tbt13.tbt13_crf_item_grp_cd		= tbt12.tbt12_crf_item_grp_cd
			)
	;

end;
//
delimiter ;
