drop function if exists b506_sf01_get_input_level;
delimiter //
create function b506_sf01_get_input_level(
		p_auth_cd	varchar(2)
	)
returns smallint
main: begin

	declare program_name	varchar(20)	default 'b506_sf01_get_input_level';

	declare w_ret_level		smallint	default 0;
	declare w_max_level		smallint	default 4;
	declare w_min_level		smallint	default 1;

	select	max(cast(tas01_item_cd as signed)),	min(cast(tas01_item_cd as signed))
	into	w_max_level,						w_min_level
	from	tas01_cdnm
	where	tas01_data_kind	= 'B01'
	and		tas01_del_flg	= '0'
	;

	select	tam04_auth_lvl + 1 into w_ret_level
	from	tam04_kngn
	where	tam04_auth_cd	= p_auth_cd
	and		tam04_del_flg	= '0'
	;

	if w_ret_level < w_min_level or w_max_level < w_ret_level then
		set w_ret_level = w_max_level;
	end if;

	return w_ret_level;

end main;
//
delimiter ;
