set NAMES utf8;
drop PROCEDURE if exists PROC_CHK_CRF;

delimiter //

CREATE PROCEDURE PROC_CHK_CRF (OUT W_ERR_CD int
					,INOUT P_STUDY_ID int
					,INOUT P_SESSION_ID varchar(50)
					,INOUT P_DATETIME DATETIME
					)

BEGIN
   DECLARE eod tinyint;
   DECLARE D_STUDY_ID text;
   DECLARE D_CRF_ID text;
   DECLARE D_CRF_ITEM_GRP_CD text;
   DECLARE D_VISIT_NO text;
   DECLARE D_DOM_CD text;
   DECLARE D_DOM_VAR_NM text;
   DECLARE D_DOM_ITM_GRP_OID text;
   DECLARE D_DOM_ITM_GRP_ROWNO text;
   DECLARE D_CRF_ITEM_DIV text;
   DECLARE D_CRF_ITEM_DIV_CD text;
   DECLARE D_VALUE text;
   DECLARE D_LIST_CD text;
   DECLARE D_DOM_CD_TBM02 text;
   DECLARE D_DOM_VAR_NM_TBM03 text;
   DECLARE D_LIST_CD_TBM26 text;
   DECLARE D_CRF_ITEM_CD text;
   DECLARE D_REF_CRF_ID text;
   DECLARE D_REF_CRF_ITEM_CD text;
   DECLARE D_CRF_ID_TBM32 text;
   DECLARE D_CRF_ITEM_CD_TBM32 text;
   DECLARE D_CNT int;
   DECLARE D_TBM32_CRF_ITEM_NM text;
 
   DECLARE D_MIN_FIXED_VALUE text;
   DECLARE D_MAX_FIXED_VALUE text;
   DECLARE D_MIN_REF_CRF_ID text;
   DECLARE D_MAX_REF_CRF_ID text;
   DECLARE D_MIN_REF_CRF_ITEM_CD text;
   DECLARE D_MAX_REF_CRF_ITEM_CD text;
   DECLARE D_CRF_INFO text;

   DECLARE WK_INIT_FLG tinyint;
   DECLARE WK_DSP_CTR_CNT int;
   DECLARE WK_DSP_CTR_CNT2 int;
   DECLARE WK_INPUT_CTR_CNT int;
   DECLARE WK_INPUT_CTR_CNT2 int;

   DECLARE WK_SEQ int;
   DECLARE WK_ERR_MSG text;

   DECLARE CNT int;
   DECLARE WK_VISIT_NO text;
   DECLARE WK_DOM_CD text;
   DECLARE WK_DOM_ITM_GRP_OID text;
   DECLARE WK_DOM_ITM_GRP_ROWNO text;
   DECLARE WK_DOM_VAR_NM text;
   DECLARE WK_VALUE text;

   DECLARE CUR_ERR_CHK CURSOR FOR
       SELECT
           T1.TBM37_STUDY_ID,
           T1.TBM37_CRF_ID,
           T2.TBM37_CRF_ITEM_GRP_CD,
           T1.TBM37_VISIT_NO,
           T1.TBM37_DOM_CD,
           T2.TBM37_DOM_VAR_NM,
           T1.TBM37_DOM_ITM_GRP_OID,
           T1.TBM37_DOM_ITM_GRP_ROWNO,
           T2.TAS01_CHAR_1,
           T2.TBM32_FIXED_VALUE,
           T2.TBM32_CRF_ITEM_DIV
       FROM
           (SELECT
               TBM37_STUDY_ID,
               TBM37_CRF_ID,
               TBM37_VISIT_NO,
               TBM37_DOM_CD,
               TBM37_DOM_ITM_GRP_OID,
               TBM37_DOM_ITM_GRP_ROWNO
           FROM
               TBM37_CRF_DOM_MAP
           WHERE TBM37_DOM_ITM_GRP_ROWNO <> 0
           AND (TBM37_DOM_CD <> 'nu' AND TBM37_DOM_CD IS NOT NULL AND Trim(TBM37_DOM_CD) <> '')
           AND (TBM37_DOM_VAR_NM <> 'null' AND TBM37_DOM_VAR_NM IS NOT NULL AND Trim(TBM37_DOM_VAR_NM) <> '')
           AND (TBM37_DEL_FLG = '0')
           AND TBM37_STUDY_ID = P_STUDY_ID
           GROUP BY
               TBM37_VISIT_NO,
               TBM37_DOM_CD,
               TBM37_DOM_ITM_GRP_OID,
               TBM37_DOM_ITM_GRP_ROWNO,
               TBM37_STUDY_ID,
               TBM37_CRF_ID
           ) as T1
           ,(
           SELECT
               TBM37_STUDY_ID,
               TBM37_CRF_ID,
               TBM37_CRF_ITEM_GRP_CD,
               TBM37_VISIT_NO,
               TBM37_DOM_CD,
               TBM37_DOM_VAR_NM,
               TBM37_DOM_ITM_GRP_OID,
               TBM37_DOM_ITM_GRP_ROWNO,
               TAS01_CHAR_1,
               TBM32_FIXED_VALUE,
               TBM32_CRF_ITEM_DIV
           FROM
               TBM37_CRF_DOM_MAP,TBM32_CRF_ITEM,TAS01_CDNM
           WHERE
               TBM37_STUDY_ID = TBM32_STUDY_ID
           AND TBM37_CRF_ID = TBM32_CRF_ID
           AND TBM37_CRF_ITEM_GRP_CD = TBM32_CRF_ITEM_CD
           AND TBM32_CRF_ITEM_DIV = TAS01_ITEM_NM
           AND TAS01_DATA_KIND = 'B06'
           AND TBM37_DOM_ITM_GRP_ROWNO = 0
           AND (TBM37_DOM_CD <> 'nu' AND TBM37_DOM_CD IS NOT NULL AND Trim(TBM37_DOM_CD) <> '')
           AND (TBM37_DOM_VAR_NM <> 'null' AND TBM37_DOM_VAR_NM IS NOT NULL AND Trim(TBM37_DOM_VAR_NM) <> '')
           AND (TBM37_DEL_FLG = '0')
           AND (TBM32_DEL_FLG = '0')
           AND (TAS01_DEL_FLG = '0')
           ) as T2,
           TBM31_CRF
       WHERE
           T1.TBM37_STUDY_ID = T2.TBM37_STUDY_ID
       AND T1.TBM37_CRF_ID = T2.TBM37_CRF_ID
       AND T1.TBM37_VISIT_NO = T2.TBM37_VISIT_NO
       AND T1.TBM37_DOM_CD = T2.TBM37_DOM_CD
       AND T1.TBM37_DOM_ITM_GRP_OID = T2.TBM37_DOM_ITM_GRP_OID
       AND (T2.TBM37_VISIT_NO IS NOT NULL AND Trim(T2.TBM37_VISIT_NO) <> '')
       AND (T2.TBM37_DOM_CD IS NOT NULL AND Trim(T2.TBM37_DOM_CD) <> '')
       AND (T2.TBM37_DOM_VAR_NM IS NOT NULL AND Trim(T2.TBM37_DOM_VAR_NM) <> '')
       AND (T2.TBM37_DOM_ITM_GRP_OID IS NOT NULL AND Trim(T2.TBM37_DOM_ITM_GRP_OID) <> '')
       AND (T2.TBM37_DOM_ITM_GRP_ROWNO IS NOT NULL AND Trim(T2.TBM37_DOM_ITM_GRP_ROWNO) <> '')
       AND T1.TBM37_STUDY_ID = TBM31_STUDY_ID
       AND T1.TBM37_CRF_ID = TBM31_CRF_ID
       AND TBM31_STATUS <> '9'
       AND (TBM31_DEL_FLG = '0')
   UNION
       SELECT
           TBM37_STUDY_ID,
           TBM37_CRF_ID,
           TBM37_CRF_ITEM_GRP_CD,
           TBM37_VISIT_NO,
           TBM37_DOM_CD,
           TBM37_DOM_VAR_NM,
           TBM37_DOM_ITM_GRP_OID,
           TBM37_DOM_ITM_GRP_ROWNO,
           TAS01_CHAR_1,
           TBM32_FIXED_VALUE,
           TBM32_CRF_ITEM_DIV
       FROM
           TBM37_CRF_DOM_MAP,TBM32_CRF_ITEM,TAS01_CDNM,TBM31_CRF
       WHERE
           TBM37_STUDY_ID = TBM32_STUDY_ID
       AND TBM37_CRF_ID = TBM32_CRF_ID
       AND TBM37_CRF_ITEM_GRP_CD = TBM32_CRF_ITEM_CD
       AND TBM32_CRF_ITEM_DIV = TAS01_ITEM_NM
       AND TAS01_DATA_KIND = 'B06'
       AND TBM37_DOM_ITM_GRP_ROWNO <> 0
       AND TBM37_STUDY_ID = P_STUDY_ID
       AND (TBM37_DOM_CD <> 'nu' AND TBM37_DOM_CD IS NOT NULL AND Trim(TBM37_DOM_CD) <> '')
       AND (TBM37_DOM_VAR_NM <> 'null' AND TBM37_DOM_VAR_NM IS NOT NULL AND Trim(TBM37_DOM_VAR_NM) <> '')
       AND (TBM37_DEL_FLG = '0')
       AND (TBM32_DEL_FLG = '0')
       AND (TAS01_DEL_FLG = '0')
       AND (TBM37_VISIT_NO IS NOT NULL AND Trim(TBM37_VISIT_NO) <> '')
       AND (TBM37_DOM_CD IS NOT NULL AND Trim(TBM37_DOM_CD) <> '')
       AND (TBM37_DOM_VAR_NM IS NOT NULL AND Trim(TBM37_DOM_VAR_NM) <> '')
       AND (TBM37_DOM_ITM_GRP_OID IS NOT NULL AND Trim(TBM37_DOM_ITM_GRP_OID) <> '')
       AND (TBM37_DOM_ITM_GRP_ROWNO IS NOT NULL AND Trim(TBM37_DOM_ITM_GRP_ROWNO) <> '')
       AND TBM37_STUDY_ID = TBM31_STUDY_ID
       AND TBM37_CRF_ID = TBM31_CRF_ID
       AND TBM31_STATUS <> '9'
       AND (TBM31_DEL_FLG = '0')
   ORDER BY TBM37_VISIT_NO,TBM37_DOM_CD,TBM37_DOM_ITM_GRP_OID,TBM37_DOM_ITM_GRP_ROWNO,TBM37_DOM_VAR_NM,TBM37_STUDY_ID,TBM37_CRF_ID;

   DECLARE CUR_DOM_CHK CURSOR FOR
   SELECT
       TBM37_STUDY_ID,
       TBM37_CRF_ID,
       TBM37_CRF_ITEM_GRP_CD,
       TBM37_DOM_CD,
       TBM37_DOM_VAR_NM,
       TBM42_DOM_CD,
       TBM43_DOM_VAR_NM,
       TBM32_CRF_ITEM_NM
   FROM
             TBM37_CRF_DOM_MAP
   left join TBM42_STUDY_CDISC_DOMAIN
       on  TBM37_STUDY_ID   = TBM42_STUDY_ID
       and TBM37_DOM_CD     = TBM42_DOM_CD
       and TBM42_DEL_FLG = '0'
   left join TBM43_STUDY_CDISC_ITEM
       on  TBM37_STUDY_ID   = TBM43_STUDY_ID
       and TBM37_DOM_CD     = TBM43_DOM_CD
       and TBM37_DOM_VAR_NM = TBM43_DOM_VAR_NM
       and TBM43_DEL_FLG    = '0'
   left join TBM32_CRF_ITEM
       on  TBM37_STUDY_ID        = TBM32_STUDY_ID
       and TBM37_CRF_ID          = TBM32_CRF_ID
       and TBM37_CRF_ITEM_GRP_CD = TBM32_CRF_ITEM_CD
   ,         TBM31_CRF
   WHERE
       TBM37_STUDY_ID = P_STUDY_ID
   AND (TBM37_DEL_FLG = '0')
   AND (TBM37_DOM_CD <> 'nu' AND TBM37_DOM_CD IS NOT NULL AND Trim(TBM37_DOM_CD) <> '')
   AND (TBM37_DOM_VAR_NM <> 'null' AND TBM37_DOM_VAR_NM IS NOT NULL AND Trim(TBM37_DOM_VAR_NM) <> '')
   AND TBM37_STUDY_ID = TBM31_STUDY_ID
   AND TBM37_CRF_ID = TBM31_CRF_ID
   AND TBM31_STATUS <> '9'
   AND (TBM31_DEL_FLG = '0')
   ORDER BY TBM37_DOM_CD,TBM37_DOM_VAR_NM;

   DECLARE CUR_GRP_CHK CURSOR FOR
   SELECT DISTINCT
       T1.TBM32_STUDY_ID,
       T1.TBM32_CRF_ID,
       T1.TBM32_CRF_ITEM_CD,
       T1.TBM32_CRF_ITEM_GRP_CD,
       T1.TBM32_CRF_ITEM_DIV,
       T1.TBM32_LIST_CD,
       TBM26_LIST_CD,
       T1.TBM32_CRF_ITEM_NM
   FROM
       TBM32_CRF_ITEM T1 left join TBM26_SEL_LIST_ITEM ON TBM32_STUDY_ID = TBM26_STUDY_ID AND TBM32_LIST_CD = TBM26_LIST_CD,
       (SELECT
           TBM32_STUDY_ID,
           TBM32_CRF_ID,
           TBM32_CRF_ITEM_GRP_CD
       FROM
           TBM32_CRF_ITEM
       WHERE
           TBM32_STUDY_ID = P_STUDY_ID
       AND TBM32_CRF_ITEM_DIV = 'RadioBox'
       AND (TBM32_DEL_FLG = '0')
       ORDER BY TBM32_STUDY_ID,TBM32_CRF_ID,TBM32_CRF_ITEM_GRP_CD) T2,
       TBM31_CRF
   WHERE
       T1.TBM32_CRF_ITEM_DIV = 'Group'
   AND T1.TBM32_STUDY_ID = T2.TBM32_STUDY_ID
   AND T1.TBM32_CRF_ID = T2.TBM32_CRF_ID
   AND T1.TBM32_CRF_ITEM_GRP_CD = T2.TBM32_CRF_ITEM_GRP_CD
   AND (T1.TBM32_DEL_FLG = '0')
   AND T1.TBM32_STUDY_ID = TBM31_STUDY_ID
   AND T1.TBM32_CRF_ID = TBM31_CRF_ID
   AND TBM31_STATUS <> '9'
   AND (TBM31_DEL_FLG = '0');

   DECLARE CUR_BOX_CHK CURSOR FOR
   SELECT    DISTINCT
       TBM37_STUDY_ID,
       TBM37_CRF_ID,
       TBM37_CRF_ITEM_GRP_CD,
       TBM32_CRF_ITEM_DIV,
       TBM32_LIST_CD,
       TBM32_CHK_TRUE_INNER_VALUE,
       TBM26_LIST_CD,
       TBM32_CRF_ITEM_NM
   FROM
       TBM37_CRF_DOM_MAP,
       TBM32_CRF_ITEM left join TBM26_SEL_LIST_ITEM on TBM32_STUDY_ID = TBM26_STUDY_ID and TBM32_LIST_CD = TBM26_LIST_CD and (TBM26_DEL_FLG = '0'),
       TBM31_CRF
   WHERE
       TBM37_STUDY_ID = TBM32_STUDY_ID
   AND TBM37_CRF_ID = TBM32_CRF_ID
   AND TBM37_CRF_ITEM_GRP_CD = TBM32_CRF_ITEM_CD
   AND TBM37_STUDY_ID = P_STUDY_ID
   AND (TBM32_CRF_ITEM_DIV = 'SelectBox' or TBM32_CRF_ITEM_DIV = 'RadioBox' or TBM32_CRF_ITEM_DIV = 'CheckBox')
   AND (TBM37_DEL_FLG = '0')
   AND (TBM32_DEL_FLG = '0')
   AND TBM37_STUDY_ID = TBM31_STUDY_ID
   AND TBM37_CRF_ID = TBM31_CRF_ID
   AND TBM31_STATUS <> '9'
   AND (TBM31_DEL_FLG = '0');

   DECLARE CUR_CRFREF_CHK CURSOR FOR
   SELECT
       T2.TBM32_STUDY_ID,
       T2.TBM32_CRF_ID,
       T2.TBM32_CRF_ITEM_CD,
       T2.TBM32_REF_CRF_ID,
       T2.TBM32_REF_CRF_ITEM_CD,
       T3.TBM32_CRF_ID,
       T3.TBM32_CRF_ITEM_CD,
       T3.TBM32_CRF_ITEM_DIV,
       T3.TAS01_CHAR_3,
       (SELECT
           COUNT(*)
       FROM
           TBM32_CRF_ITEM
       WHERE
           (TBM32_DEL_FLG = '0')
       AND TBM32_STUDY_ID = T2.TBM32_STUDY_ID
       AND TBM32_CRF_ID = T2.TBM32_REF_CRF_ID) as CNT,
       T2.TBM32_CRF_ITEM_NM
   FROM
       TBM32_CRF_ITEM T2 left join
       (SELECT
           TBM32_STUDY_ID,
           TBM32_CRF_ID,
           TBM32_CRF_ITEM_CD,
           TBM32_CRF_ITEM_DIV,
           TAS01_CHAR_3
       FROM
           TBM32_CRF_ITEM,TAS01_CDNM
       WHERE
           (TBM32_DEL_FLG = '0')
       AND TBM32_STUDY_ID = P_STUDY_ID
       AND TAS01_DATA_KIND = 'B06'
       AND TAS01_ITEM_NM = TBM32_CRF_ITEM_DIV
       AND TAS01_DEL_FLG = '0'
       ORDER BY TBM32_STUDY_ID,TBM32_CRF_ID,TBM32_CRF_ITEM_CD) T3 on T2.TBM32_STUDY_ID = T3.TBM32_STUDY_ID
                                                                 AND T2.TBM32_REF_CRF_ID = T3.TBM32_CRF_ID
                                                                 AND T2.TBM32_REF_CRF_ITEM_CD = T3.TBM32_CRF_ITEM_CD,
       TBM31_CRF
   WHERE
       (T2.TBM32_REF_CRF_ID IS NOT NULL AND Trim(T2.TBM32_REF_CRF_ID) <> '')
   AND (T2.TBM32_DEL_FLG = '0')
   AND T2.TBM32_STUDY_ID = P_STUDY_ID
   AND T2.TBM32_STUDY_ID = TBM31_STUDY_ID
   AND T2.TBM32_CRF_ID = TBM31_CRF_ID
   AND TBM31_STATUS <> '9'
   AND (TBM31_DEL_FLG = '0');

   DECLARE CUR_DOM_DEFF_CHK CURSOR FOR
	SELECT
		TBM37.TBM37_VISIT_NO,
		TBM37.TBM37_DOM_CD,
		TBM37.TBM37_DOM_VAR_NM,
		TBM37.TBM37_DOM_ITM_GRP_OID,
		TBM37.TBM37_DOM_ITM_GRP_ROWNO,
		MIN(TBM32.TBM32_FIXED_VALUE)		AS MIN_FIXED_VALUE,
		MAX(TBM32.TBM32_FIXED_VALUE)		AS MAX_FIXED_VALUE,
		MIN(TBM32.TBM32_REF_CRF_ID)			AS MIN_CRF_ID,
		MAX(TBM32.TBM32_REF_CRF_ID)			AS MAX_CRF_ID,
		MIN(TBM32.TBM32_REF_CRF_ITEM_CD)	AS MIN_CRF_ITEM_CD,
		MAX(TBM32.TBM32_REF_CRF_ITEM_CD)	AS MAX_CRF_ITEM_CD,
		GROUP_CONCAT(CONCAT(TBM37.TBM37_CRF_ID, '_', TBM37.TBM37_CRF_ITEM_GRP_CD) SEPARATOR ' / ') AS CRF_INFO
	FROM
				TBM37_CRF_DOM_MAP	TBM37
	INNER JOIN	TBM32_CRF_ITEM		TBM32
		ON	TBM37.TBM37_STUDY_ID		= TBM32.TBM32_STUDY_ID
		AND	TBM37.TBM37_CRF_ID			= TBM32.TBM32_CRF_ID
		AND	TBM37.TBM37_CRF_ITEM_GRP_CD	= TBM32.TBM32_CRF_ITEM_CD
	INNER JOIN	TAS01_CDNM			TAS01
		ON	TBM32.TBM32_CRF_ITEM_DIV	= TAS01.TAS01_ITEM_NM
		AND	'B06'						= TAS01.TAS01_DATA_KIND
		AND	TAS01.TAS01_CHAR_1			<> '1'
	WHERE	TBM37.TBM37_STUDY_ID = P_STUDY_ID
	  AND	TBM37.TBM37_DOM_CD IS NOT NULL
	  AND	TRIM(TBM37.TBM37_DOM_CD) <> ''
	  AND	TBM37.TBM37_DOM_VAR_NM IS NOT NULL
	  AND	TRIM(TBM37.TBM37_DOM_VAR_NM) <> ''
	  AND	TBM37.TBM37_DEL_FLG = '0'
	  AND	TBM32.TBM32_DEL_FLG = '0'
	GROUP BY TBM37.TBM37_STUDY_ID,
			 TBM37.TBM37_VISIT_NO,
			 TBM37.TBM37_DOM_CD,
			 TBM37.TBM37_DOM_VAR_NM,
			 TBM37.TBM37_DOM_ITM_GRP_OID,
			 TBM37.TBM37_DOM_ITM_GRP_ROWNO;
   
   DECLARE continue handler for not found set eod = 1;

   set eod = 0;
   set W_ERR_CD = 0;
   set CNT = 0;
   set WK_INIT_FLG = 0;
   set WK_INPUT_CTR_CNT = 0;
   set WK_SEQ = 0;
   set WK_INPUT_CTR_CNT = 0;
   set WK_DSP_CTR_CNT = 0;
   set WK_INPUT_CTR_CNT2 = 0;
   set WK_DSP_CTR_CNT2 = 0;


   OPEN CUR_ERR_CHK;
   FETCH CUR_ERR_CHK INTO D_STUDY_ID, D_CRF_ID, D_CRF_ITEM_GRP_CD, D_VISIT_NO, D_DOM_CD,D_DOM_VAR_NM, D_DOM_ITM_GRP_OID, D_DOM_ITM_GRP_ROWNO, D_CRF_ITEM_DIV_CD, D_VALUE ,D_CRF_ITEM_DIV;
   while eod = 0 do

       IF (WK_INIT_FLG <> 0)
       AND (WK_VISIT_NO <> D_VISIT_NO
       OR WK_DOM_CD <> D_DOM_CD
       OR WK_DOM_ITM_GRP_OID <> D_DOM_ITM_GRP_OID
       OR WK_DOM_ITM_GRP_ROWNO <> D_DOM_ITM_GRP_ROWNO) then
           IF WK_INPUT_CTR_CNT2 = 0 and WK_DSP_CTR_CNT2 > 0 then
               Set WK_SEQ = WK_SEQ + 1;
               Set WK_ERR_MSG = CONCAT('VISIT番号＝[',WK_VISIT_NO,']、ドメインコード＝[',WK_DOM_CD,']、項目グループOID＝[',WK_DOM_ITM_GRP_OID,']、行番号＝[',WK_DOM_ITM_GRP_ROWNO,']に該当する部品の中に入力系部品が含まれておりません。');
               INSERT INTO TBW12_CRF_ERR_MSG VALUES
                   (P_SESSION_ID,
                   P_DATETIME,
                   WK_SEQ,
                   5,
                   2,
                   WK_ERR_MSG);
           END IF;
           Set WK_INPUT_CTR_CNT2 = 0;
           Set WK_DSP_CTR_CNT2 = 0;

           IF D_CRF_ITEM_DIV_CD = '1' then
               IF D_CRF_ITEM_DIV <> 'RadioBox' then
                   Set WK_INPUT_CTR_CNT2 = WK_INPUT_CTR_CNT2 + 1;
               END IF;
           ELSE
               Set WK_DSP_CTR_CNT2 = WK_DSP_CTR_CNT2 + 1;
           END IF;
       ELSE
           IF D_CRF_ITEM_DIV_CD = '1' then
               IF D_CRF_ITEM_DIV <> 'RadioBox' then
                   Set WK_INPUT_CTR_CNT2 = WK_INPUT_CTR_CNT2 + 1;
               END IF;
           ELSE
               Set WK_DSP_CTR_CNT2 = WK_DSP_CTR_CNT2 + 1;
           END IF;
       END IF;

       IF (WK_INIT_FLG <> 0)
       AND (WK_VISIT_NO <> D_VISIT_NO
       OR WK_DOM_CD <> D_DOM_CD
       OR WK_DOM_ITM_GRP_OID <> D_DOM_ITM_GRP_OID
       OR WK_DOM_ITM_GRP_ROWNO <> D_DOM_ITM_GRP_ROWNO
       OR WK_DOM_VAR_NM <> D_DOM_VAR_NM) then
           Set WK_INPUT_CTR_CNT = 0;
           Set WK_DSP_CTR_CNT = 0;

           IF D_CRF_ITEM_DIV_CD = '1' then
               Set WK_INPUT_CTR_CNT = WK_INPUT_CTR_CNT + 1;
           ELSE
               Set WK_DSP_CTR_CNT = WK_DSP_CTR_CNT + 1;
           END IF;
       ELSE
           IF D_CRF_ITEM_DIV_CD = '1' then
               IF D_CRF_ITEM_DIV <> 'RadioBox' then
                   Set WK_INPUT_CTR_CNT = WK_INPUT_CTR_CNT + 1;
               END IF;
           ELSE
               Set WK_DSP_CTR_CNT = WK_DSP_CTR_CNT + 1;
           END IF;

           IF WK_INPUT_CTR_CNT >= 2 then
               Set W_ERR_CD = 1;
               Set WK_SEQ = WK_SEQ + 1;
               Set WK_ERR_MSG = CONCAT('VISIT番号＝[',D_VISIT_NO,']、ドメインコード＝[',D_DOM_CD,']、項目グループOID＝[',D_DOM_ITM_GRP_OID,']、行番号＝[',D_DOM_ITM_GRP_ROWNO,']、ドメイン変数名＝[',D_DOM_VAR_NM,']に該当する一覧の中に入力系部品が複数存在します。');
               INSERT INTO TBW12_CRF_ERR_MSG VALUES
                   (P_SESSION_ID,
                   P_DATETIME,
                   WK_SEQ,
                   3,
                   1,
                   WK_ERR_MSG);
           END IF;
       END IF;

       Set WK_INIT_FLG = 1;

       Set WK_VISIT_NO = D_VISIT_NO;
       Set WK_DOM_CD = D_DOM_CD;
       Set WK_DOM_ITM_GRP_OID = D_DOM_ITM_GRP_OID;
       Set WK_DOM_ITM_GRP_ROWNO = D_DOM_ITM_GRP_ROWNO;
       Set WK_DOM_VAR_NM = D_DOM_VAR_NM;
       Set WK_VALUE = D_VALUE;

       FETCH CUR_ERR_CHK INTO D_STUDY_ID, D_CRF_ID, D_CRF_ITEM_GRP_CD, D_VISIT_NO, D_DOM_CD,D_DOM_VAR_NM, D_DOM_ITM_GRP_OID, D_DOM_ITM_GRP_ROWNO, D_CRF_ITEM_DIV_CD, D_VALUE ,D_CRF_ITEM_DIV;

   end while;
   CLOSE CUR_ERR_CHK;

   set eod = 0;
   OPEN CUR_DOM_CHK;
   FETCH CUR_DOM_CHK INTO D_STUDY_ID, D_CRF_ID, D_CRF_ITEM_GRP_CD, D_DOM_CD, D_DOM_VAR_NM, D_DOM_CD_TBM02, D_DOM_VAR_NM_TBM03, D_TBM32_CRF_ITEM_NM;
   while eod = 0 do
       IF D_DOM_CD_TBM02 IS NULL then
           Set W_ERR_CD = 1;
           Set WK_SEQ = WK_SEQ + 1;
           Set WK_ERR_MSG = CONCAT('[',D_CRF_ID,'].[',D_CRF_ITEM_GRP_CD,'(',D_TBM32_CRF_ITEM_NM,')]に指定されているドメインコードが正しくありません。');
           INSERT INTO TBW12_CRF_ERR_MSG VALUES
               (P_SESSION_ID,
               P_DATETIME,
               WK_SEQ,
               1,
               1,
               WK_ERR_MSG);
       ELSE
           IF D_DOM_VAR_NM_TBM03 IS NULL then
               Set W_ERR_CD = 1;
               Set WK_SEQ = WK_SEQ + 1;
               Set WK_ERR_MSG = CONCAT('[',D_CRF_ID,'].[',D_CRF_ITEM_GRP_CD,'(',D_TBM32_CRF_ITEM_NM,')]に指定されているドメイン変数名が正しくありません。');
               INSERT INTO TBW12_CRF_ERR_MSG VALUES
                   (P_SESSION_ID,
                   P_DATETIME,
                   WK_SEQ,
                   2,
                   1,
                   WK_ERR_MSG);
           END IF;
       END IF;
       FETCH CUR_DOM_CHK INTO D_STUDY_ID, D_CRF_ID, D_CRF_ITEM_GRP_CD, D_DOM_CD, D_DOM_VAR_NM, D_DOM_CD_TBM02, D_DOM_VAR_NM_TBM03, D_TBM32_CRF_ITEM_NM;

   end while;
   CLOSE CUR_DOM_CHK;

   set eod = 0;
   OPEN CUR_GRP_CHK;
   FETCH CUR_GRP_CHK INTO D_STUDY_ID, D_CRF_ID, D_CRF_ITEM_CD, D_CRF_ITEM_GRP_CD, D_CRF_ITEM_DIV, D_LIST_CD, D_LIST_CD_TBM26, D_TBM32_CRF_ITEM_NM;
   while eod = 0 do
       IF D_LIST_CD Is NULL then
           Set W_ERR_CD = 1;
           Set WK_SEQ = WK_SEQ + 1;
           Set WK_ERR_MSG = CONCAT('[',D_CRF_ID,'].[',D_CRF_ITEM_CD,'(',D_TBM32_CRF_ITEM_NM,')]に指定されている選択リストコードが設定されていないか正しくありません。');
           INSERT INTO TBW12_CRF_ERR_MSG VALUES
               (P_SESSION_ID,
               P_DATETIME,
               WK_SEQ,
               9,
               1,
               WK_ERR_MSG);
       ELSE
           IF D_LIST_CD_TBM26 IS NULL then
               Set W_ERR_CD = 1;
               Set WK_SEQ = WK_SEQ + 1;
               Set WK_ERR_MSG = CONCAT('[',D_CRF_ID,'].[',D_CRF_ITEM_CD,'(',D_TBM32_CRF_ITEM_NM,')]に指定されている選択リストコードが設定されていないか正しくありません。');
               INSERT INTO TBW12_CRF_ERR_MSG VALUES
                   (P_SESSION_ID,
                   P_DATETIME,
                   WK_SEQ,
                   9,
                   1,
                   WK_ERR_MSG);
           END IF;
       END IF;
       FETCH CUR_GRP_CHK INTO D_STUDY_ID, D_CRF_ID, D_CRF_ITEM_CD, D_CRF_ITEM_GRP_CD, D_CRF_ITEM_DIV, D_LIST_CD, D_LIST_CD_TBM26, D_TBM32_CRF_ITEM_NM;
   end while;
   CLOSE CUR_GRP_CHK;

   set eod = 0;
   OPEN CUR_BOX_CHK;
   FETCH CUR_BOX_CHK INTO D_STUDY_ID, D_CRF_ID, D_CRF_ITEM_GRP_CD, D_CRF_ITEM_DIV, D_LIST_CD, D_VALUE, D_LIST_CD_TBM26, D_TBM32_CRF_ITEM_NM;
   while eod = 0 do

       IF D_CRF_ITEM_DIV = 'SelectBox' then
           IF D_LIST_CD IS NULL or D_LIST_CD = '@Null' or Trim(D_LIST_CD) = '' then
               Set W_ERR_CD = 1;
               Set WK_SEQ = WK_SEQ + 1;
               Set WK_ERR_MSG = CONCAT('[',D_CRF_ID,'].[',D_CRF_ITEM_GRP_CD,'(',D_TBM32_CRF_ITEM_NM,')]に指定されている選択リストコードが設定されていないか正しくありません。');
               INSERT INTO TBW12_CRF_ERR_MSG VALUES
                   (P_SESSION_ID,
                   P_DATETIME,
                   WK_SEQ,
                   8,
                   1,
                   WK_ERR_MSG);
           ELSE
               IF D_LIST_CD_TBM26 IS NULL then
                   Set W_ERR_CD = 1;
                   Set WK_SEQ = WK_SEQ + 1;
                   Set WK_ERR_MSG = CONCAT('[',D_CRF_ID,'].[',D_CRF_ITEM_GRP_CD,'(',D_TBM32_CRF_ITEM_NM,')]に指定されている選択リストコードが設定されていないか正しくありません。');
                   INSERT INTO TBW12_CRF_ERR_MSG VALUES
                       (P_SESSION_ID,
                       P_DATETIME,
                       WK_SEQ,
                       8,
                       1,
                       WK_ERR_MSG);
               END IF;
           END IF;
       END IF;

       IF D_CRF_ITEM_DIV = 'RadioBox' then
           IF D_VALUE = '@Null' or D_VALUE IS NULL or Trim(D_VALUE) = '' then
               Set W_ERR_CD = 1;
               Set WK_SEQ = WK_SEQ + 1;
               Set WK_ERR_MSG = CONCAT('[',D_CRF_ID,'].[',D_CRF_ITEM_GRP_CD,'(',D_TBM32_CRF_ITEM_NM,')]に内部固定値が設定されていません。');
               INSERT INTO TBW12_CRF_ERR_MSG VALUES
                   (P_SESSION_ID,
                   P_DATETIME,
                   WK_SEQ,
                   10,
                   1,
                   WK_ERR_MSG);
           END IF;
       END IF;

       IF D_CRF_ITEM_DIV = 'CheckBox' then
           IF D_VALUE = '@Null' or D_VALUE IS NULL or Trim(D_VALUE) = '' then
               Set W_ERR_CD = 1;
               Set WK_SEQ = WK_SEQ + 1;
               Set WK_ERR_MSG = CONCAT('[',D_CRF_ID,'].[',D_CRF_ITEM_GRP_CD,'(',D_TBM32_CRF_ITEM_NM,')]に内部固定値が設定されていません。');
               INSERT INTO TBW12_CRF_ERR_MSG VALUES
                   (P_SESSION_ID,
                   P_DATETIME,
                   WK_SEQ,
                   11,
                   1,
                   WK_ERR_MSG);
           END IF;
       END IF;

       FETCH CUR_BOX_CHK INTO D_STUDY_ID, D_CRF_ID, D_CRF_ITEM_GRP_CD, D_CRF_ITEM_DIV, D_LIST_CD, D_VALUE, D_LIST_CD_TBM26, D_TBM32_CRF_ITEM_NM;
   end while;
   CLOSE CUR_BOX_CHK;

   set eod = 0;
   OPEN CUR_CRFREF_CHK;
   FETCH CUR_CRFREF_CHK INTO D_STUDY_ID, D_CRF_ID, D_CRF_ITEM_CD, D_REF_CRF_ID, D_REF_CRF_ITEM_CD, D_CRF_ID_TBM32, D_CRF_ITEM_CD_TBM32, D_CRF_ITEM_DIV, D_CRF_ITEM_DIV_CD, D_CNT, D_TBM32_CRF_ITEM_NM;
   while eod = 0 do

       IF D_REF_CRF_ID <> 0 then
           IF D_REF_CRF_ITEM_CD IS NULL or D_REF_CRF_ITEM_CD = '@Null' then
               Set W_ERR_CD = 1;
               Set WK_SEQ = WK_SEQ + 1;
               Set WK_ERR_MSG = CONCAT('[',D_CRF_ID,'].[',D_CRF_ITEM_CD,'(',D_TBM32_CRF_ITEM_NM,')]に参照先CRF項目コードが設定されていないか正しくありません。');
               INSERT INTO TBW12_CRF_ERR_MSG VALUES
                   (P_SESSION_ID,
                   P_DATETIME,
                   WK_SEQ,
                   7,
                   1,
                   WK_ERR_MSG);
           ELSE
               IF D_CNT = 0 then
                   Set W_ERR_CD = 1;
                   Set WK_SEQ = WK_SEQ + 1;
                   Set WK_ERR_MSG = CONCAT('[',D_CRF_ID,'].[',D_CRF_ITEM_CD,'(',D_TBM32_CRF_ITEM_NM,')]に指定されている参照先CRFIDが存在しないか有効ではありません。');
                   INSERT INTO TBW12_CRF_ERR_MSG VALUES
                       (P_SESSION_ID,
                       P_DATETIME,
                       WK_SEQ,
                       6,
                       1,
                       WK_ERR_MSG);
               ELSE
                   IF D_CNT <> 0 and D_CRF_ITEM_CD_TBM32 IS NULL then
                       Set W_ERR_CD = 1;
                       Set WK_SEQ = WK_SEQ + 1;
                       Set WK_ERR_MSG = CONCAT('[',D_CRF_ID,'].[',D_CRF_ITEM_CD,'(',D_TBM32_CRF_ITEM_NM,')]に参照先CRF項目コードが設定されていないか正しくありません。');
                       INSERT INTO TBW12_CRF_ERR_MSG VALUES
                           (P_SESSION_ID,
                           P_DATETIME,
                           WK_SEQ,
                           7,
                           1,
                           WK_ERR_MSG);
                   ELSE
                       IF D_CRF_ITEM_DIV_CD = '1' then
                           Set W_ERR_CD = 1;
                           Set WK_SEQ = WK_SEQ + 1;
                           Set WK_ERR_MSG = CONCAT('[',D_CRF_ID,'].[',D_CRF_ITEM_CD,'(',D_TBM32_CRF_ITEM_NM,')]：参照先[',D_REF_CRF_ID,'].[',D_REF_CRF_ITEM_CD,'].[',D_CRF_ITEM_DIV,']を参照先に指定することはできません。');
                           INSERT INTO TBW12_CRF_ERR_MSG VALUES
                               (P_SESSION_ID,
                               P_DATETIME,
                               WK_SEQ,
                               7,
                               1,
                               WK_ERR_MSG);
                       END IF;
                   END IF;
               END IF;
           END IF;
       END IF;

       FETCH CUR_CRFREF_CHK INTO D_STUDY_ID, D_CRF_ID, D_CRF_ITEM_CD, D_REF_CRF_ID, D_REF_CRF_ITEM_CD, D_CRF_ID_TBM32, D_CRF_ITEM_CD_TBM32, D_CRF_ITEM_DIV, D_CRF_ITEM_DIV_CD, D_CNT, D_TBM32_CRF_ITEM_NM;
   end while;
   CLOSE CUR_CRFREF_CHK;

   set eod = 0;
   OPEN CUR_DOM_DEFF_CHK;
   FETCH CUR_DOM_DEFF_CHK INTO D_VISIT_NO, D_DOM_CD, D_DOM_VAR_NM, D_DOM_ITM_GRP_OID, D_DOM_ITM_GRP_ROWNO, D_MIN_FIXED_VALUE, D_MAX_FIXED_VALUE, D_MIN_REF_CRF_ID, D_MAX_REF_CRF_ID, D_MIN_REF_CRF_ITEM_CD, D_MAX_REF_CRF_ITEM_CD, D_CRF_INFO;
   while eod = 0 do
       IF D_MIN_FIXED_VALUE     <> D_MAX_FIXED_VALUE
       or D_MIN_REF_CRF_ID      <> D_MAX_REF_CRF_ID
       or D_MIN_REF_CRF_ITEM_CD <> D_MAX_REF_CRF_ITEM_CD then
           Set W_ERR_CD = 1;
           Set WK_SEQ = WK_SEQ + 1;
           Set WK_ERR_MSG = CONCAT('VISIT番号＝[',D_VISIT_NO,']、ドメイン＝[',D_DOM_CD,'.',D_DOM_VAR_NM,']、項目グループOID＝[',D_DOM_ITM_GRP_OID,']、行番号＝[',D_DOM_ITM_GRP_ROWNO,']に該当する項目の固定値（または参照先CRF）が同一の値ではありません。');
           INSERT INTO TBW12_CRF_ERR_MSG VALUES
               (P_SESSION_ID,
               P_DATETIME,
               WK_SEQ,
               1,
               1,
               WK_ERR_MSG);
           Set W_ERR_CD = 1;
           Set WK_SEQ = WK_SEQ + 1;
           Set WK_ERR_MSG = CONCAT('　※上記に該当する項目（CRFID_CRF項目ID）＝[',D_CRF_INFO,']');
           INSERT INTO TBW12_CRF_ERR_MSG VALUES
               (P_SESSION_ID,
               P_DATETIME,
               WK_SEQ,
               1,
               1,
               WK_ERR_MSG);
       END IF;
       FETCH CUR_DOM_DEFF_CHK INTO D_VISIT_NO, D_DOM_CD, D_DOM_VAR_NM, D_DOM_ITM_GRP_OID, D_DOM_ITM_GRP_ROWNO, D_MIN_FIXED_VALUE, D_MAX_FIXED_VALUE, D_MIN_REF_CRF_ID, D_MAX_REF_CRF_ID, D_MIN_REF_CRF_ITEM_CD, D_MAX_REF_CRF_ITEM_CD, D_CRF_INFO;
   end while;
   CLOSE CUR_DOM_DEFF_CHK;

   commit;

END