-- MySQL dump 10.13  Distrib 5.1.41, for Win32 (ia32)
--
-- Host: localhost    Database: smartedc
-- ------------------------------------------------------
-- Server version	5.1.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tam01_sys`
--

DROP TABLE IF EXISTS `tam01_sys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tam01_sys` (
  `TAM01_SYS_ID` varchar(2) NOT NULL,
  `TAM01_SYS_NM` varchar(40) DEFAULT NULL,
  `TAM01_DEL_FLG` varchar(1) DEFAULT NULL,
  `TAM01_CRT_DATETIME` datetime DEFAULT NULL,
  `TAM01_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TAM01_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TAM01_UPD_DATETIME` datetime DEFAULT NULL,
  `TAM01_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TAM01_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TAM01_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TAM01_SYS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tam01_sys`
--

LOCK TABLES `tam01_sys` WRITE;
/*!40000 ALTER TABLE `tam01_sys` DISABLE KEYS */;
/*!40000 ALTER TABLE `tam01_sys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tam02_menu`
--

DROP TABLE IF EXISTS `tam02_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tam02_menu` (
  `TAM01_SYS_ID` varchar(2) NOT NULL,
  `TAM02_MENU_ID_TREE_1` varchar(2) NOT NULL,
  `TAM02_MENU_ID_TREE_2` varchar(2) NOT NULL,
  `TAM02_MENU_ID_TREE_3` varchar(2) NOT NULL,
  `TAM02_MENU_NM` varchar(50) DEFAULT NULL,
  `TAM02_APP_ID` varchar(7) DEFAULT NULL,
  `TAM02_DEL_FLG` varchar(1) DEFAULT NULL,
  `TAM02_CRT_DATETIME` datetime DEFAULT NULL,
  `TAM02_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TAM02_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TAM02_UPD_DATETIME` datetime DEFAULT NULL,
  `TAM02_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TAM02_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TAM02_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TAM01_SYS_ID`,`TAM02_MENU_ID_TREE_1`,`TAM02_MENU_ID_TREE_2`,`TAM02_MENU_ID_TREE_3`),
  KEY `ITAM02_MENU2` (`TAM02_APP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tam02_menu`
--

LOCK TABLES `tam02_menu` WRITE;
/*!40000 ALTER TABLE `tam02_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `tam02_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tam03_appli`
--

DROP TABLE IF EXISTS `tam03_appli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tam03_appli` (
  `TAM03_APP_ID` varchar(7) NOT NULL,
  `TAM03_APP_NM` varchar(40) DEFAULT NULL,
  `TAM03_SUB_MENU_FLG` varchar(1) DEFAULT NULL,
  `TAM03_KIDO_PG` varchar(40) DEFAULT NULL,
  `TAM03_DEL_FLG` varchar(1) DEFAULT NULL,
  `TAM03_CRT_DATETIME` datetime DEFAULT NULL,
  `TAM03_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TAM03_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TAM03_UPD_DATETIME` datetime DEFAULT NULL,
  `TAM03_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TAM03_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TAM03_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TAM03_APP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tam03_appli`
--

LOCK TABLES `tam03_appli` WRITE;
/*!40000 ALTER TABLE `tam03_appli` DISABLE KEYS */;
/*!40000 ALTER TABLE `tam03_appli` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tam04_kngn`
--

DROP TABLE IF EXISTS `tam04_kngn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tam04_kngn` (
  `TAM04_AUTH_CD` varchar(2) NOT NULL,
  `TAM04_AUTH_NM` varchar(40) DEFAULT NULL,
  `TAM04_AUTH_LVL` smallint(6) DEFAULT NULL,
  `TAM04_DEL_FLG` varchar(1) DEFAULT NULL,
  `TAM04_CRT_DATETIME` datetime DEFAULT NULL,
  `TAM04_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TAM04_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TAM04_UPD_DATETIME` datetime DEFAULT NULL,
  `TAM04_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TAM04_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TAM04_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TAM04_AUTH_CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tam04_kngn`
--

LOCK TABLES `tam04_kngn` WRITE;
/*!40000 ALTER TABLE `tam04_kngn` DISABLE KEYS */;
/*!40000 ALTER TABLE `tam04_kngn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tam05_appli_kngn`
--

DROP TABLE IF EXISTS `tam05_appli_kngn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tam05_appli_kngn` (
  `TAM04_AUTH_CD` varchar(2) NOT NULL,
  `TAM03_APP_ID` varchar(7) NOT NULL,
  `TAM05_KNGN_FLG` varchar(1) DEFAULT NULL,
  `TAM05_DEL_FLG` varchar(1) DEFAULT NULL,
  `TAM05_CRT_DATETIME` datetime DEFAULT NULL,
  `TAM05_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TAM05_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TAM05_UPD_DATETIME` datetime DEFAULT NULL,
  `TAM05_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TAM05_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TAM05_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TAM04_AUTH_CD`,`TAM03_APP_ID`),
  KEY `ITAM05_APPLI_KNGN1` (`TAM03_APP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tam05_appli_kngn`
--

LOCK TABLES `tam05_appli_kngn` WRITE;
/*!40000 ALTER TABLE `tam05_appli_kngn` DISABLE KEYS */;
/*!40000 ALTER TABLE `tam05_appli_kngn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tam06_msg`
--

DROP TABLE IF EXISTS `tam06_msg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tam06_msg` (
  `TAM06_MSG_CD` varchar(7) NOT NULL,
  `TAM06_MSG` varchar(1000) DEFAULT NULL,
  `TAM06_DEL_FLG` varchar(1) DEFAULT NULL,
  `TAM06_CRT_DATETIME` datetime DEFAULT NULL,
  `TAM06_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TAM06_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TAM06_UPD_DATETIME` datetime DEFAULT NULL,
  `TAM06_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TAM06_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TAM06_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TAM06_MSG_CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tam06_msg`
--

LOCK TABLES `tam06_msg` WRITE;
/*!40000 ALTER TABLE `tam06_msg` DISABLE KEYS */;
/*!40000 ALTER TABLE `tam06_msg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tam07_user`
--

DROP TABLE IF EXISTS `tam07_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tam07_user` (
  `TAM07_USER_ID` varchar(128) NOT NULL DEFAULT '',
  `TAM07_USER_NM` varchar(30) DEFAULT NULL,
  `TAM07_USER_KANA_NM` varchar(20) DEFAULT NULL,
  `TAM07_PWD` varchar(128) DEFAULT NULL,
  `TAM07_AUTH_CD` varchar(2) DEFAULT NULL,
  `TAM07_SITE_ID` varchar(20) DEFAULT NULL,
  `TAM07_EMAIL` varchar(256) DEFAULT NULL,
  `TAM07_DEL_FLG` varchar(1) DEFAULT NULL,
  `TAM07_CRT_DATETIME` datetime DEFAULT NULL,
  `TAM07_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TAM07_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TAM07_UPD_DATETIME` datetime DEFAULT NULL,
  `TAM07_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TAM07_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TAM07_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TAM07_USER_ID`),
  KEY `ITAM07_USER1` (`TAM07_AUTH_CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tam07_user`
--

LOCK TABLES `tam07_user` WRITE;
/*!40000 ALTER TABLE `tam07_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `tam07_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tam08_site`
--

DROP TABLE IF EXISTS `tam08_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tam08_site` (
  `TAM08_SITE_ID` varchar(20) NOT NULL,
  `TAM08_SITE_NM` varchar(50) DEFAULT NULL,
  `TAM08_SITE_SNM` varchar(20) DEFAULT NULL,
  `TAM08_OUTER_SITE_ID` varchar(20) DEFAULT NULL,
  `TAM08_DEL_FLG` varchar(1) DEFAULT NULL,
  `TAM08_CRT_DATETIME` datetime DEFAULT NULL,
  `TAM08_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TAM08_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TAM08_UPD_DATETIME` datetime DEFAULT NULL,
  `TAM08_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TAM08_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TAM08_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TAM08_SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tam08_site`
--

LOCK TABLES `tam08_site` WRITE;
/*!40000 ALTER TABLE `tam08_site` DISABLE KEYS */;
/*!40000 ALTER TABLE `tam08_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tas01_cdnm`
--

DROP TABLE IF EXISTS `tas01_cdnm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tas01_cdnm` (
  `TAS01_DATA_KIND` varchar(3) NOT NULL,
  `TAS01_ITEM_CD` varchar(4) NOT NULL,
  `TAS01_ITEM_NM` varchar(60) DEFAULT NULL,
  `TAS01_ITEM_RYAK` varchar(20) DEFAULT NULL,
  `TAS01_DATA_KIND_NM` varchar(40) DEFAULT NULL,
  `TAS01_SORT_NO` smallint(6) DEFAULT NULL,
  `TAS01_CHAR_1` varchar(100) DEFAULT NULL,
  `TAS01_CHAR_2` varchar(100) DEFAULT NULL,
  `TAS01_CHAR_3` varchar(100) DEFAULT NULL,
  `TAS01_CHAR_4` varchar(100) DEFAULT NULL,
  `TAS01_CHAR_5` varchar(100) DEFAULT NULL,
  `TAS01_NUM_1` decimal(17,4) DEFAULT NULL,
  `TAS01_NUM_2` decimal(17,4) DEFAULT NULL,
  `TAS01_NUM_3` decimal(17,4) DEFAULT NULL,
  `TAS01_NUM_4` decimal(17,4) DEFAULT NULL,
  `TAS01_NUM_5` decimal(17,4) DEFAULT NULL,
  `TAS01_DEL_FLG` varchar(1) DEFAULT NULL,
  `TAS01_CRT_DATETIME` datetime DEFAULT NULL,
  `TAS01_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TAS01_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TAS01_UPD_DATETIME` datetime DEFAULT NULL,
  `TAS01_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TAS01_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TAS01_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TAS01_DATA_KIND`,`TAS01_ITEM_CD`),
  KEY `UTAS01_CDNM01` (`TAS01_ITEM_NM`,`TAS01_DATA_KIND`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tas01_cdnm`
--

LOCK TABLES `tas01_cdnm` WRITE;
/*!40000 ALTER TABLE `tas01_cdnm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tas01_cdnm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tas02_geng`
--

DROP TABLE IF EXISTS `tas02_geng`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tas02_geng` (
  `TAS02_GNGO_KBN` varchar(1) NOT NULL,
  `TAS02_GNGO_NM` varchar(10) DEFAULT NULL,
  `TAS02_GNGO_RYAK_NM` varchar(10) DEFAULT NULL,
  `TAS02_HNKAN_NEN` smallint(6) DEFAULT NULL,
  `TAS02_DATE_START` varchar(8) DEFAULT NULL,
  `TAS02_DATE_END` varchar(8) DEFAULT NULL,
  `TAS02_DATE_W_START` varchar(6) DEFAULT NULL,
  `TAS02_DATE_W_END` varchar(6) DEFAULT NULL,
  `TAS02_DEL_FLG` varchar(1) DEFAULT NULL,
  `TAS02_CRT_DATETIME` datetime DEFAULT NULL,
  `TAS02_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TAS02_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TAS02_UPD_DATETIME` datetime DEFAULT NULL,
  `TAS02_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TAS02_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TAS02_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TAS02_GNGO_KBN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tas02_geng`
--

LOCK TABLES `tas02_geng` WRITE;
/*!40000 ALTER TABLE `tas02_geng` DISABLE KEYS */;
/*!40000 ALTER TABLE `tas02_geng` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tat01_info`
--

DROP TABLE IF EXISTS `tat01_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tat01_info` (
  `TAT01_INFO_NO` mediumint(9) NOT NULL AUTO_INCREMENT,
  `TAT01_INFO_KBN` varchar(1) DEFAULT NULL,
  `TAT01_DATE_START` date DEFAULT NULL,
  `TAT01_DATE_END` date DEFAULT NULL,
  `TAT01_INFO` varchar(2000) DEFAULT NULL,
  `TAT01_DEL_FLG` varchar(1) DEFAULT NULL,
  `TAT01_CRT_DATETIME` datetime DEFAULT NULL,
  `TAT01_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TAT01_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TAT01_UPD_DATETIME` datetime DEFAULT NULL,
  `TAT01_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TAT01_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TAT01_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TAT01_INFO_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tat01_info`
--

LOCK TABLES `tat01_info` WRITE;
/*!40000 ALTER TABLE `tat01_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `tat01_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taw01_api_sdt_work`
--

DROP TABLE IF EXISTS `taw01_api_sdt_work`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taw01_api_sdt_work` (
  `TAW01_SESSION_ID` varchar(50) NOT NULL,
  `TAW01_APP_ID` varchar(7) NOT NULL,
  `TAW01_DISP_DATETIME` varchar(14) NOT NULL,
  `TAW01_CRT_DATE` date DEFAULT NULL,
  `TAW01_SDT_SAVE_1` mediumtext,
  `TAW01_SDT_SAVE_2` mediumtext,
  PRIMARY KEY (`TAW01_SESSION_ID`,`TAW01_APP_ID`,`TAW01_DISP_DATETIME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taw01_api_sdt_work`
--

LOCK TABLES `taw01_api_sdt_work` WRITE;
/*!40000 ALTER TABLE `taw01_api_sdt_work` DISABLE KEYS */;
/*!40000 ALTER TABLE `taw01_api_sdt_work` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm01_system`
--

DROP TABLE IF EXISTS `tbm01_system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm01_system` (
  `TBM01_SYS_ID` varchar(20) NOT NULL,
  `TBM01_SYS_VALUE` varchar(100) DEFAULT NULL,
  `TBM01_NOTE` varchar(1000) DEFAULT NULL,
  `TBM01_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM01_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM01_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM01_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM01_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM01_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM01_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM01_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM01_SYS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm01_system`
--

LOCK TABLES `tbm01_system` WRITE;
/*!40000 ALTER TABLE `tbm01_system` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm01_system` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm02_cdisc_domain`
--

DROP TABLE IF EXISTS `tbm02_cdisc_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm02_cdisc_domain` (
  `TBM02_DOM_CD` varchar(2) NOT NULL,
  `TBM02_DOM_ENM` varchar(50) DEFAULT NULL,
  `TBM02_DOM_JNM` varchar(50) DEFAULT NULL,
  `TBM02_DOM_GRP_NM` varchar(50) DEFAULT NULL,
  `TBM02_NOTE` varchar(1000) DEFAULT NULL,
  `TBM02_ORDER` mediumint(9) DEFAULT NULL,
  `TBM02_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM02_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM02_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM02_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM02_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM02_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM02_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM02_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM02_DOM_CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm02_cdisc_domain`
--

LOCK TABLES `tbm02_cdisc_domain` WRITE;
/*!40000 ALTER TABLE `tbm02_cdisc_domain` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm02_cdisc_domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm03_cdisc_item`
--

DROP TABLE IF EXISTS `tbm03_cdisc_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm03_cdisc_item` (
  `TBM03_DOM_CD` varchar(2) NOT NULL,
  `TBM03_DOM_VAR_NM` varchar(50) NOT NULL,
  `TBM03_VAR_DESC` varchar(100) DEFAULT NULL,
  `TBM03_SDTM_FLG` varchar(1) DEFAULT NULL,
  `TBM03_CDASH_FLG` varchar(1) DEFAULT NULL,
  `TBM03_INPUT_TYPE_DIV` varchar(2) DEFAULT NULL,
  `TBM03_REQUIRED_FLG` varchar(1) DEFAULT NULL,
  `TBM03_SAS_FIELD_NM` varchar(50) DEFAULT NULL,
  `TBM03_ODM_DATA_TYPE` varchar(20) DEFAULT NULL,
  `TBM03_NOTE` varchar(1000) DEFAULT NULL,
  `TBM03_ORDER` mediumint(9) DEFAULT NULL,
  `TBM03_VERSION` varchar(20) DEFAULT NULL,
  `TBM03_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM03_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM03_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM03_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM03_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM03_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM03_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM03_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM03_DOM_CD`,`TBM03_DOM_VAR_NM`),
  KEY `UTBM03_CDISC_ITEM01` (`TBM03_ORDER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm03_cdisc_item`
--

LOCK TABLES `tbm03_cdisc_item` WRITE;
/*!40000 ALTER TABLE `tbm03_cdisc_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm03_cdisc_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm07_auth_behavior`
--

DROP TABLE IF EXISTS `tbm07_auth_behavior`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm07_auth_behavior` (
  `TBM07_AUTH_CD` varchar(2) NOT NULL,
  `TBM07_CRF_INP_AUTH_FLG` varchar(1) DEFAULT NULL,
  `TBM07_CRF_EDIT_AUTH_FLG` varchar(1) DEFAULT NULL,
  `TBM07_OTHER_SITE_VIEW_FLG` varchar(1) DEFAULT NULL,
  `TBM07_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM07_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM07_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM07_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM07_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM07_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM07_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM07_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM07_AUTH_CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm07_auth_behavior`
--

LOCK TABLES `tbm07_auth_behavior` WRITE;
/*!40000 ALTER TABLE `tbm07_auth_behavior` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm07_auth_behavior` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm08_auth_inp_lvl`
--

DROP TABLE IF EXISTS `tbm08_auth_inp_lvl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm08_auth_inp_lvl` (
  `TBM08_AUTH_CD` varchar(2) NOT NULL,
  `TBM08_DM_MICHAKU_CRF_FLG` varchar(1) DEFAULT NULL,
  `TBM08_DM_MICHAKU_MEMO_FLG` varchar(1) DEFAULT NULL,
  `TBM08_DM_MICHAKU_DM_FLG` varchar(1) DEFAULT NULL,
  `TBM08_DM_ARRI_CRF_FLG` varchar(1) DEFAULT NULL,
  `TBM08_DM_ARRI_MEMO_FLG` varchar(1) DEFAULT NULL,
  `TBM08_DM_ARRI_DM_FLG` varchar(1) DEFAULT NULL,
  `TBM08_DM_KAIJO_CRF_FLG` varchar(1) DEFAULT NULL,
  `TBM08_DM_KAIJO_MEMO_FLG` varchar(1) DEFAULT NULL,
  `TBM08_DM_KAIJO_DM_FLG` varchar(1) DEFAULT NULL,
  `TBM08_ICON_CAPTION` varchar(2) DEFAULT NULL,
  `TBM08_ICON_R` decimal(4,0) DEFAULT NULL,
  `TBM08_ICON_G` decimal(4,0) DEFAULT NULL,
  `TBM08_ICON_B` decimal(4,0) DEFAULT NULL,
  `TBM08_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM08_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM08_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM08_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM08_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM08_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM08_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM08_UPD_COUNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM08_AUTH_CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm08_auth_inp_lvl`
--

LOCK TABLES `tbm08_auth_inp_lvl` WRITE;
/*!40000 ALTER TABLE `tbm08_auth_inp_lvl` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm08_auth_inp_lvl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm11_image`
--

DROP TABLE IF EXISTS `tbm11_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm11_image` (
  `TBM11_IMAGE_CD` varchar(50) NOT NULL,
  `TBM11_IMAGE_NM` varchar(50) DEFAULT NULL,
  `TBM11_IMAGE` longblob,
  `TBM11_FILE_NAME` varchar(100) DEFAULT NULL,
  `TBM11_STUDY_ID` bigint(20) DEFAULT NULL,
  `TBM11_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM11_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM11_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM11_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM11_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM11_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM11_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM11_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM11_IMAGE_CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm11_image`
--

LOCK TABLES `tbm11_image` WRITE;
/*!40000 ALTER TABLE `tbm11_image` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm11_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm21_study`
--

DROP TABLE IF EXISTS `tbm21_study`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm21_study` (
  `TBM21_STUDY_ID` bigint(20) NOT NULL,
  `TBM21_STUDY_NM` varchar(100) DEFAULT NULL,
  `TBM21_OUTER_STUDY_ID` varchar(20) DEFAULT NULL,
  `TBM21_PROC_NM` varchar(100) DEFAULT NULL,
  `TBM21_NOTE` varchar(1000) DEFAULT NULL,
  `TBM21_STATUS` varchar(1) DEFAULT NULL,
  `TBM21_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM21_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM21_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM21_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM21_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM21_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM21_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM21_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM21_STUDY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm21_study`
--

LOCK TABLES `tbm21_study` WRITE;
/*!40000 ALTER TABLE `tbm21_study` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm21_study` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm22_study_site`
--

DROP TABLE IF EXISTS `tbm22_study_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm22_study_site` (
  `TBM22_STUDY_ID` bigint(20) NOT NULL,
  `TBM22_SITE_ID` varchar(20) NOT NULL,
  `TBM22_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM22_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM22_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM22_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM22_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM22_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM22_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM22_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM22_STUDY_ID`,`TBM22_SITE_ID`),
  KEY `ITBM22_STUDY_SITE2` (`TBM22_SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm22_study_site`
--

LOCK TABLES `tbm22_study_site` WRITE;
/*!40000 ALTER TABLE `tbm22_study_site` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm22_study_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm23_study_staff`
--

DROP TABLE IF EXISTS `tbm23_study_staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm23_study_staff` (
  `TBM23_STUDY_ID` bigint(20) NOT NULL,
  `TBM23_USER_ID` varchar(128) NOT NULL DEFAULT '',
  `TBM23_STYDY_AUTH_CD` varchar(2) NOT NULL,
  `TBM23_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM23_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM23_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM23_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM23_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM23_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM23_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM23_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM23_STUDY_ID`,`TBM23_USER_ID`,`TBM23_STYDY_AUTH_CD`),
  KEY `ITBM23_STUDY_STAFF1` (`TBM23_USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm23_study_staff`
--

LOCK TABLES `tbm23_study_staff` WRITE;
/*!40000 ALTER TABLE `tbm23_study_staff` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm23_study_staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm24_map_item`
--

DROP TABLE IF EXISTS `tbm24_map_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm24_map_item` (
  `TBM24_STUDY_ID` bigint(20) NOT NULL,
  `TBM24_DOM_CD` varchar(2) NOT NULL,
  `TBM24_DOM_VAR_NM` varchar(50) NOT NULL,
  `TBM24_CRF_ITEM_DIV` varchar(20) NOT NULL,
  `TBM24_DOM_ITM_GRP_OID` varchar(50) DEFAULT NULL,
  `TBM24_DOM_ITM_GRP_ATTR_SEQ` smallint(6) DEFAULT NULL,
  `TBM24_DOM_ITM_GRP_ROWNO` smallint(6) DEFAULT NULL,
  `TBM24_CRF_ITEM_NM` varchar(200) DEFAULT NULL,
  `TBM24_IDENTIFICATION_CD` varchar(50) DEFAULT NULL,
  `TBM24_TEXT_MAXLENGTH` smallint(6) DEFAULT NULL,
  `TBM24_TEXT_MAXROWS` smallint(6) DEFAULT NULL,
  `TBM24_DECIMAL_DIGITS` smallint(6) DEFAULT NULL,
  `TBM24_TEXT` varchar(200) DEFAULT NULL,
  `TBM24_FIXED_VALUE` varchar(100) DEFAULT NULL,
  `TBM24_CHK_FALSE_INNER_VALUE` varchar(100) DEFAULT NULL,
  `TBM24_REQUIRED_INPUT_FLG` varchar(1) DEFAULT NULL,
  `TBM24_MIN_VALUE` varchar(10) DEFAULT NULL,
  `TBM24_MAX_VALUE` varchar(10) DEFAULT NULL,
  `TBM24_ORDER` mediumint(9) DEFAULT NULL,
  `TBM24_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM24_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM24_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM24_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM24_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM24_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM24_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM24_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM24_STUDY_ID`,`TBM24_DOM_CD`,`TBM24_DOM_VAR_NM`,`TBM24_CRF_ITEM_DIV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm24_map_item`
--

LOCK TABLES `tbm24_map_item` WRITE;
/*!40000 ALTER TABLE `tbm24_map_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm24_map_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm25_sel_list`
--

DROP TABLE IF EXISTS `tbm25_sel_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm25_sel_list` (
  `TBM25_STUDY_ID` bigint(20) NOT NULL,
  `TBM25_LIST_CD` varchar(20) NOT NULL,
  `TBM25_LIST_NM` varchar(50) DEFAULT NULL,
  `TBM25_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM25_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM25_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM25_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM25_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM25_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM25_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM25_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM25_STUDY_ID`,`TBM25_LIST_CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm25_sel_list`
--

LOCK TABLES `tbm25_sel_list` WRITE;
/*!40000 ALTER TABLE `tbm25_sel_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm25_sel_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm26_sel_list_item`
--

DROP TABLE IF EXISTS `tbm26_sel_list_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm26_sel_list_item` (
  `TBM26_STUDY_ID` bigint(20) NOT NULL,
  `TBM26_LIST_CD` varchar(20) NOT NULL,
  `TBM26_LIST_ITEM_NO` smallint(6) NOT NULL,
  `TBM26_LIST_ITEM_NAME` varchar(50) DEFAULT NULL,
  `TBM26_INNER_VALUE` varchar(100) DEFAULT NULL,
  `TBM26_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM26_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM26_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM26_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM26_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM26_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM26_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM26_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM26_STUDY_ID`,`TBM26_LIST_CD`,`TBM26_LIST_ITEM_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm26_sel_list_item`
--

LOCK TABLES `tbm26_sel_list_item` WRITE;
/*!40000 ALTER TABLE `tbm26_sel_list_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm26_sel_list_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm31_crf`
--

DROP TABLE IF EXISTS `tbm31_crf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm31_crf` (
  `TBM31_STUDY_ID` bigint(20) NOT NULL,
  `TBM31_CRF_ID` smallint(6) NOT NULL,
  `TBM31_CRF_NM` varchar(100) DEFAULT NULL,
  `TBM31_CRF_SNM` varchar(20) DEFAULT NULL,
  `TBM31_GRID_SIZE` smallint(6) DEFAULT NULL,
  `TBM31_ORDER` mediumint(9) DEFAULT NULL,
  `TBM31_DEF_VISIT_NO` smallint(6) DEFAULT NULL,
  `TBM31_DEF_DOMAIN_CD` varchar(2) DEFAULT NULL,
  `TBM31_STATUS` varchar(1) DEFAULT NULL,
  `TBM31_NOTE` varchar(1000) DEFAULT NULL,
  `TBM31_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM31_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM31_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM31_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM31_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM31_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM31_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM31_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM31_STUDY_ID`,`TBM31_CRF_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm31_crf`
--

LOCK TABLES `tbm31_crf` WRITE;
/*!40000 ALTER TABLE `tbm31_crf` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm31_crf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm32_crf_item`
--

DROP TABLE IF EXISTS `tbm32_crf_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm32_crf_item` (
  `TBM32_STUDY_ID` bigint(20) NOT NULL,
  `TBM32_CRF_ID` smallint(6) NOT NULL,
  `TBM32_CRF_ITEM_CD` varchar(50) NOT NULL,
  `TBM32_CRF_ITEM_NM` varchar(200) DEFAULT NULL,
  `TBM32_CRF_ITEM_DIV` varchar(20) DEFAULT NULL,
  `TBM32_CRF_ITEM_GRP_CD` varchar(50) DEFAULT NULL,
  `TBM32_CRF_ITEM_GRP_ORDER` smallint(6) DEFAULT NULL,
  `TBM32_LOCATION_X` smallint(6) DEFAULT NULL,
  `TBM32_LOCATION_Y` smallint(6) DEFAULT NULL,
  `TBM32_LOCATION_X2` smallint(6) DEFAULT NULL,
  `TBM32_LOCATION_Y2` smallint(6) DEFAULT NULL,
  `TBM32_TEXT_ALIGN_DIV` varchar(6) DEFAULT NULL,
  `TBM32_TEXT_MAXROWS` smallint(6) DEFAULT NULL,
  `TBM32_TEXT_MAXLENGTH` smallint(6) DEFAULT NULL,
  `TBM32_DECIMAL_DIGITS` smallint(6) DEFAULT NULL,
  `TBM32_CHK_TRUE_INNER_VALUE` varchar(100) DEFAULT NULL,
  `TBM32_CHK_FALSE_INNER_VALUE` varchar(100) DEFAULT NULL,
  `TBM32_FIXED_VALUE` varchar(100) DEFAULT NULL,
  `TBM32_LIST_CD` varchar(20) DEFAULT NULL,
  `TBM32_IMAGE_CD` varchar(50) DEFAULT NULL,
  `TBM32_TEXT` varchar(200) DEFAULT NULL,
  `TBM32_FONT_SIZE` smallint(6) DEFAULT NULL,
  `TBM32_FONT_UL_FLG` varchar(1) DEFAULT NULL,
  `TBM32_FONT_COLOR_DIV` bigint(20) DEFAULT NULL,
  `TBM32_LINE_SIZE_DIV` smallint(6) DEFAULT NULL,
  `TBM32_LINE_COLOR_DIV` bigint(20) DEFAULT NULL,
  `TBM32_LINE_START_POINT_DIV` varchar(2) DEFAULT NULL,
  `TBM32_LINE_END_POINT_DIV` varchar(2) DEFAULT NULL,
  `TBM32_LINE_ANGLE` smallint(6) DEFAULT NULL,
  `TBM32_AUTH_LVL_MIN` smallint(6) DEFAULT NULL,
  `TBM32_ZORDER` smallint(6) DEFAULT NULL,
  `TBM32_TAB_ORDER` smallint(6) DEFAULT NULL,
  `TBM32_TABSTOP_FLG` varchar(1) DEFAULT NULL,
  `TBM32_REQUIRED_INPUT_FLG` varchar(1) DEFAULT NULL,
  `TBM32_MIN_VALUE` varchar(10) DEFAULT NULL,
  `TBM32_MAX_VALUE` varchar(10) DEFAULT NULL,
  `TBM32_CRF_ITEM_NOTE` varchar(1000) DEFAULT NULL,
  `TBM32_REF_CRF_ID` smallint(6) DEFAULT NULL,
  `TBM32_REF_CRF_ITEM_CD` varchar(50) DEFAULT NULL,
  `TBM32_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM32_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM32_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM32_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM32_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM32_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM32_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM32_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM32_STUDY_ID`,`TBM32_CRF_ID`,`TBM32_CRF_ITEM_CD`),
  KEY `UTBM32_CRF_ITEM01` (`TBM32_STUDY_ID`,`TBM32_CRF_ID`,`TBM32_CRF_ITEM_GRP_CD`,`TBM32_CRF_ITEM_DIV`,`TBM32_DEL_FLG`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm32_crf_item`
--

LOCK TABLES `tbm32_crf_item` WRITE;
/*!40000 ALTER TABLE `tbm32_crf_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm32_crf_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm33_crf_cond`
--

DROP TABLE IF EXISTS `tbm33_crf_cond`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm33_crf_cond` (
  `TBM33_STUDY_ID` bigint(20) NOT NULL,
  `TBM33_CRF_ID` smallint(6) NOT NULL,
  `TBM33_COND_NO` smallint(6) NOT NULL,
  `TBM33_COND_NM` varchar(100) DEFAULT NULL,
  `TBM33_EXPRESSION` varchar(1000) DEFAULT NULL,
  `TBM33_COND_DIV` varchar(1) DEFAULT NULL,
  `TBM33_CRF_ITEM_CD` varchar(50) DEFAULT NULL,
  `TBM33_PRIOR_NO` smallint(6) DEFAULT NULL,
  `TBM33_ERR_DIV` varchar(1) DEFAULT NULL,
  `TBM33_ERR_MSG` varchar(200) DEFAULT NULL,
  `TBM33_ENABLED_FLG` varchar(1) DEFAULT NULL,
  `TBM33_REQUIRED_INPUT_FLG` varchar(1) DEFAULT NULL,
  `TBM33_NUMERIC_RANGE_FLG` varchar(1) DEFAULT NULL,
  `TBM33_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM33_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM33_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM33_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM33_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM33_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM33_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM33_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM33_STUDY_ID`,`TBM33_CRF_ID`,`TBM33_COND_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm33_crf_cond`
--

LOCK TABLES `tbm33_crf_cond` WRITE;
/*!40000 ALTER TABLE `tbm33_crf_cond` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm33_crf_cond` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm34_crf_auth`
--

DROP TABLE IF EXISTS `tbm34_crf_auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm34_crf_auth` (
  `TBM34_STUDY_ID` bigint(20) NOT NULL,
  `TBM34_CRF_ID` smallint(6) NOT NULL,
  `TBM34_STYDY_AUTH_CD` varchar(2) NOT NULL,
  `TBM34_DISPLAY_FLG` varchar(1) DEFAULT NULL,
  `TBM34_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM34_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM34_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM34_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM34_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM34_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM34_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM34_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM34_STUDY_ID`,`TBM34_CRF_ID`,`TBM34_STYDY_AUTH_CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm34_crf_auth`
--

LOCK TABLES `tbm34_crf_auth` WRITE;
/*!40000 ALTER TABLE `tbm34_crf_auth` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm34_crf_auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm35_crf_item_auth`
--

DROP TABLE IF EXISTS `tbm35_crf_item_auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm35_crf_item_auth` (
  `TBM35_STUDY_ID` bigint(20) NOT NULL,
  `TBM35_CRF_ID` smallint(6) NOT NULL,
  `TBM35_CRF_ITEM_CD` varchar(50) NOT NULL,
  `TBM35_STUDY_AUTH_CD` varchar(2) NOT NULL,
  `TBM35_DISPLAY_FLG` varchar(1) DEFAULT NULL,
  `TBM35_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM35_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM35_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM35_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM35_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM35_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM35_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM35_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM35_STUDY_ID`,`TBM35_CRF_ID`,`TBM35_CRF_ITEM_CD`,`TBM35_STUDY_AUTH_CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm35_crf_item_auth`
--

LOCK TABLES `tbm35_crf_item_auth` WRITE;
/*!40000 ALTER TABLE `tbm35_crf_item_auth` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm35_crf_item_auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm36_crf_select`
--

DROP TABLE IF EXISTS `tbm36_crf_select`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm36_crf_select` (
  `TBM36_STUDY_ID` bigint(20) NOT NULL,
  `TBM36_CRF_ID` smallint(6) NOT NULL,
  `TBM36_COND_NO` smallint(6) NOT NULL,
  `TBM36_SELECT_CRF_ID` smallint(6) NOT NULL,
  `TBM36_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM36_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM36_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM36_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM36_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM36_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM36_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM36_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM36_STUDY_ID`,`TBM36_CRF_ID`,`TBM36_COND_NO`,`TBM36_SELECT_CRF_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm36_crf_select`
--

LOCK TABLES `tbm36_crf_select` WRITE;
/*!40000 ALTER TABLE `tbm36_crf_select` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm36_crf_select` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm37_crf_dom_map`
--

DROP TABLE IF EXISTS `tbm37_crf_dom_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm37_crf_dom_map` (
  `TBM37_STUDY_ID` bigint(20) NOT NULL,
  `TBM37_CRF_ID` smallint(6) NOT NULL,
  `TBM37_CRF_ITEM_GRP_DIV` varchar(1) NOT NULL,
  `TBM37_CRF_ITEM_GRP_CD` varchar(50) NOT NULL,
  `TBM37_VISIT_NO` smallint(6) DEFAULT NULL,
  `TBM37_DOM_CD` varchar(2) DEFAULT NULL,
  `TBM37_DOM_VAR_NM` varchar(50) DEFAULT NULL,
  `TBM37_DOM_ITM_GRP_OID` varchar(50) DEFAULT NULL,
  `TBM37_DOM_ITM_GRP_ATTR_SEQ` smallint(6) DEFAULT NULL,
  `TBM37_DOM_ITM_GRP_ROWNO` smallint(6) DEFAULT NULL,
  `TBM37_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM37_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM37_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM37_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM37_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM37_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM37_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM37_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM37_STUDY_ID`,`TBM37_CRF_ID`,`TBM37_CRF_ITEM_GRP_DIV`,`TBM37_CRF_ITEM_GRP_CD`),
  KEY `UTBM37_CRF_DOM_MAP01` (`TBM37_STUDY_ID`,`TBM37_VISIT_NO`,`TBM37_DOM_CD`,`TBM37_DOM_ITM_GRP_OID`,`TBM37_DOM_ITM_GRP_ROWNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm37_crf_dom_map`
--

LOCK TABLES `tbm37_crf_dom_map` WRITE;
/*!40000 ALTER TABLE `tbm37_crf_dom_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm37_crf_dom_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm41_crf_ncm_map`
--

DROP TABLE IF EXISTS `tbm41_crf_ncm_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm41_crf_ncm_map` (
  `TBM41_STUDY_ID` bigint(20) NOT NULL,
  `TBM41_CRF_ID` smallint(6) NOT NULL,
  `TBM41_CRF_ITEM_GRP_DIV` varchar(1) NOT NULL,
  `TBM41_CRF_ITEM_GRP_CD` varchar(50) NOT NULL,
  `TBM41_NCM_METADATA_ID` varchar(100) DEFAULT NULL,
  `TBM41_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM41_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM41_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM41_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM41_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM41_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM41_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM41_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM41_STUDY_ID`,`TBM41_CRF_ID`,`TBM41_CRF_ITEM_GRP_DIV`,`TBM41_CRF_ITEM_GRP_CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm41_crf_ncm_map`
--

LOCK TABLES `tbm41_crf_ncm_map` WRITE;
/*!40000 ALTER TABLE `tbm41_crf_ncm_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm41_crf_ncm_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm42_study_cdisc_domain`
--

DROP TABLE IF EXISTS `tbm42_study_cdisc_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm42_study_cdisc_domain` (
  `TBM42_STUDY_ID` bigint(20) NOT NULL,
  `TBM42_DOM_CD` varchar(2) NOT NULL,
  `TBM42_DOM_ENM` varchar(50) DEFAULT NULL,
  `TBM42_DOM_JNM` varchar(50) DEFAULT NULL,
  `TBM42_DOM_GRP_NM` varchar(50) DEFAULT NULL,
  `TBM42_NOTE` varchar(1000) DEFAULT NULL,
  `TBM42_ORDER` mediumint(9) DEFAULT NULL,
  `TBM42_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM42_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM42_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM42_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM42_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM42_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM42_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM42_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBM42_STUDY_ID`,`TBM42_DOM_CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm42_study_cdisc_domain`
--

LOCK TABLES `tbm42_study_cdisc_domain` WRITE;
/*!40000 ALTER TABLE `tbm42_study_cdisc_domain` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm42_study_cdisc_domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbm43_study_cdisc_item`
--

DROP TABLE IF EXISTS `tbm43_study_cdisc_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbm43_study_cdisc_item` (
  `TBM43_STUDY_ID` bigint(20) NOT NULL,
  `TBM43_DOM_CD` varchar(2) NOT NULL,
  `TBM43_DOM_VAR_NM` varchar(50) NOT NULL,
  `TBM43_VAR_DESC` varchar(100) DEFAULT NULL,
  `TBM43_SDTM_FLG` varchar(1) DEFAULT NULL,
  `TBM43_CDASH_FLG` varchar(1) DEFAULT NULL,
  `TBM43_INPUT_TYPE_DIV` varchar(2) DEFAULT NULL,
  `TBM43_REQUIRED_FLG` varchar(1) DEFAULT NULL,
  `TBM43_SAS_FIELD_NM` varchar(50) DEFAULT NULL,
  `TBM43_ODM_DATA_TYPE` varchar(20) DEFAULT NULL,
  `TBM43_NOTE` varchar(1000) DEFAULT NULL,
  `TBM43_ORDER` mediumint(9) DEFAULT NULL,
  `TBM43_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBM43_CRT_DATETIME` datetime DEFAULT NULL,
  `TBM43_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBM43_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM43_UPD_DATETIME` datetime DEFAULT NULL,
  `TBM43_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBM43_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBM43_UPD_CNT` bigint(20) DEFAULT NULL,
  `TBM43_VERSION` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`TBM43_STUDY_ID`,`TBM43_DOM_CD`,`TBM43_DOM_VAR_NM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbm43_study_cdisc_item`
--

LOCK TABLES `tbm43_study_cdisc_item` WRITE;
/*!40000 ALTER TABLE `tbm43_study_cdisc_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbm43_study_cdisc_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbt01_subject`
--

DROP TABLE IF EXISTS `tbt01_subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbt01_subject` (
  `TBT01_STUDY_ID` bigint(20) NOT NULL,
  `TBT01_SUBJECT_ID` mediumint(9) NOT NULL,
  `TBT01_OUTER_SUBJECT_ID` varchar(6) DEFAULT NULL,
  `TBT01_SITE_ID` varchar(20) DEFAULT NULL,
  `TBT01_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBT01_CRT_DATETIME` datetime DEFAULT NULL,
  `TBT01_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBT01_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBT01_UPD_DATETIME` datetime DEFAULT NULL,
  `TBT01_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBT01_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBT01_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBT01_STUDY_ID`,`TBT01_SUBJECT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbt01_subject`
--

LOCK TABLES `tbt01_subject` WRITE;
/*!40000 ALTER TABLE `tbt01_subject` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbt01_subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbt02_crf`
--

DROP TABLE IF EXISTS `tbt02_crf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbt02_crf` (
  `TBT02_STUDY_ID` bigint(20) NOT NULL,
  `TBT02_SUBJECT_ID` mediumint(9) NOT NULL,
  `TBT02_CRF_ID` smallint(6) NOT NULL,
  `TBT02_CRF_LATEST_VERSION` smallint(6) DEFAULT NULL,
  `TBT02_CRF_INPUT_LEVEL` smallint(6) DEFAULT NULL,
  `TBT02_LOCK_FLG` varchar(1) DEFAULT NULL,
  `TBT02_LOCK_DATETIME` datetime DEFAULT NULL,
  `TBT02_LOCK_USER_ID` varchar(128) DEFAULT NULL,
  `TBT02_LOCK_AUTH_CD` varchar(2) DEFAULT NULL,
  `TBT02_UPLOAD_DATETIME` datetime DEFAULT NULL,
  `TBT02_UPLOAD_USER_ID` varchar(128) DEFAULT NULL,
  `TBT02_UPLOAD_AUTH_CD` varchar(2) DEFAULT NULL,
  `TBT02_DM_ARRIVAL_FLG` varchar(1) DEFAULT NULL,
  `TBT02_DM_ARRIVAL_DATETIME` datetime DEFAULT NULL,
  `TBT02_APPROVAL_FLG` varchar(1) DEFAULT NULL,
  `TBT02_APPROVAL_DATETIME` datetime DEFAULT NULL,
  `TBT02_APPROVAL_USER_ID` varchar(128) DEFAULT NULL,
  `TBT02_APPROVAL_AUTH_CD` varchar(2) DEFAULT NULL,
  `TBT02_INPUT_END_FLG` varchar(1) DEFAULT NULL,
  `TBT02_INPUT_END_DATETIME` datetime DEFAULT NULL,
  `TBT02_INPUT_END_USER_ID` varchar(128) DEFAULT NULL,
  `TBT02_INPUT_END_AUTH_CD` varchar(2) DEFAULT NULL,
  `TBT02_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBT02_CRT_DATETIME` datetime DEFAULT NULL,
  `TBT02_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBT02_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBT02_UPD_DATETIME` datetime DEFAULT NULL,
  `TBT02_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBT02_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBT02_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBT02_STUDY_ID`,`TBT02_SUBJECT_ID`,`TBT02_CRF_ID`),
  KEY `UTBT02_CRF01` (`TBT02_CRF_ID`,`TBT02_SUBJECT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbt02_crf`
--

LOCK TABLES `tbt02_crf` WRITE;
/*!40000 ALTER TABLE `tbt02_crf` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbt02_crf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbt11_crf_history`
--

DROP TABLE IF EXISTS `tbt11_crf_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbt11_crf_history` (
  `TBT11_STUDY_ID` bigint(20) NOT NULL,
  `TBT11_SUBJECT_ID` mediumint(9) NOT NULL,
  `TBT11_CRF_ID` smallint(6) NOT NULL,
  `TBT11_CRF_VERSION` smallint(6) NOT NULL,
  `TBT11_CRF_INPUT_LEVEL` smallint(6) DEFAULT NULL,
  `TBT11_UPLOAD_DATETIME` datetime DEFAULT NULL,
  `TBT11_UPLOAD_USER_ID` varchar(128) DEFAULT NULL,
  `TBT11_UPLOAD_AUTH_CD` varchar(2) DEFAULT NULL,
  `TBT11_DM_ARRIVAL_FLG` varchar(1) DEFAULT NULL,
  `TBT11_DM_ARRIVAL_DATETIME` datetime DEFAULT NULL,
  `TBT11_APPROVAL_FLG` varchar(1) DEFAULT NULL,
  `TBT11_APPROVAL_DATETIME` datetime DEFAULT NULL,
  `TBT11_APPROVAL_USER_ID` varchar(128) DEFAULT NULL,
  `TBT11_APPROVAL_AUTH_CD` varchar(2) DEFAULT NULL,
  `TBT11_INPUT_END_FLG` varchar(1) DEFAULT NULL,
  `TBT11_INPUT_END_DATETIME` datetime DEFAULT NULL,
  `TBT11_INPUT_END_USER_ID` varchar(128) DEFAULT NULL,
  `TBT11_INPUT_END_AUTH_CD` varchar(2) DEFAULT NULL,
  `TBT11_UPD_RIYU` varchar(2000) DEFAULT NULL,
  `TBT11_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBT11_CRT_DATETIME` datetime DEFAULT NULL,
  `TBT11_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBT11_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBT11_UPD_DATETIME` datetime DEFAULT NULL,
  `TBT11_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBT11_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBT11_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBT11_STUDY_ID`,`TBT11_SUBJECT_ID`,`TBT11_CRF_ID`,`TBT11_CRF_VERSION`),
  KEY `UTBT11_CRF_HISTORY01` (`TBT11_CRF_VERSION`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbt11_crf_history`
--

LOCK TABLES `tbt11_crf_history` WRITE;
/*!40000 ALTER TABLE `tbt11_crf_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbt11_crf_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbt12_crf_result`
--

DROP TABLE IF EXISTS `tbt12_crf_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbt12_crf_result` (
  `TBT12_STUDY_ID` bigint(20) NOT NULL,
  `TBT12_SUBJECT_ID` mediumint(9) NOT NULL,
  `TBT12_CRF_ID` smallint(6) NOT NULL,
  `TBT12_CRF_ITEM_GRP_DIV` varchar(1) NOT NULL,
  `TBT12_CRF_ITEM_GRP_CD` varchar(50) NOT NULL,
  `TBT12_CRF_VALUE` varchar(2000) DEFAULT NULL,
  `TBT12_EDIT_FLG` varchar(1) DEFAULT NULL,
  `TBT12_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBT12_CRT_DATETIME` datetime DEFAULT NULL,
  `TBT12_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBT12_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBT12_UPD_DATETIME` datetime DEFAULT NULL,
  `TBT12_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBT12_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBT12_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBT12_STUDY_ID`,`TBT12_SUBJECT_ID`,`TBT12_CRF_ID`,`TBT12_CRF_ITEM_GRP_DIV`,`TBT12_CRF_ITEM_GRP_CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbt12_crf_result`
--

LOCK TABLES `tbt12_crf_result` WRITE;
/*!40000 ALTER TABLE `tbt12_crf_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbt12_crf_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbt13_crf_res_his`
--

DROP TABLE IF EXISTS `tbt13_crf_res_his`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbt13_crf_res_his` (
  `TBT13_STUDY_ID` bigint(20) NOT NULL,
  `TBT13_SUBJECT_ID` mediumint(9) NOT NULL,
  `TBT13_CRF_ID` smallint(6) NOT NULL,
  `TBT13_CRF_VERSION` smallint(6) NOT NULL,
  `TBT13_CRF_ITEM_GRP_DIV` varchar(1) NOT NULL,
  `TBT13_CRF_ITEM_GRP_CD` varchar(50) NOT NULL,
  `TBT13_CRF_VALUE` varchar(2000) DEFAULT NULL,
  `TBT13_EDIT_FLG` varchar(1) DEFAULT NULL,
  `TBT13_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBT13_CRT_DATETIME` datetime DEFAULT NULL,
  `TBT13_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBT13_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBT13_UPD_DATETIME` datetime DEFAULT NULL,
  `TBT13_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBT13_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBT13_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBT13_STUDY_ID`,`TBT13_SUBJECT_ID`,`TBT13_CRF_ID`,`TBT13_CRF_VERSION`,`TBT13_CRF_ITEM_GRP_DIV`,`TBT13_CRF_ITEM_GRP_CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbt13_crf_res_his`
--

LOCK TABLES `tbt13_crf_res_his` WRITE;
/*!40000 ALTER TABLE `tbt13_crf_res_his` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbt13_crf_res_his` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbt14_crf_memo`
--

DROP TABLE IF EXISTS `tbt14_crf_memo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbt14_crf_memo` (
  `TBT14_STUDY_ID` bigint(20) NOT NULL,
  `TBT14_SUBJECT_ID` mediumint(9) NOT NULL,
  `TBT14_MEMO_NO` smallint(6) NOT NULL,
  `TBT14_CRF_ID` smallint(6) DEFAULT NULL,
  `TBT14_CRF_VERSION` smallint(6) DEFAULT NULL,
  `TBT14_MEMO_KBN` varchar(1) DEFAULT NULL,
  `TBT14_MEMO` varchar(2000) DEFAULT NULL,
  `TBT14_REQUEST_SITE_ID` varchar(20) DEFAULT NULL,
  `TBT14_REQUEST_AUTH_CD` varchar(2) DEFAULT NULL,
  `TBT14_CRT_AUTH_CD` varchar(2) DEFAULT NULL,
  `TBT14_KAKUNIN_FLG` varchar(1) DEFAULT NULL,
  `TBT14_KAKUNIN_USER_ID` varchar(128) DEFAULT NULL,
  `TBT14_KAKUNIN_COMMENT` varchar(2000) DEFAULT NULL,
  `TBT14_KANRYO_FLG` varchar(1) DEFAULT NULL,
  `TBT14_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBT14_CRT_DATETIME` datetime DEFAULT NULL,
  `TBT14_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBT14_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBT14_UPD_DATETIME` datetime DEFAULT NULL,
  `TBT14_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBT14_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBT14_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBT14_STUDY_ID`,`TBT14_SUBJECT_ID`,`TBT14_MEMO_NO`),
  CONSTRAINT `ITBT14_CRF_MEMO1` FOREIGN KEY (`TBT14_STUDY_ID`, `TBT14_SUBJECT_ID`) REFERENCES `tbt01_subject` (`TBT01_STUDY_ID`, `TBT01_SUBJECT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbt14_crf_memo`
--

LOCK TABLES `tbt14_crf_memo` WRITE;
/*!40000 ALTER TABLE `tbt14_crf_memo` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbt14_crf_memo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbt15_crf_memo_loc`
--

DROP TABLE IF EXISTS `tbt15_crf_memo_loc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbt15_crf_memo_loc` (
  `TBT15_STUDY_ID` bigint(20) NOT NULL,
  `TBT15_SUBJECT_ID` mediumint(9) NOT NULL,
  `TBT15_MEMO_NO` smallint(6) NOT NULL,
  `TBT15_CRF_ID` smallint(6) DEFAULT NULL,
  `TBT15_CRF_VERSION` smallint(6) DEFAULT NULL,
  `TBT15_CRF_ITEM_GRP_DIV` varchar(1) DEFAULT NULL,
  `TBT15_CRF_ITEM_GRP_CD` varchar(50) DEFAULT NULL,
  `TBT15_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBT15_CRT_DATETIME` datetime DEFAULT NULL,
  `TBT15_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBT15_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBT15_UPD_DATETIME` datetime DEFAULT NULL,
  `TBT15_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBT15_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBT15_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBT15_STUDY_ID`,`TBT15_SUBJECT_ID`,`TBT15_MEMO_NO`),
  CONSTRAINT `ITBT15_CRF_MEMO_LOC` FOREIGN KEY (`TBT15_STUDY_ID`, `TBT15_SUBJECT_ID`, `TBT15_MEMO_NO`) REFERENCES `tbt14_crf_memo` (`TBT14_STUDY_ID`, `TBT14_SUBJECT_ID`, `TBT14_MEMO_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbt15_crf_memo_loc`
--

LOCK TABLES `tbt15_crf_memo_loc` WRITE;
/*!40000 ALTER TABLE `tbt15_crf_memo_loc` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbt15_crf_memo_loc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbt16_import_history`
--

DROP TABLE IF EXISTS `tbt16_import_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbt16_import_history` (
  `TBT16_IMPORT_NO` bigint(20) NOT NULL AUTO_INCREMENT,
  `TBT16_IMPORT_FILE_NM` varchar(200) DEFAULT NULL,
  `TBT16_FILE_NM` varchar(200) DEFAULT NULL,
  `TBT16_IMPORT_DATETIME` datetime DEFAULT NULL,
  `TBT16_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBT16_CRT_DATETIME` datetime DEFAULT NULL,
  `TBT16_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBT16_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBT16_UPD_DATETIME` datetime DEFAULT NULL,
  `TBT16_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBT16_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBT16_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBT16_IMPORT_NO`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbt16_import_history`
--

LOCK TABLES `tbt16_import_history` WRITE;
/*!40000 ALTER TABLE `tbt16_import_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbt16_import_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbw01_free_work`
--

DROP TABLE IF EXISTS `tbw01_free_work`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbw01_free_work` (
  `TBW01_SESSION_ID` varchar(50) NOT NULL,
  `TBW01_APP_ID` varchar(7) NOT NULL,
  `TBW01_DISP_DATETIME` varchar(14) NOT NULL,
  `TBW01_LINE_NO` bigint(20) NOT NULL,
  `TBW01_FREE_SAVE_1` mediumtext,
  `TBW01_FREE_SAVE_2` mediumtext,
  PRIMARY KEY (`TBW01_SESSION_ID`,`TBW01_APP_ID`,`TBW01_DISP_DATETIME`,`TBW01_LINE_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbw01_free_work`
--

LOCK TABLES `tbw01_free_work` WRITE;
/*!40000 ALTER TABLE `tbw01_free_work` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbw01_free_work` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbw02_odm_work`
--

DROP TABLE IF EXISTS `tbw02_odm_work`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbw02_odm_work` (
  `TBW02_SESSION_ID` varchar(50) NOT NULL,
  `TBW02_APP_ID` varchar(7) NOT NULL,
  `TBW02_DISP_DATETIME` varchar(14) NOT NULL,
  `TBW02_STUDY_ID` bigint(20) NOT NULL,
  `TBW02_SUBJECT_ID` mediumint(9) NOT NULL,
  `TBW02_VISIT_NO` smallint(6) NOT NULL,
  `TBW02_DOM_CD` varchar(2) NOT NULL,
  `TBW02_REPEAT_KEY` smallint(6) NOT NULL,
  `TBW02_ORDER` mediumint(9) NOT NULL,
  `TBW02_DOM_VAR_NM` varchar(50) NOT NULL,
  `TBW02_CRF_ITEM_CD` varchar(50) DEFAULT NULL,
  `TBW02_CRF_VALUE` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`TBW02_SESSION_ID`,`TBW02_APP_ID`,`TBW02_DISP_DATETIME`,`TBW02_STUDY_ID`,`TBW02_SUBJECT_ID`,`TBW02_VISIT_NO`,`TBW02_DOM_CD`,`TBW02_REPEAT_KEY`,`TBW02_ORDER`,`TBW02_DOM_VAR_NM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbw02_odm_work`
--

LOCK TABLES `tbw02_odm_work` WRITE;
/*!40000 ALTER TABLE `tbw02_odm_work` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbw02_odm_work` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbw03_crf_search`
--

DROP TABLE IF EXISTS `tbw03_crf_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbw03_crf_search` (
  `TBW03_SESSION_ID` varchar(50) NOT NULL,
  `TBW03_APP_ID` varchar(7) NOT NULL,
  `TBW03_DISP_DATETIME` varchar(14) NOT NULL,
  `TBW03_STUDY_ID` bigint(20) NOT NULL,
  `TBW03_SUBJECT_ID` mediumint(9) NOT NULL,
  `TBW03_CRF_ID` smallint(6) NOT NULL,
  `TBW03_SITE_ID` varchar(20) DEFAULT NULL,
  `TBW03_OUTER_SUBJECT_ID` varchar(6) DEFAULT NULL,
  `TBW03_CRF_LATEST_VERSION` smallint(6) DEFAULT NULL,
  `TBW03_CRF_INPUT_LEVEL` smallint(6) DEFAULT NULL,
  `TBW03_LOCK_FLG` varchar(1) DEFAULT NULL,
  `TBW03_LOCK_DATETIME` datetime DEFAULT NULL,
  `TBW03_LOCK_USER_ID` varchar(128) DEFAULT NULL,
  `TBW03_LOCK_AUTH_CD` varchar(2) DEFAULT NULL,
  `TBW03_UPLOAD_DATETIME` datetime DEFAULT NULL,
  `TBW03_UPLOAD_USER_ID` varchar(128) DEFAULT NULL,
  `TBW03_UPLOAD_AUTH_CD` varchar(2) DEFAULT NULL,
  `TBW03_DM_ARRIVAL_FLG` varchar(1) DEFAULT NULL,
  `TBW03_DM_ARRIVAL_DATETIME` datetime DEFAULT NULL,
  `TBW03_APPROVAL_FLG` varchar(1) DEFAULT NULL,
  `TBW03_APPROVAL_DATETIME` datetime DEFAULT NULL,
  `TBW03_APPROVAL_USER_ID` varchar(128) DEFAULT NULL,
  `TBW03_APPROVAL_AUTH_CD` varchar(2) DEFAULT NULL,
  `TBW03_INPUT_END_FLG` varchar(1) DEFAULT NULL,
  `TBW03_INPUT_END_DATETIME` datetime DEFAULT NULL,
  `TBW03_INPUT_END_USER_ID` varchar(128) DEFAULT NULL,
  `TBW03_INPUT_END_AUTH_CD` varchar(2) DEFAULT NULL,
  `TBW03_DEL_FLG` varchar(1) DEFAULT NULL,
  `TBW03_CRT_DATETIME` datetime DEFAULT NULL,
  `TBW03_CRT_USER_ID` varchar(128) DEFAULT NULL,
  `TBW03_CRT_PROG_NM` varchar(40) DEFAULT NULL,
  `TBW03_UPD_DATETIME` datetime DEFAULT NULL,
  `TBW03_UPD_USER_ID` varchar(128) DEFAULT NULL,
  `TBW03_UPD_PROG_NM` varchar(40) DEFAULT NULL,
  `TBW03_UPD_CNT` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TBW03_SESSION_ID`,`TBW03_APP_ID`,`TBW03_DISP_DATETIME`,`TBW03_STUDY_ID`,`TBW03_SUBJECT_ID`,`TBW03_CRF_ID`),
  KEY `ITBW03_CRF_SEARCH3` (`TBW03_LOCK_USER_ID`),
  KEY `ITBW03_CRF_SEARCH4` (`TBW03_UPLOAD_USER_ID`),
  KEY `ITBW03_CRF_SEARCH5` (`TBW03_APPROVAL_USER_ID`),
  KEY `ITBW03_CRF_SEARCH6` (`TBW03_INPUT_END_USER_ID`),
  KEY `ITBW03_CRF_SEARCH2` (`TBW03_SITE_ID`),
  KEY `ITBW03_CRF_SEARCH1` (`TBW03_STUDY_ID`,`TBW03_CRF_ID`),
  KEY `ITBW03_CRF_SEARCH7` (`TBW03_CRT_USER_ID`),
  KEY `ITBW03_CRF_SEARCH8` (`TBW03_UPD_USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbw03_crf_search`
--

LOCK TABLES `tbw03_crf_search` WRITE;
/*!40000 ALTER TABLE `tbw03_crf_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbw03_crf_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbw04_crf`
--

DROP TABLE IF EXISTS `tbw04_crf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbw04_crf` (
  `TBW04_SESSION_ID` varchar(50) NOT NULL,
  `TBW04_APP_ID` varchar(7) NOT NULL,
  `TBW04_DISP_DATETIME` varchar(14) NOT NULL,
  `TBW04_STUDY_ID` bigint(20) NOT NULL,
  `TBW04_SUBJECT_ID` mediumint(9) NOT NULL,
  `TBW04_CRF_ID` smallint(6) NOT NULL,
  `TBW04_CRF_LATEST_VERSION` smallint(6) DEFAULT NULL,
  `TBW04_CRF_INPUT_LEVEL` smallint(6) DEFAULT NULL,
  `TBW04_LOCK_FLG` varchar(1) DEFAULT NULL,
  `TBW04_LOCK_DATETIME` datetime DEFAULT NULL,
  `TBW04_LOCK_USER_ID` varchar(128) DEFAULT NULL,
  `TBW04_LOCK_AUTH_CD` varchar(2) DEFAULT NULL,
  `TBW04_UPLOAD_DATETIME` datetime DEFAULT NULL,
  `TBW04_UPLOAD_USER_ID` varchar(128) DEFAULT NULL,
  `TBW04_UPLOAD_AUTH_CD` varchar(2) DEFAULT NULL,
  `TBW04_DM_ARRIVAL_FLG` varchar(1) DEFAULT NULL,
  `TBW04_DM_ARRIVAL_DATETIME` datetime DEFAULT NULL,
  `TBW04_APPROVAL_FLG` varchar(1) DEFAULT NULL,
  `TBW04_APPROVAL_DATETIME` datetime DEFAULT NULL,
  `TBW04_APPROVAL_USER_ID` varchar(128) DEFAULT NULL,
  `TBW04_APPROVAL_AUTH_CD` varchar(2) DEFAULT NULL,
  `TBW04_INPUT_END_FLG` varchar(1) DEFAULT NULL,
  `TBW04_INPUT_END_DATETIME` datetime DEFAULT NULL,
  `TBW04_INPUT_END_USER_ID` varchar(128) DEFAULT NULL,
  `TBW04_INPUT_END_AUTH_CD` varchar(2) DEFAULT NULL,
  `TBW04_COMPLETION_FLG` varchar(1) DEFAULT NULL,
  `TBW04_EDIT_FLG` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`TBW04_SESSION_ID`,`TBW04_APP_ID`,`TBW04_DISP_DATETIME`,`TBW04_STUDY_ID`,`TBW04_SUBJECT_ID`,`TBW04_CRF_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbw04_crf`
--

LOCK TABLES `tbw04_crf` WRITE;
/*!40000 ALTER TABLE `tbw04_crf` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbw04_crf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbw05_crf_result`
--

DROP TABLE IF EXISTS `tbw05_crf_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbw05_crf_result` (
  `TBW05_SESSION_ID` varchar(50) NOT NULL,
  `TBW05_APP_ID` varchar(7) NOT NULL,
  `TBW05_DISP_DATETIME` varchar(14) NOT NULL,
  `TBW05_STUDY_ID` bigint(20) NOT NULL,
  `TBW05_SUBJECT_ID` mediumint(9) NOT NULL,
  `TBW05_CRF_ID` smallint(6) NOT NULL,
  `TBW05_CRF_ITEM_GRP_DIV` varchar(1) NOT NULL,
  `TBW05_CRF_ITEM_GRP_CD` varchar(50) NOT NULL,
  `TBW05_CRF_VALUE` varchar(2000) DEFAULT NULL,
  `TBW05_EDIT_FLG` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`TBW05_SESSION_ID`,`TBW05_APP_ID`,`TBW05_DISP_DATETIME`,`TBW05_STUDY_ID`,`TBW05_SUBJECT_ID`,`TBW05_CRF_ID`,`TBW05_CRF_ITEM_GRP_DIV`,`TBW05_CRF_ITEM_GRP_CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbw05_crf_result`
--

LOCK TABLES `tbw05_crf_result` WRITE;
/*!40000 ALTER TABLE `tbw05_crf_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbw05_crf_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbw06_crf_memo`
--

DROP TABLE IF EXISTS `tbw06_crf_memo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbw06_crf_memo` (
  `TBW06_SESSION_ID` varchar(50) NOT NULL,
  `TBW06_APP_ID` varchar(7) NOT NULL,
  `TBW06_DISP_DATETIME` varchar(14) NOT NULL,
  `TBW06_STUDY_ID` bigint(20) NOT NULL,
  `TBW06_SUBJECT_ID` mediumint(9) NOT NULL,
  `TBW06_INS_NO` smallint(6) NOT NULL,
  `TBW06_CRF_ID` smallint(6) DEFAULT NULL,
  `TBW06_CRF_VERSION` smallint(6) DEFAULT NULL,
  `TBW06_MEMO` varchar(2000) DEFAULT NULL,
  `TBW06_STYDY_AUTH_CD` varchar(2) DEFAULT NULL,
  `TBW06_REQUEST_USER_ID` varchar(128) DEFAULT NULL,
  `TBW06_EDIT_REQUEST_FLG` varchar(1) DEFAULT NULL,
  `TBW06_EDIT_REQUEST_END_FLG` varchar(1) DEFAULT NULL,
  `TBW06_EDIT_REQ_END_DATETIME` datetime DEFAULT NULL,
  `TBW06_EDIT_REQUEST_END_USER_ID` varchar(128) DEFAULT NULL,
  `TBW06_PROC_DIV` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`TBW06_SESSION_ID`,`TBW06_APP_ID`,`TBW06_DISP_DATETIME`,`TBW06_STUDY_ID`,`TBW06_SUBJECT_ID`,`TBW06_INS_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbw06_crf_memo`
--

LOCK TABLES `tbw06_crf_memo` WRITE;
/*!40000 ALTER TABLE `tbw06_crf_memo` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbw06_crf_memo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbw07_crf_memo_loc`
--

DROP TABLE IF EXISTS `tbw07_crf_memo_loc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbw07_crf_memo_loc` (
  `TBW07_SESSION_ID` varchar(50) NOT NULL,
  `TBW07_APP_ID` varchar(7) NOT NULL,
  `TBW07_DISP_DATETIME` varchar(14) NOT NULL,
  `TBW07_STUDY_ID` bigint(20) NOT NULL,
  `TBW07_SUBJECT_ID` mediumint(9) NOT NULL,
  `TBW07_INS_NO` smallint(6) NOT NULL,
  `TBW07_CRF_ID` smallint(6) NOT NULL,
  `TBW07_CRF_VERSION` smallint(6) NOT NULL,
  `TBW07_X` smallint(6) NOT NULL,
  `TBW07_Y` smallint(6) NOT NULL,
  `TBW07_EDIT_REQUEST_FLG` varchar(1) DEFAULT NULL,
  `TBW07_COLOR_DIV` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`TBW07_SESSION_ID`,`TBW07_APP_ID`,`TBW07_DISP_DATETIME`,`TBW07_STUDY_ID`,`TBW07_SUBJECT_ID`,`TBW07_INS_NO`,`TBW07_CRF_ID`,`TBW07_CRF_VERSION`,`TBW07_X`,`TBW07_Y`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbw07_crf_memo_loc`
--

LOCK TABLES `tbw07_crf_memo_loc` WRITE;
/*!40000 ALTER TABLE `tbw07_crf_memo_loc` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbw07_crf_memo_loc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbw10_csv_work`
--

DROP TABLE IF EXISTS `tbw10_csv_work`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbw10_csv_work` (
  `TBW10_SESSION_ID` varchar(50) NOT NULL,
  `TBW10_DATETIME` datetime NOT NULL,
  `TBW10_STUDY_ID` bigint(20) NOT NULL,
  `TBW10_SUBJECT_ID` mediumint(9) NOT NULL,
  `TBW10_CRF_ID` smallint(6) NOT NULL,
  `TBW10_CRF_ITEM_GRP_CD` varchar(50) NOT NULL,
  `TBW10_VISIT_NO` smallint(6) NOT NULL,
  `TBW10_DOM_CD` varchar(2) NOT NULL,
  `TBW10_DOM_VAR_NM` varchar(50) NOT NULL,
  `TBW10_DOM_ITM_GRP_OID` varchar(50) NOT NULL,
  `TBW10_DOM_ITM_GRP_ROWNO` smallint(6) NOT NULL,
  `TBW10_CHAR_1` smallint(6) DEFAULT NULL,
  `TBW10_VALUE` varchar(2000) DEFAULT NULL,
  `TBW10_CRF_ITEM_DIV` varchar(20) DEFAULT NULL,
  `TBW10_LIST_CD` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`TBW10_SESSION_ID`,`TBW10_DATETIME`,`TBW10_STUDY_ID`,`TBW10_SUBJECT_ID`,`TBW10_CRF_ID`,`TBW10_CRF_ITEM_GRP_CD`,`TBW10_VISIT_NO`,`TBW10_DOM_CD`,`TBW10_DOM_VAR_NM`,`TBW10_DOM_ITM_GRP_OID`,`TBW10_DOM_ITM_GRP_ROWNO`),
  KEY `UTBW10_CSV_WORK01` (`TBW10_SESSION_ID`,`TBW10_DATETIME`,`TBW10_STUDY_ID`,`TBW10_SUBJECT_ID`,`TBW10_VISIT_NO`,`TBW10_DOM_CD`,`TBW10_DOM_ITM_GRP_OID`,`TBW10_DOM_ITM_GRP_ROWNO`,`TBW10_DOM_VAR_NM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbw10_csv_work`
--

LOCK TABLES `tbw10_csv_work` WRITE;
/*!40000 ALTER TABLE `tbw10_csv_work` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbw10_csv_work` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbw11_cond_work`
--

DROP TABLE IF EXISTS `tbw11_cond_work`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbw11_cond_work` (
  `TBW11_SESSION_ID` varchar(50) NOT NULL,
  `TBW11_DATETIME` datetime NOT NULL,
  `TBW11_STUDY_ID` bigint(20) NOT NULL,
  `TBW11_SUBJECT_ID` mediumint(9) NOT NULL,
  `TBW11_CRF_ID` smallint(6) NOT NULL,
  PRIMARY KEY (`TBW11_SESSION_ID`,`TBW11_DATETIME`,`TBW11_STUDY_ID`,`TBW11_SUBJECT_ID`,`TBW11_CRF_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbw11_cond_work`
--

LOCK TABLES `tbw11_cond_work` WRITE;
/*!40000 ALTER TABLE `tbw11_cond_work` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbw11_cond_work` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbw12_crf_err_msg`
--

DROP TABLE IF EXISTS `tbw12_crf_err_msg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbw12_crf_err_msg` (
  `TBW12_SESSION_ID` varchar(50) NOT NULL,
  `TBW12_DATETIME` datetime NOT NULL,
  `TBW12_SEQ` smallint(6) NOT NULL,
  `TBW12_ERR_CD` smallint(6) DEFAULT NULL,
  `TBW12_ERR_DIV` smallint(6) DEFAULT NULL,
  `TBW12_ERR_MSG` varchar(3000) DEFAULT NULL,
  PRIMARY KEY (`TBW12_SESSION_ID`,`TBW12_DATETIME`,`TBW12_SEQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbw12_crf_err_msg`
--

LOCK TABLES `tbw12_crf_err_msg` WRITE;
/*!40000 ALTER TABLE `tbw12_crf_err_msg` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbw12_crf_err_msg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbw13_csv_record`
--

DROP TABLE IF EXISTS `tbw13_csv_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbw13_csv_record` (
  `TBW13_SESSION_ID` varchar(50) NOT NULL,
  `TBW13_DATETIME` datetime NOT NULL,
  `TBW13_STUDY_ID` bigint(20) NOT NULL,
  `TBW13_SUBJECT_ID` mediumint(9) NOT NULL,
  `TBW13_VISIT_NO` smallint(6) NOT NULL,
  `TBW13_DOM_CD` varchar(2) NOT NULL,
  `TBW13_DOM_ITM_GRP_OID` varchar(50) NOT NULL,
  `TBW13_DOM_ITM_GRP_ROWNO` smallint(6) NOT NULL,
  `TBW13_VALUE` text,
  PRIMARY KEY (`TBW13_SESSION_ID`,`TBW13_DATETIME`,`TBW13_STUDY_ID`,`TBW13_SUBJECT_ID`,`TBW13_VISIT_NO`,`TBW13_DOM_CD`,`TBW13_DOM_ITM_GRP_OID`,`TBW13_DOM_ITM_GRP_ROWNO`),
  KEY `UTBW13_CSV_RECORD01` (`TBW13_DOM_CD`,`TBW13_STUDY_ID`,`TBW13_SUBJECT_ID`,`TBW13_VISIT_NO`,`TBW13_DOM_ITM_GRP_OID`,`TBW13_DOM_ITM_GRP_ROWNO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbw13_csv_record`
--

LOCK TABLES `tbw13_csv_record` WRITE;
/*!40000 ALTER TABLE `tbw13_csv_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbw13_csv_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbw14_crf_sdt_work`
--

DROP TABLE IF EXISTS `tbw14_crf_sdt_work`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbw14_crf_sdt_work` (
  `TBW14_SESSION_ID` varchar(50) NOT NULL,
  `TBW14_DISP_DATETIME` varchar(14) NOT NULL,
  `TBW14_STUDY_ID` bigint(20) NOT NULL,
  `TBW14_SUBJECT_ID` mediumint(9) NOT NULL,
  `TBW14_CRF_ID` smallint(6) NOT NULL,
  `TBW14_CRF_LATEST_VERSION` smallint(6) NOT NULL,
  `TBW14_SDT_SAVE` mediumtext,
  PRIMARY KEY (`TBW14_SESSION_ID`,`TBW14_DISP_DATETIME`,`TBW14_STUDY_ID`,`TBW14_SUBJECT_ID`,`TBW14_CRF_ID`,`TBW14_CRF_LATEST_VERSION`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbw14_crf_sdt_work`
--

LOCK TABLES `tbw14_crf_sdt_work` WRITE;
/*!40000 ALTER TABLE `tbw14_crf_sdt_work` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbw14_crf_sdt_work` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `vbm01_crf_def_inf`
--

DROP TABLE IF EXISTS `vbm01_crf_def_inf`;
/*!50001 DROP VIEW IF EXISTS `vbm01_crf_def_inf`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vbm01_crf_def_inf` (
  `VBM01_TBM32_STUDY_ID` bigint(20),
  `VBM01_TBM32_CRF_ID` smallint(6),
  `VBM01_TBM31_CRF_SNM` varchar(20),
  `VBM01_TBM32_CRF_ITEM_CD` varchar(50),
  `VBM01_TBM32_CRF_ITEM_NM` varchar(200),
  `VBM01_TBM32_CRF_ITEM_DIV` varchar(20),
  `VBM01_TBM32_CRF_ITEM_GRP_CD` varchar(50),
  `VBM01_TBM32_CRF_ITEM_GRP_ORDER` smallint(6),
  `VBM01_TBM32_LOCATION_X` smallint(6),
  `VBM01_TBM32_LOCATION_Y` smallint(6),
  `VBM01_TBM32_LOCATION_X2` smallint(6),
  `VBM01_TBM32_LOCATION_Y2` smallint(6),
  `VBM01_TBM32_TEXT_ALIGN_DIV` varchar(6),
  `VBM01_TBM32_TEXT_MAXROWS` smallint(6),
  `VBM01_TBM32_TEXT_MAXLENGTH` smallint(6),
  `VBM01_TBM32_DECIMAL_DIGITS` smallint(6),
  `VBM01_TBM32_CHK_TRUE_INNER_VALUE` varchar(100),
  `VBM01_TBM32_CHK_FALSE_INNER_VALUE` varchar(100),
  `VBM01_TBM32_FIXED_VALUE` varchar(100),
  `VBM01_TBM32_LIST_CD` varchar(20),
  `VBM01_TBM25_LIST_NM` varchar(50),
  `VBM01_TBM32_IMAGE_CD` varchar(50),
  `VBM01_TBM32_TEXT` varchar(200),
  `VBM01_TBM32_FONT_SIZE` smallint(6),
  `VBM01_TBM32_FONT_UL_FLG` varchar(1),
  `VBM01_TBM32_FONT_COLOR_DIV` bigint(20),
  `VBM01_TBM32_LINE_SIZE_DIV` smallint(6),
  `VBM01_TBM32_LINE_COLOR_DIV` bigint(20),
  `VBM01_TBM32_LINE_START_POINT_DIV` varchar(2),
  `VBM01_TBM32_LINE_END_POINT_DIV` varchar(2),
  `VBM01_TBM32_LINE_ANGLE` smallint(6),
  `VBM01_TBM32_AUTH_LVL_MIN` smallint(6),
  `VBM01_TBM32_ZORDER` smallint(6),
  `VBM01_TBM32_TAB_ORDER` smallint(6),
  `VBM01_TBM32_TABSTOP_FLG` varchar(1),
  `VBM01_TBM32_REQUIRED_INPUT_FLG` varchar(1),
  `VBM01_TBM32_MIN_VALUE` varchar(10),
  `VBM01_TBM32_MAX_VALUE` varchar(10),
  `VBM01_TBM32_CRF_ITEM_NOTE` varchar(1000),
  `VBM01_TBM32_REF_CRF_ID` smallint(6),
  `VBM01_TBM32_REF_CRF_ITEM_CD` varchar(50),
  `VBM01_TBM37_VISIT_NO` smallint(6),
  `VBM01_TBM37_DOM_CD` varchar(2),
  `VBM01_TBM37_DOM_VAR_NM` varchar(50),
  `VBM01_TBM37_DOM_ITM_GRP_OID` varchar(50),
  `VBM01_TBM37_DOM_ITM_GRP_ATTR_SEQ` smallint(6),
  `VBM01_TBM37_DOM_ITM_GRP_ROWNO` smallint(6),
  `VBM01_TBM41_NCM_METADATA_ID` varchar(100)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vbm01_crf_def_inf`
--

/*!50001 DROP TABLE IF EXISTS `vbm01_crf_def_inf`*/;
/*!50001 DROP VIEW IF EXISTS `vbm01_crf_def_inf`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vbm01_crf_def_inf` AS select `itm`.`TBM32_STUDY_ID` AS `VBM01_TBM32_STUDY_ID`,`itm`.`TBM32_CRF_ID` AS `VBM01_TBM32_CRF_ID`,`crf`.`TBM31_CRF_SNM` AS `VBM01_TBM31_CRF_SNM`,`itm`.`TBM32_CRF_ITEM_CD` AS `VBM01_TBM32_CRF_ITEM_CD`,`itm`.`TBM32_CRF_ITEM_NM` AS `VBM01_TBM32_CRF_ITEM_NM`,`itm`.`TBM32_CRF_ITEM_DIV` AS `VBM01_TBM32_CRF_ITEM_DIV`,`itm`.`TBM32_CRF_ITEM_GRP_CD` AS `VBM01_TBM32_CRF_ITEM_GRP_CD`,`itm`.`TBM32_CRF_ITEM_GRP_ORDER` AS `VBM01_TBM32_CRF_ITEM_GRP_ORDER`,`itm`.`TBM32_LOCATION_X` AS `VBM01_TBM32_LOCATION_X`,`itm`.`TBM32_LOCATION_Y` AS `VBM01_TBM32_LOCATION_Y`,`itm`.`TBM32_LOCATION_X2` AS `VBM01_TBM32_LOCATION_X2`,`itm`.`TBM32_LOCATION_Y2` AS `VBM01_TBM32_LOCATION_Y2`,`itm`.`TBM32_TEXT_ALIGN_DIV` AS `VBM01_TBM32_TEXT_ALIGN_DIV`,`itm`.`TBM32_TEXT_MAXROWS` AS `VBM01_TBM32_TEXT_MAXROWS`,`itm`.`TBM32_TEXT_MAXLENGTH` AS `VBM01_TBM32_TEXT_MAXLENGTH`,`itm`.`TBM32_DECIMAL_DIGITS` AS `VBM01_TBM32_DECIMAL_DIGITS`,`itm`.`TBM32_CHK_TRUE_INNER_VALUE` AS `VBM01_TBM32_CHK_TRUE_INNER_VALUE`,`itm`.`TBM32_CHK_FALSE_INNER_VALUE` AS `VBM01_TBM32_CHK_FALSE_INNER_VALUE`,`itm`.`TBM32_FIXED_VALUE` AS `VBM01_TBM32_FIXED_VALUE`,`itm`.`TBM32_LIST_CD` AS `VBM01_TBM32_LIST_CD`,`lst`.`TBM25_LIST_NM` AS `VBM01_TBM25_LIST_NM`,`itm`.`TBM32_IMAGE_CD` AS `VBM01_TBM32_IMAGE_CD`,`itm`.`TBM32_TEXT` AS `VBM01_TBM32_TEXT`,`itm`.`TBM32_FONT_SIZE` AS `VBM01_TBM32_FONT_SIZE`,`itm`.`TBM32_FONT_UL_FLG` AS `VBM01_TBM32_FONT_UL_FLG`,`itm`.`TBM32_FONT_COLOR_DIV` AS `VBM01_TBM32_FONT_COLOR_DIV`,`itm`.`TBM32_LINE_SIZE_DIV` AS `VBM01_TBM32_LINE_SIZE_DIV`,`itm`.`TBM32_LINE_COLOR_DIV` AS `VBM01_TBM32_LINE_COLOR_DIV`,`itm`.`TBM32_LINE_START_POINT_DIV` AS `VBM01_TBM32_LINE_START_POINT_DIV`,`itm`.`TBM32_LINE_END_POINT_DIV` AS `VBM01_TBM32_LINE_END_POINT_DIV`,`itm`.`TBM32_LINE_ANGLE` AS `VBM01_TBM32_LINE_ANGLE`,`itm`.`TBM32_AUTH_LVL_MIN` AS `VBM01_TBM32_AUTH_LVL_MIN`,`itm`.`TBM32_ZORDER` AS `VBM01_TBM32_ZORDER`,`itm`.`TBM32_TAB_ORDER` AS `VBM01_TBM32_TAB_ORDER`,`itm`.`TBM32_TABSTOP_FLG` AS `VBM01_TBM32_TABSTOP_FLG`,`itm`.`TBM32_REQUIRED_INPUT_FLG` AS `VBM01_TBM32_REQUIRED_INPUT_FLG`,`itm`.`TBM32_MIN_VALUE` AS `VBM01_TBM32_MIN_VALUE`,`itm`.`TBM32_MAX_VALUE` AS `VBM01_TBM32_MAX_VALUE`,`itm`.`TBM32_CRF_ITEM_NOTE` AS `VBM01_TBM32_CRF_ITEM_NOTE`,`itm`.`TBM32_REF_CRF_ID` AS `VBM01_TBM32_REF_CRF_ID`,`itm`.`TBM32_REF_CRF_ITEM_CD` AS `VBM01_TBM32_REF_CRF_ITEM_CD`,`dom`.`TBM37_VISIT_NO` AS `VBM01_TBM37_VISIT_NO`,`dom`.`TBM37_DOM_CD` AS `VBM01_TBM37_DOM_CD`,`dom`.`TBM37_DOM_VAR_NM` AS `VBM01_TBM37_DOM_VAR_NM`,`dom`.`TBM37_DOM_ITM_GRP_OID` AS `VBM01_TBM37_DOM_ITM_GRP_OID`,`dom`.`TBM37_DOM_ITM_GRP_ATTR_SEQ` AS `VBM01_TBM37_DOM_ITM_GRP_ATTR_SEQ`,`dom`.`TBM37_DOM_ITM_GRP_ROWNO` AS `VBM01_TBM37_DOM_ITM_GRP_ROWNO`,`ncm`.`TBM41_NCM_METADATA_ID` AS `VBM01_TBM41_NCM_METADATA_ID` from ((((`tbm32_crf_item` `itm` join `tbm31_crf` `crf` on(((`itm`.`TBM32_STUDY_ID` = `crf`.`TBM31_STUDY_ID`) and (`itm`.`TBM32_CRF_ID` = `crf`.`TBM31_CRF_ID`)))) left join `tbm37_crf_dom_map` `dom` on(((`itm`.`TBM32_STUDY_ID` = `dom`.`TBM37_STUDY_ID`) and (`itm`.`TBM32_CRF_ID` = `dom`.`TBM37_CRF_ID`) and (`itm`.`TBM32_CRF_ITEM_CD` = `dom`.`TBM37_CRF_ITEM_GRP_CD`) and (`dom`.`TBM37_DEL_FLG` = '0')))) left join `tbm41_crf_ncm_map` `ncm` on(((`itm`.`TBM32_STUDY_ID` = `ncm`.`TBM41_STUDY_ID`) and (`itm`.`TBM32_CRF_ID` = `ncm`.`TBM41_CRF_ID`) and (`itm`.`TBM32_CRF_ITEM_CD` = `ncm`.`TBM41_CRF_ITEM_GRP_CD`) and (`ncm`.`TBM41_DEL_FLG` = '0')))) left join `tbm25_sel_list` `lst` on(((`itm`.`TBM32_STUDY_ID` = `lst`.`TBM25_STUDY_ID`) and (`itm`.`TBM32_LIST_CD` = `lst`.`TBM25_LIST_CD`) and (`lst`.`TBM25_DEL_FLG` = '0')))) where ((`crf`.`TBM31_STATUS` in ('0','1')) and (`crf`.`TBM31_DEL_FLG` = '0') and (`itm`.`TBM32_DEL_FLG` = '0')) order by `dom`.`TBM37_VISIT_NO`,`dom`.`TBM37_DOM_CD`,`dom`.`TBM37_DOM_VAR_NM`,`dom`.`TBM37_DOM_ITM_GRP_OID`,`dom`.`TBM37_DOM_ITM_GRP_ROWNO`,`itm`.`TBM32_CRF_ID`,`itm`.`TBM32_CRF_ITEM_CD` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-06-05 17:30:29
