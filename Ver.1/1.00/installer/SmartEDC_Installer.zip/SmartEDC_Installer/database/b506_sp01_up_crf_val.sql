drop procedure if exists b506_sp01_up_crf_val;
delimiter //
create procedure b506_sp01_up_crf_val(
		inout	p_session_id	varchar(50)
	,	inout	p_app_id		varchar(7)
	,	inout	p_disp_datetime	varchar(14)
	,	inout	p_exec_user_id	varchar(200)
	,	inout	p_exec_auth_cd	varchar(2)
	,	out		p_err_cd		tinyint
	,	out		p_err_val		varchar(512)
	)
begin

	declare program_name	varchar(20)	DEFAULT 'b506_sp01_up_crf_val';
	declare eod				tinyint;
	declare exec_time		datetime	DEFAULT now();

	set p_err_cd	= 0;
	set p_err_val	= '';

	if p_err_cd = 0 then
		call b506_sp02_crf_update(
			p_session_id, p_app_id, p_disp_datetime, p_exec_user_id, p_exec_auth_cd, exec_time, p_err_cd, p_err_val
		);
	end if;

	if p_err_cd = 0 then
		call b506_sp03_crf_result(
			p_session_id, p_app_id, p_disp_datetime, p_exec_user_id, exec_time, p_err_cd
		);
	end if;

	if p_err_cd = 0 then
		call b506_sp04_crf_verup(
			p_session_id, p_app_id, p_disp_datetime,  p_exec_user_id, exec_time, p_err_cd
		);
	end if;

	if p_err_cd = 0 then
		call b506_sp05_crf_memo(
			p_session_id, p_app_id, p_disp_datetime, p_exec_user_id, p_exec_auth_cd, exec_time, p_err_cd
		);
	end if;

end;
//
delimiter ;
