drop procedure if exists b506_sp02_crf_update;
delimiter //
create procedure b506_sp02_crf_update(
		in	p_session_id	varchar(50)
	,	in	p_app_id		varchar(7)
	,	in	p_disp_datetime	varchar(14)
	,	in	p_exec_user_id	varchar(200)
	,	in	p_exec_auth_cd	varchar(2)
	,	in	p_exec_time		datetime
	,	out	p_err_cd		tinyint
	,	out	p_err_val		varchar(512)
	)
main: begin

	declare program_name	varchar(20)	DEFAULT 'b506_sp02_crf_update';
	declare eod				tinyint;

	declare w_err			boolean;
	declare w_current_level	smallint;
	declare w_input_level	smallint;
	declare w_max_level		smallint	default 4;
	declare w_study_id		bigint;
	declare w_subject_id	mediumint;
	declare w_crf_id		smallint;

	declare cr_exists_check cursor for
		select	tbw04_study_id
			,	tbw04_subject_id
			,	tbw04_crf_id
		from		tbw04_crf tbw04
		left join	tbt02_crf tbt02
			on	tbt02.tbt02_study_id	= tbw04.tbw04_study_id
			and	tbt02.tbt02_subject_id	= tbw04.tbw04_subject_id
			and	tbt02.tbt02_crf_id		= tbw04.tbw04_crf_id
		where	tbw04.tbw04_session_id		= p_session_id
		and		tbw04.tbw04_app_id			= p_app_id
		and		tbw04.tbw04_disp_datetime	= p_disp_datetime
		and		tbt02.tbt02_study_id is null
		;

	declare cr_lock_check cursor for
		select	tbw04_study_id
			,	tbw04_subject_id
			,	tbw04_crf_id
		from		tbw04_crf tbw04
		inner join	tbt02_crf tbt02
			on	tbt02.tbt02_study_id	= tbw04.tbw04_study_id
			and	tbt02.tbt02_subject_id	= tbw04.tbw04_subject_id
			and	tbt02.tbt02_crf_id		= tbw04.tbw04_crf_id
		where	tbw04.tbw04_session_id		= p_session_id
		and		tbw04.tbw04_app_id			= p_app_id
		and		tbw04.tbw04_disp_datetime	= p_disp_datetime
		and		tbt02.tbt02_lock_flg		<> '1'
		;

	declare cr_level_check cursor for
		select	tbw04_study_id
			,	tbw04_subject_id
			,	tbw04_crf_id
		from		tbw04_crf tbw04
		inner join	tbt02_crf tbt02
			on	tbt02.tbt02_study_id	= tbw04.tbw04_study_id
			and	tbt02.tbt02_subject_id	= tbw04.tbw04_subject_id
			and	tbt02.tbt02_crf_id		= tbw04.tbw04_crf_id
		where	tbw04.tbw04_session_id		= p_session_id
		and		tbw04.tbw04_app_id			= p_app_id
		and		tbw04.tbw04_disp_datetime	= p_disp_datetime
		and		tbt02.tbt02_crf_input_level	> w_current_level
		;

	declare continue handler for not found
	begin
		set eod	= 1;
	end;

	set p_err_cd	= 0;
	set p_err_val	= '';

	select b506_sf01_get_input_level(p_exec_auth_cd) into w_input_level;

	select	max(cast(tas01_item_cd as signed)) into w_max_level
	from	tas01_cdnm
	where	tas01_data_kind	= 'B01'
	and		tas01_del_flg	= '0'
	;

	select	tam04_auth_lvl into w_current_level
	from	tam04_kngn
	where	tam04_auth_cd	= p_exec_auth_cd
	and		tam04_del_flg	= '0'
	;

	open cr_exists_check;
	set eod		= 0;
	set w_err	= false;
	fetch cr_exists_check into w_study_id, w_subject_id, w_crf_id;
	loop_cr_exists_check: while eod = 0 do
		select concat(p_err_val, concat_ws(',', w_study_id, w_subject_id, w_crf_id), Char(13)) into p_err_val;
		set w_err = true;
		fetch cr_exists_check into w_study_id, w_subject_id, w_crf_id;
	end while loop_cr_exists_check;
	close cr_exists_check;

	if w_err then
		set p_err_cd = 2;
		leave main;
	end if;

	open cr_lock_check;
	set eod		= 0;
	set w_err	= false;
	fetch cr_lock_check into w_study_id, w_subject_id, w_crf_id;
	loop_cr_lock_check: while eod = 0 do
		select concat(p_err_val, concat_ws(',', w_study_id, w_subject_id, w_crf_id), Char(13)) into p_err_val;
		set w_err = true;
		fetch cr_lock_check into w_study_id, w_subject_id, w_crf_id;
	end while loop_cr_lock_check;
	close cr_lock_check;

	if w_err then
		set p_err_cd = 3;
		leave main;
	end if;

	open cr_level_check;
	set eod		= 0;
	set w_err	= false;
	fetch cr_level_check into w_study_id, w_subject_id, w_crf_id;
	loop_cr_level_check: while eod = 0 do
		select concat(p_err_val, concat_ws(',', w_study_id, w_subject_id, w_crf_id), Char(13)) into p_err_val;
		set w_err = true;
		fetch cr_level_check into w_study_id, w_subject_id, w_crf_id;
	end while loop_cr_level_check;
	close cr_level_check;

	if w_err then
		set p_err_cd = 4;
		leave main;
	end if;

	update		tbt02_crf tbt02
	inner join	tbw04_crf tbw04
		on	tbt02.tbt02_study_id	= tbw04.tbw04_study_id
		and	tbt02.tbt02_subject_id	= tbw04.tbw04_subject_id
		and	tbt02.tbt02_crf_id		= tbw04.tbw04_crf_id
	set		tbt02_crf_input_level		= if(tbw04.tbw04_completion_flg = '1'
												, w_input_level
												, tbt02_crf_input_level
											)
	,		tbt02_lock_flg				= if(tbw04.tbw04_completion_flg = '0' and tbw04.tbw04_edit_flg = '1'
												, '2'
												, '0'
											)
	,		tbt02_lock_datetime			= if(tbw04.tbw04_completion_flg = '0' and tbw04.tbw04_edit_flg = '1'
												, p_exec_time
												, null
											)
	,		tbt02_lock_user_id			= if(tbw04.tbw04_completion_flg = '0' and tbw04.tbw04_edit_flg = '1'
												, p_exec_user_id
												, null
											)
	,		tbt02_lock_auth_cd			= if(tbw04.tbw04_completion_flg = '0' and tbw04.tbw04_edit_flg = '1'
												, p_exec_auth_cd
												, null
											)
	,		tbt02_upload_datetime		= p_exec_time
	,		tbt02_upload_user_id		= p_exec_user_id
	,		tbt02_upload_auth_cd		= p_exec_auth_cd
	,		tbt02_dm_arrival_flg		= if(w_input_level >= w_max_level and tbw04.tbw04_completion_flg = '1' and tbt02_dm_arrival_flg <> '1'
												, '1'
												, tbt02_dm_arrival_flg
											)
	,		tbt02_dm_arrival_datetime	= if(w_input_level >= w_max_level and tbw04.tbw04_completion_flg = '1' and tbt02_dm_arrival_flg <> '1'
												, p_exec_time
												, tbt02_dm_arrival_datetime
											)
	,		tbt02_approval_flg			= (case
												when tbw04.tbw04_approval_flg in ('0', '1') then
													tbw04.tbw04_approval_flg
												else
													tbt02_approval_flg
											end)
	,		tbt02_approval_datetime		= (case
												when tbw04.tbw04_approval_flg = '0' then
													null
												when tbw04.tbw04_approval_flg = '1' then
													p_exec_time
												else
													tbt02_approval_datetime
											end)
	,		tbt02_approval_user_id		= (case
												when tbw04.tbw04_approval_flg = '0' then
													null
												when tbw04.tbw04_approval_flg = '1' then
													p_exec_user_id
												else
													tbt02_approval_user_id
											end)
	,		tbt02_approval_auth_cd		= (case
												when tbw04.tbw04_approval_flg = '0' then
													null
												when tbw04.tbw04_approval_flg = '1' then
													p_exec_auth_cd
												else
													tbt02_approval_auth_cd
											end)
	,		tbt02_input_end_flg			= (case
												when tbw04.tbw04_input_end_flg in ('0', '1') then
													tbw04.tbw04_input_end_flg
												else
													tbt02_input_end_flg
											end)
	,		tbt02_input_end_datetime	= (case
												when tbw04.tbw04_input_end_flg = '0' then
													null
												when tbw04.tbw04_input_end_flg = '1' then
													p_exec_time
												else
													tbt02_input_end_datetime
											end)
	,		tbt02_input_end_user_id		= (case
												when tbw04.tbw04_input_end_flg = '0' then
													null
												when tbw04.tbw04_input_end_flg = '1' then
													p_exec_user_id
												else
													tbt02_input_end_user_id
											end)
	,		tbt02_input_end_auth_cd		= (case
												when tbw04.tbw04_input_end_flg = '0' then
													null
												when tbw04.tbw04_input_end_flg = '1' then
													p_exec_auth_cd
												else
													tbt02_input_end_auth_cd
											end)
	,		tbt02_upd_datetime			= p_exec_time
	,		tbt02_upd_user_id			= p_exec_user_id
	,		tbt02_upd_prog_nm			= program_name
	,		tbt02_upd_cnt				= tbt02_upd_cnt + 1
	where	tbw04.tbw04_session_id		= p_session_id
	and		tbw04.tbw04_app_id			= p_app_id
	and		tbw04.tbw04_disp_datetime	= p_disp_datetime
	;

end main;
//
delimiter ;
